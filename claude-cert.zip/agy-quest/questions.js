window.QUIZ_DATA = {
  "meta": {
    "exam": "Claude Certified Architect — Foundations (CCAR-F)",
    "blueprintVersion": "1.0",
    "sets": 3,
    "questionsPerSet": 60,
    "passScaled": 720
  },
  "sets": [
    {
      "id": 1,
      "title": "Core judgment",
      "blurb": "Balanced coverage of agent loops, tool boundaries, Claude Code config, structured output and reliability. Start here.",
      "mode": "mixed",
      "questions": [
        {
          "id": "s1q01",
          "d": "D1",
          "t": "1.1",
          "type": "single",
          "q": "A support agent is built with a manual agentic loop. In production it sometimes performs one tool call, writes “I found your order” in the same assistant turn, and exits before processing the refund. The tool result is never sent back to the model. What is the most likely defect?",
          "o": [
            "The loop retries each tool call too many times and reaches its cap.",
            "The loop terminates when the assistant returns any text instead of inspecting stop_reason.",
            "The lookup_order tool description is too short for reliable selection.",
            "The model's max_tokens setting is too low to finish the response."
          ],
          "a": [
            1
          ],
          "e": "The loop must continue while stop_reason is “tool_use” and stop only on “end_turn”. Assistant text can appear alongside a tool_use block, so treating text as completion prematurely ends the workflow. Max tokens, tool descriptions and retry caps do not explain why the tool result was never appended."
        },
        {
          "id": "s1q02",
          "d": "D1",
          "t": "1.1",
          "type": "single",
          "q": "You are reviewing an agent loop that must support multi-step tool use. Which control flow correctly implements the lifecycle described by the exam blueprint?",
          "o": [
            "Call the model up to a fixed maximum of ten times; terminate on the tenth iteration regardless of stop_reason.",
            "Call the model; stop when the assistant text no longer contains the word “tool” or an exclamation mark.",
            "Call the model; if the reply contains a tool call, execute it and append the result, then treat the next assistant message as final.",
            "Call the model; if stop_reason is “tool_use”, execute every requested tool, append tool_result blocks to history, and continue. Stop when stop_reason is “end_turn”."
          ],
          "a": [
            3
          ],
          "e": "The reliable signal is the API's stop_reason. A “tool_use” stop means execute and return results for another model turn; “end_turn” means the model is finished. Fixed caps, keyword parsing and text heuristics are named anti-patterns because they can end work early or loop without a semantic stop."
        },
        {
          "id": "s1q03",
          "d": "D1",
          "t": "1.2",
          "type": "single",
          "q": "A research coordinator delegates the topic “AI's impact on creative industries”. Each subagent succeeds, but the final report covers only digital art, graphic design and photography. The coordinator log shows those three subtasks. Where should the fix be made?",
          "o": [
            "In the document analysis agent: relax relevance filtering so non-visual sources are not discarded.",
            "In the coordinator: improve task decomposition so the assigned scope covers all relevant creative sectors.",
            "In the web search agent: broaden its queries so it discovers music, writing and film itself.",
            "In the synthesis agent: add instructions to detect coverage gaps in the findings it receives."
          ],
          "a": [
            1
          ],
          "e": "Every downstream agent executed its assignment correctly; the assignment itself was too narrow. The coordinator owns decomposition and coverage, so it must split a broad topic into subtopics or source types that span the whole question. Blaming working subagents leaves the root cause untouched."
        },
        {
          "id": "s1q04",
          "d": "D1",
          "t": "1.2",
          "type": "multi",
          "n": 2,
          "q": "A team wants subagents to call one another directly to reduce latency, bypassing the coordinator. Which two properties of the hub-and-spoke design would this most directly weaken? (Select two.)",
          "o": [
            "The requirement that each subagent use a different model tier.",
            "Consistent error handling and controlled information flow across the system.",
            "The ability of subagents to run in parallel on independent subtasks.",
            "Central observability of inter-agent communication and routing decisions."
          ],
          "a": [
            1,
            3
          ],
          "e": "Routing all communication through the coordinator preserves an inspectable hub for routing, aggregation, error policy and controlled data movement. Parallelism can still occur through multiple Task calls from the coordinator; different model tiers are not a requirement of the pattern."
        },
        {
          "id": "s1q05",
          "d": "D1",
          "t": "1.2",
          "type": "single",
          "q": "A coordinator always invokes all four research subagents for every question, including simple factual lookups. This adds latency and produces irrelevant analysis. What is the best architectural change?",
          "o": [
            "Add a fixed rule that skips the report agent when the query has fewer than ten words.",
            "Have the coordinator analyze query requirements and dynamically invoke only the subagents needed.",
            "Merge the four subagents into one general-purpose agent with every tool.",
            "Run all four subagents in parallel so the unnecessary work finishes sooner."
          ],
          "a": [
            1
          ],
          "e": "The coordinator's role is to decide which specialists a query actually needs. Dynamic selection reduces cost while preserving specialization. Parallelizing unnecessary work hides the design problem, merging specialists increases tool confusion, and a word-count heuristic is unrelated to information need."
        },
        {
          "id": "s1q06",
          "d": "D1",
          "t": "1.3",
          "type": "single",
          "q": "A coordinator must launch a web-search subagent and a document-analysis subagent at the same time. Both need the same research brief. What is the correct Agent SDK mechanism?",
          "o": [
            "Emit two Task tool calls in a single coordinator response, with the brief included in each subagent prompt.",
            "Call the first subagent, wait for completion, then call the second in the next coordinator turn.",
            "Place both subagents in shared memory so they inherit the coordinator's conversation automatically.",
            "Expose each subagent as an MCP tool and let the model choose whichever server responds first."
          ],
          "a": [
            0
          ],
          "e": "Parallel subagent execution comes from multiple Task tool calls in one coordinator response. Subagents have isolated context, so the brief must be passed explicitly in each prompt. Sequential calls are not parallel, shared memory is not automatic inheritance, and subagents are not MCP servers."
        },
        {
          "id": "s1q07",
          "d": "D1",
          "t": "1.3",
          "type": "single",
          "q": "A synthesis subagent receives prose summaries from prior agents but no URLs. The final report cannot cite sources. Which change best preserves attribution without over-provisioning the synthesizer?",
          "o": [
            "Store all prior conversations in shared memory so the synthesis agent can inspect them later.",
            "Increase the synthesis agent's context window and ask it to “remember where each fact came from”.",
            "Require each upstream agent to return structured findings with claim, evidence excerpt, source URL, document name and date; pass those structures into the synthesis prompt.",
            "Give the synthesis agent every web-search tool so it can rediscover sources for each claim."
          ],
          "a": [
            2
          ],
          "e": "Attribution must travel with the finding as structured metadata. Subagents do not inherit the coordinator's history, so prose plus an instruction to remember is not a provenance mechanism. Giving synthesis broad search tools violates specialization; a larger window does not reconstruct lost mappings."
        },
        {
          "id": "s1q08",
          "d": "D1",
          "t": "1.4",
          "type": "single",
          "q": "An agent applies account credits before verifying the customer's identity. Logs show this happens in 8% of cases and has caused credits on the wrong account. The policy requires deterministic compliance. Which fix is appropriate?",
          "o": [
            "Add few-shot examples showing the agent verifying identity first in similar cases.",
            "Restrict the credit tool to the coordinator and leave verification to the agent's judgment.",
            "Strengthen the system prompt to say identity verification is mandatory before credits.",
            "Add a programmatic prerequisite gate that blocks credit operations until a verified customer ID is present."
          ],
          "a": [
            3
          ],
          "e": "When a prerequisite protects money or private data, prompt-based guidance remains probabilistic. A gate that checks for a verified ID before allowing the downstream call gives a deterministic guarantee. Prompting and examples reduce but do not eliminate violations; restricting tool ownership does not enforce ordering."
        },
        {
          "id": "s1q09",
          "d": "D1",
          "t": "1.4",
          "type": "single",
          "q": "A customer writes one message covering a duplicate charge, a delayed replacement, and a change of address. The agent resolves the charge and closes the case. What workflow best handles this multi-concern request?",
          "o": [
            "Handle the concerns strictly in the order they appear and stop after the first successful tool call.",
            "Decompose the message into distinct concerns, investigate each using shared case context, then synthesize one unified resolution.",
            "Escalate the entire message because multi-concern requests exceed the agent's authority.",
            "Ask the customer to send three separate tickets so each concern can be handled independently."
          ],
          "a": [
            1
          ],
          "e": "The blueprint calls for decomposing multi-concern requests, investigating each with shared context, and synthesizing a unified answer. Forcing the customer to re-submit is poor service, sequential handling can drop later concerns, and complexity alone is not an escalation trigger."
        },
        {
          "id": "s1q10",
          "d": "D1",
          "t": "1.4",
          "type": "multi",
          "n": 2,
          "q": "A mid-process escalation must hand a case to a human who cannot see the chat transcript. Which two components are most important in the structured handoff? (Select two.)",
          "o": [
            "The model's self-reported confidence score and sentiment classification.",
            "The full raw transcript with every tool payload attached.",
            "Verified customer details and the specific facts of the case, such as amount, dates and order ID.",
            "Root-cause analysis plus a recommended next action for the human agent."
          ],
          "a": [
            2,
            3
          ],
          "e": "A useful handoff is self-contained: verified identity, transactional facts, what was found, and what should happen next. Raw transcripts are large and not a summary; self-reported confidence and sentiment are explicitly unreliable proxies for case complexity."
        },
        {
          "id": "s1q11",
          "d": "D1",
          "t": "1.5",
          "type": "single",
          "q": "Three order MCP tools return timestamps as Unix seconds, ISO 8601 and a numeric status code. The agent misreads dates and compares statuses incorrectly. Where should normalization occur?",
          "o": [
            "In a retry loop that re-calls the tool until the model interprets the value correctly.",
            "By replacing the three tools with one generic tool that returns whatever format is available.",
            "In a PostToolUse hook that converts each tool result to one canonical schema before the model processes it.",
            "In the system prompt, instructing the model to infer the format from context on every call."
          ],
          "a": [
            2
          ],
          "e": "A PostToolUse hook is the deterministic place to normalize heterogeneous tool output before it enters model context. Prompt inference is probabilistic and repeated on every turn; a generic tool does not create consistency; retries cannot fix an interpretation problem."
        },
        {
          "id": "s1q12",
          "d": "D1",
          "t": "1.5",
          "type": "single",
          "q": "Company policy forbids refunds over $500 without manager approval. The agent has exceeded that limit in 3% of transactions despite a clear prompt. What control best guarantees compliance?",
          "o": [
            "Few-shot examples that show the agent escalating high-value refunds.",
            "A tool-call interception hook that blocks the refund above the threshold and routes it to human approval.",
            "A stronger system-prompt sentence in bold stating that refunds above $500 are prohibited.",
            "Lowering the model temperature so the agent follows instructions more consistently."
          ],
          "a": [
            1
          ],
          "e": "Hooks enforce business rules regardless of model sampling. Instructions and examples remain probabilistic, and temperature does not create a guarantee. The hook also provides a deterministic redirect path to human approval."
        },
        {
          "id": "s1q13",
          "d": "D1",
          "t": "1.6",
          "type": "single",
          "q": "A 14-file pull request receives inconsistent review depth: some files get detailed comments, obvious bugs are missed, and identical code is approved in one file but flagged in another. What review decomposition is most appropriate?",
          "o": [
            "Run a per-file local analysis pass for each file, then a separate cross-file integration pass for data-flow issues.",
            "Switch to a larger-context model so all 14 files fit comfortably in one prompt.",
            "Run three full-PR reviews and report only findings that appear in at least two runs.",
            "Require developers to split the PR into groups of three files before any automated review."
          ],
          "a": [
            0
          ],
          "e": "Attention dilution and contradictory local judgments are fixed by narrowing each pass. Per-file passes give consistent local depth; an integration pass handles cross-file dependencies. Larger context does not guarantee attention quality, and consensus voting can suppress intermittently detected real bugs."
        },
        {
          "id": "s1q14",
          "d": "D1",
          "t": "1.6",
          "type": "single",
          "q": "You are asked to “add comprehensive tests to this legacy codebase”. No test inventory exists and the dependency structure is unknown. Which decomposition strategy fits the work?",
          "o": [
            "Generate tests for every file in a single pass so no module is missed.",
            "Map the repository structure and entry points, identify high-impact areas, then build a prioritized plan that adapts as dependencies are discovered.",
            "Start with the alphabetically first twenty files and work through the list in order.",
            "Ask the model to produce a fixed 100-test plan before opening any source file."
          ],
          "a": [
            1
          ],
          "e": "Open-ended investigation needs adaptive decomposition: learn the structure, prioritize by impact, and revise as dependencies emerge. A fixed list or one giant pass ignores what is discovered and spreads effort evenly rather than where risk is highest."
        },
        {
          "id": "s1q15",
          "d": "D1",
          "t": "1.7",
          "type": "single",
          "q": "You return to a named investigation session two days later, but several files the agent analyzed have since changed. Prior tool results are partly stale. What is the most reliable approach?",
          "o": [
            "Start a new session with a structured summary of the prior findings and explicitly flag the changed files for targeted re-analysis.",
            "Resume the old session exactly as it was and ask the agent to “be careful” about outdated information.",
            "Fork the session and replay every original tool call against every file.",
            "Resume the old session and delete its tool-result messages without adding a summary."
          ],
          "a": [
            0
          ],
          "e": "Resuming is appropriate when context is mostly valid; when tool results are stale, a fresh session with an injected structured summary is more reliable. The summary preserves useful findings and the changed-file list focuses re-analysis. Blind resumption or deletion without replacement loses or trusts stale evidence."
        },
        {
          "id": "s1q16",
          "d": "D1",
          "t": "1.7",
          "type": "single",
          "q": "After a shared codebase analysis, you want to compare two refactoring strategies without one experiment contaminating the other. Which session mechanism fits?",
          "o": [
            "Spawn two subagents with identical prompts but no shared findings and compare their outputs.",
            "Use --resume twice in the same session, applying strategy A and then strategy B sequentially.",
            "Start two unrelated sessions with no baseline and ask each to rediscover the codebase.",
            "Use fork_session to create independent branches from the shared analysis baseline."
          ],
          "a": [
            3
          ],
          "e": "Forking preserves a common analysis baseline while isolating divergent exploration. Sequential work in one session lets the first strategy contaminate the second; unrelated sessions waste effort and lose the shared baseline; subagents do not inherit context automatically."
        },
        {
          "id": "s1q17",
          "d": "D2",
          "t": "2.1",
          "type": "single",
          "q": "Users say “check my order #12345”, but the agent often calls get_customer instead of lookup_order. Both tools have one-line descriptions and accept similar identifiers. What is the highest-leverage first fix?",
          "o": [
            "Build a keyword router that selects the tool before the model sees the request.",
            "Add eight few-shot examples that route order questions to lookup_order.",
            "Expand each description to state purpose, accepted inputs, example queries, edge cases and when to use it instead of the similar tool.",
            "Merge both tools into one lookup_entity tool that decides which backend to query."
          ],
          "a": [
            2
          ],
          "e": "Tool descriptions are the model's primary selection signal. Minimal descriptions cannot distinguish similar tools, so detailed boundaries fix the root cause cheaply. Examples add tokens without repairing descriptions; a router bypasses model understanding; consolidation is a larger design change, not the first step."
        },
        {
          "id": "s1q18",
          "d": "D2",
          "t": "2.1",
          "type": "single",
          "q": "One generic analyze_document tool is used for data extraction, summarization and claim verification. The agent routinely chooses it for tasks where its behavior is wrong. What change best improves selection and output contracts?",
          "o": [
            "Rename the tool to analyze_document_v2 and keep the existing description.",
            "Increase the number of few-shot examples that call analyze_document.",
            "Split it into extract_data_points, summarize_content and verify_claim_against_source, each with a defined contract.",
            "Add a system-prompt line telling the model to “pick the right mode” inside the generic tool."
          ],
          "a": [
            2
          ],
          "e": "Purpose-specific tools with explicit input/output contracts remove ambiguous mode selection. Renaming without changing semantics does not help; a single tool with internal modes hides intent; more examples for the same generic tool reinforce the ambiguity."
        },
        {
          "id": "s1q19",
          "d": "D2",
          "t": "2.2",
          "type": "single",
          "q": "A tool returns “Operation failed” for every problem. The agent retries a validation error repeatedly and eventually gives up. What error-response design best supports recovery?",
          "o": [
            "Escalate every tool error directly to a human without attempting recovery.",
            "Return a generic failure string but lower the agent's retry limit to one attempt.",
            "Return structured metadata: errorCategory (transient/validation/permission), isRetryable, and a human-readable description.",
            "Return an empty successful result so the agent can continue with other work."
          ],
          "a": [
            2
          ],
          "e": "The agent needs category and retryability to choose between retrying, correcting input, or escalating. Generic errors hide that decision. A lower limit avoids wasted retries but still cannot distinguish causes; empty success suppresses the failure; escalating everything removes useful autonomy."
        },
        {
          "id": "s1q20",
          "d": "D2",
          "t": "2.2",
          "type": "single",
          "q": "A search tool finds no matching documents and returns zero results. The agent treats this as an infrastructure failure and retries with the same query several times. What should the tool return?",
          "o": [
            "A transient error with isRetryable set to true so the agent keeps trying.",
            "A valid empty result explicitly labeled as a successful query with no matches.",
            "A fabricated best-match document so the workflow can continue.",
            "A generic “search unavailable” status to avoid exposing internal details."
          ],
          "a": [
            1
          ],
          "e": "Access failures and valid empty results are different outcomes. A successful no-match result tells the agent to change the query or report that nothing was found. Marking it transient invites pointless retries; generic errors hide the distinction; fabricating data is unsafe."
        },
        {
          "id": "s1q21",
          "d": "D2",
          "t": "2.2",
          "type": "single",
          "q": "A search subagent hits a timeout while researching one of five sources. The coordinator can still produce a useful report if it knows what happened. What should the subagent do?",
          "o": [
            "Raise an exception that terminates the entire research workflow.",
            "Return an empty result marked successful so the coordinator never sees a failure.",
            "Retry the same request indefinitely until the source responds.",
            "Attempt bounded local recovery for the transient failure, then propagate structured error context with partial results if recovery fails."
          ],
          "a": [
            3
          ],
          "e": "Local recovery keeps transient failures from burdening the coordinator, but unresolved errors should travel with failure type, attempted query, partial results and alternatives. Empty success hides a gap, infinite retries stall the workflow, and terminating everything discards recoverable work."
        },
        {
          "id": "s1q22",
          "d": "D2",
          "t": "2.3",
          "type": "single",
          "q": "Every subagent in a research system has access to all 18 tools, and tool misuse is rising: the synthesis agent runs web searches, while the report agent edits source documents. What change best addresses this?",
          "o": [
            "Restrict each subagent's tool set to its role, with narrow scoped tools for high-frequency cross-role needs.",
            "Add a classifier that predicts which of the 18 tools the agent should use before each turn.",
            "Keep the same tool set but rewrite every description in more detail.",
            "Set tool_choice to “any” so each agent must call some tool on every turn."
          ],
          "a": [
            0
          ],
          "e": "More tools increase decision complexity and invite out-of-role behavior. Least privilege gives each specialist only what it needs, optionally plus a constrained cross-role tool. Better descriptions help but do not remove irrelevant options; forcing any tool worsens misuse; a classifier adds complexity around the same over-provisioned set."
        },
        {
          "id": "s1q23",
          "d": "D2",
          "t": "2.3",
          "type": "single",
          "q": "An analysis agent round-trips through the coordinator for 80% of its needs, which are simple unit conversions; the other 20% require complex statistical validation. Round trips add latency. What is the most appropriate design?",
          "o": [
            "Precompute every possible conversion during the initial research phase.",
            "Have the agent batch all conversion and validation requests until the end of its pass.",
            "Give the analysis agent a scoped convert_units tool for the common case while complex validation still routes through the coordinator.",
            "Give the analysis agent every data tool so it never needs to ask the coordinator."
          ],
          "a": [
            2
          ],
          "e": "A constrained cross-role tool for a high-frequency, low-risk need preserves specialization while removing round trips. Granting all tools violates least privilege; batching creates blocking dependencies; speculative precomputation cannot predict every needed conversion."
        },
        {
          "id": "s1q24",
          "d": "D2",
          "t": "2.4",
          "type": "single",
          "q": "Your team wants a shared Jira MCP server available to everyone who clones the repository, authenticated with a personal token that must not enter version control. How should it be configured?",
          "o": [
            "In the project's .mcp.json using environment variable expansion such as ${JIRA_TOKEN}.",
            "In each developer's ~/.claude.json with the token hardcoded for convenience.",
            "In the root CLAUDE.md as a documented command that developers run manually.",
            "In a .env file committed beside .mcp.json so the expansion resolves for all users."
          ],
          "a": [
            0
          ],
          "e": "Project-scoped .mcp.json shares the server configuration through version control while ${JIRA_TOKEN} keeps the secret in each developer's environment. User scope is for personal servers; CLAUDE.md is instructions, not server configuration; committing a .env file leaks credentials."
        },
        {
          "id": "s1q25",
          "d": "D2",
          "t": "2.4",
          "type": "single",
          "q": "A documentation MCP server offers a capable search_docs tool, but the agent keeps using Grep over a vendored docs folder and misses semantic matches. What is the most direct improvement?",
          "o": [
            "Force search_docs with tool_choice on every turn.",
            "Add a system-prompt instruction that says “always prefer MCP tools”.",
            "Enhance the MCP tool description to explain its coverage, outputs and when it outperforms raw content search, and expose the documentation catalog as a resource.",
            "Remove Grep from the agent so the MCP tool is the only option."
          ],
          "a": [
            2
          ],
          "e": "The model needs to understand what the MCP tool knows and returns, and a resource catalog makes available content visible without exploratory calls. Removing built-ins is unnecessarily restrictive; forcing the tool ignores whether it fits each turn; a blanket preference does not explain the tool's value."
        },
        {
          "id": "s1q26",
          "d": "D2",
          "t": "2.5",
          "type": "single",
          "q": "You need to find every place in a large repository where the function refund_order is called, including calls through wrapper modules. Which built-in tool is the right starting point?",
          "o": [
            "Grep for the exported name and for each wrapper alias across file contents.",
            "Bash with a directory listing of each package.",
            "Glob with the pattern **/refund_order*",
            "Read every Python file from the repository root."
          ],
          "a": [
            0
          ],
          "e": "Grep searches file contents for symbols, call sites and error strings. Glob finds paths by name, which misses callers in arbitrary files; reading everything is wasteful; directory listings reveal nothing about usage. Wrapper tracing requires searching exported names and aliases."
        },
        {
          "id": "s1q27",
          "d": "D2",
          "t": "2.5",
          "type": "single",
          "q": "The Edit tool refuses a targeted change because the anchor text appears in three places in the file. You have already inspected the file and know the exact intended change. What is the reliable fallback?",
          "o": [
            "Re-run Edit with the same anchor and hope the correct occurrence is chosen.",
            "Use a shell search-and-replace without checking which occurrences changed.",
            "Delete the file and recreate it from memory.",
            "Read the full file, apply the change to the complete content, and Write the file back."
          ],
          "a": [
            3
          ],
          "e": "Edit relies on a unique match. When the anchor is non-unique, Read plus Write gives full control over the final content. Re-running cannot disambiguate; deleting risks data loss; an unchecked global replace can modify the wrong occurrences."
        },
        {
          "id": "s1q28",
          "d": "D3",
          "t": "3.1",
          "type": "single",
          "q": "A new teammate clones the repository but does not receive the team's coding instructions. The instructions currently live in your ~/.claude/CLAUDE.md. What is the correct fix?",
          "o": [
            "Move the shared instructions into the project-level CLAUDE.md and commit it.",
            "Run /memory on the teammate's machine and accept the defaults.",
            "Add the instructions to a personal skill in ~/.claude/skills/.",
            "Ask the teammate to copy your home-directory file into their own ~/.claude/CLAUDE.md."
          ],
          "a": [
            0
          ],
          "e": "User-level memory applies only to that user and is not shared through version control. Project-level CLAUDE.md is versioned with the repository and loads for everyone. Manual copying is fragile, personal skills are not shared, and /memory diagnoses loaded files rather than distributing them."
        },
        {
          "id": "s1q29",
          "d": "D3",
          "t": "3.1",
          "type": "single",
          "q": "A root CLAUDE.md has grown to 900 lines covering testing, API conventions, deployment and frontend rules. Developers say it is hard to maintain and often irrelevant. What organization is most appropriate?",
          "o": [
            "Split topics into .claude/rules/ files and use @import to pull only the relevant standards into each package.",
            "Convert the file into a custom slash command that developers invoke manually.",
            "Move everything into the user-level CLAUDE.md so it loads faster.",
            "Keep one file but add a table of contents at the top."
          ],
          "a": [
            0
          ],
          "e": "Modular rules keep each topic focused and import only what a package needs. A table of contents does not reduce context; user-level memory removes team sharing; a manually invoked command is not always-loaded project context."
        },
        {
          "id": "s1q30",
          "d": "D3",
          "t": "3.2",
          "type": "single",
          "q": "You want a /review slash command that runs the team's standard review checklist and is available to every developer after cloning the repo. Where should it live?",
          "o": [
            "In .claude/settings.json under a commands array.",
            "In ~/.claude/commands/ on each developer's machine.",
            "Inside the root CLAUDE.md as a bullet list.",
            "In .claude/commands/ inside the project repository."
          ],
          "a": [
            3
          ],
          "e": "Project-scoped custom commands in .claude/commands/ are version-controlled and shared automatically. The home-directory location is personal; CLAUDE.md holds context, not command definitions; there is no commands array in settings.json for this purpose."
        },
        {
          "id": "s1q31",
          "d": "D3",
          "t": "3.2",
          "type": "single",
          "q": "A codebase-analysis skill produces pages of exploration output that pollute the main conversation and crowd out later work. Which skill frontmatter option directly addresses this?",
          "o": [
            "argument-hint",
            "description with trigger keywords",
            "allowed-tools: Read",
            "context: fork"
          ],
          "a": [
            3
          ],
          "e": "context: fork runs the skill in an isolated sub-agent context so its verbose output does not accumulate in the main session. argument-hint prompts for arguments, allowed-tools restricts tools, and descriptions help invocation but do not isolate output."
        },
        {
          "id": "s1q32",
          "d": "D3",
          "t": "3.2",
          "type": "single",
          "q": "A release-notes skill must edit files but must never run shell commands. Which configuration best enforces that boundary?",
          "o": [
            "Set allowed-tools in SKILL.md frontmatter to the file-editing tools only.",
            "Add “do not use Bash” to the skill body.",
            "Use argument-hint to tell the developer which files to pass.",
            "Set context: fork and hope the isolated agent avoids Bash."
          ],
          "a": [
            0
          ],
          "e": "allowed-tools in skill frontmatter restricts the tools available during execution, which is a configuration boundary rather than a suggestion. Prose instructions are probabilistic; forking isolates context but does not limit tools; argument-hint only documents parameters."
        },
        {
          "id": "s1q33",
          "d": "D3",
          "t": "3.3",
          "type": "single",
          "q": "Test files are spread throughout the repository next to the code they test. All of them should receive the same testing conventions, regardless of directory. What is the most maintainable configuration?",
          "o": [
            "A separate CLAUDE.md in every directory that might contain a test.",
            "A testing skill that developers invoke manually before editing each test.",
            "A root CLAUDE.md section titled “Testing” that the model must infer applies.",
            "A .claude/rules/ file with paths: [\"**/*.test.tsx\"] and the testing conventions."
          ],
          "a": [
            3
          ],
          "e": "Path-scoped rules load automatically when matching files are edited and can target file types across directories. Directory CLAUDE.md files cannot cover spread-out tests cleanly; inference is unreliable; manual invocation is not automatic."
        },
        {
          "id": "s1q34",
          "d": "D3",
          "t": "3.3",
          "type": "single",
          "q": "You want Terraform conventions to load only when Claude is working with files under terraform/. What frontmatter should the rule file contain?",
          "o": [
            "alwaysApply: true",
            "description: Terraform conventions",
            "paths: [\"terraform/**/*\"]",
            "globs: terraform"
          ],
          "a": [
            2
          ],
          "e": "Path-specific rules use YAML frontmatter with a paths list of glob patterns. alwaysApply would load them everywhere; a bare directory name is not the documented glob form; a description alone does not scope activation."
        },
        {
          "id": "s1q35",
          "d": "D3",
          "t": "3.4",
          "type": "single",
          "q": "A team must migrate a shared library used by 45 files. There are two viable migration approaches with different infrastructure implications. Which working mode should Claude Code start in?",
          "o": [
            "Direct execution, changing files incrementally to discover the natural approach.",
            "Direct execution with a longer prompt that specifies every file edit upfront.",
            "A single Bash command that rewrites all imports at once.",
            "Plan mode, to explore dependencies and design the approach before committing changes."
          ],
          "a": [
            3
          ],
          "e": "Plan mode is for large-scale, multi-file work with architectural choices and costly rework risk. It supports exploration and design before edits. Incremental direct execution risks discovering dependencies too late; an upfront prompt assumes knowledge; a bulk rewrite is not a migration plan."
        },
        {
          "id": "s1q36",
          "d": "D3",
          "t": "3.4",
          "type": "single",
          "q": "A stack trace points to one function in one file, and the fix is a missing null check. Which execution approach is appropriate?",
          "o": [
            "Plan mode, because every code change should be planned.",
            "Fork the session and compare three fix strategies before editing.",
            "Direct execution of the well-scoped change.",
            "A research subagent followed by a full architecture review."
          ],
          "a": [
            2
          ],
          "e": "Direct execution fits simple, well-understood changes with a clear scope. Plan mode adds overhead when the location and fix are already known; architecture review and multi-branch exploration are disproportionate to a one-line bug fix."
        },
        {
          "id": "s1q37",
          "d": "D3",
          "t": "3.5",
          "type": "single",
          "q": "A data transformation prompt produces inconsistent results: the prose says “normalize phone numbers”, but the model keeps inventing different formats. What is the most effective way to clarify the requirement?",
          "o": [
            "Ask the model to explain its interpretation before every run.",
            "Provide two or three concrete input/output examples that demonstrate the exact transformation.",
            "Repeat the instruction in uppercase and add “this is very important”.",
            "Raise the temperature so the model explores more formatting options."
          ],
          "a": [
            1
          ],
          "e": "Concrete examples communicate transformations more reliably than prose because they resolve ambiguity about edge cases and output shape. Emphasis does not add information; higher temperature increases variance; explanations add cost without pinning the expected output."
        },
        {
          "id": "s1q38",
          "d": "D3",
          "t": "3.5",
          "type": "single",
          "q": "A legacy migration script handles nulls incorrectly in several edge cases. You want progressive, verifiable improvement rather than repeated guessing. Which approach fits best?",
          "o": [
            "Lower the temperature and rerun the same prompt until the output looks better.",
            "List every edge case in one prompt and request a single final version.",
            "Ask for a complete rewrite with no tests, then inspect the diff manually.",
            "Write a test suite covering expected behavior and edge cases, then iterate by sharing specific test failures."
          ],
          "a": [
            3
          ],
          "e": "Tests make the desired behavior executable and give the model precise failure feedback for each iteration. A rewrite without tests provides no signal; a one-shot prompt hides unresolved cases; rerunning with lower temperature does not supply missing requirements."
        },
        {
          "id": "s1q39",
          "d": "D3",
          "t": "3.6",
          "type": "single",
          "q": "A CI job runs `claude \"Analyze this pull request for security issues\"` and hangs indefinitely waiting for input. What is the correct fix?",
          "o": [
            "Set CLAUDE_HEADLESS=true before invoking the command.",
            "Add a --batch flag to put Claude Code into pipeline mode.",
            "Use the -p (or --print) flag to run Claude Code non-interactively.",
            "Redirect stdin from /dev/null and keep the same command."
          ],
          "a": [
            2
          ],
          "e": "The -p/--print flag is the documented non-interactive mode: it processes the prompt, writes the result, and exits without waiting for user input. The environment variable and --batch flag are not the documented mechanism; redirecting stdin is a workaround, not proper CLI usage."
        },
        {
          "id": "s1q40",
          "d": "D4",
          "t": "4.1",
          "type": "single",
          "q": "An automated reviewer flags many minor style preferences and comments on unchanged lines. Developers are starting to ignore all of its findings, including real bugs. What change best restores precision?",
          "o": [
            "Define explicit categorical criteria for what to report and what to skip, with concrete severity examples.",
            "Reduce the number of files reviewed per pull request.",
            "Add “be conservative and only report high-confidence findings” to the prompt.",
            "Lower the model temperature to make the review more deterministic."
          ],
          "a": [
            0
          ],
          "e": "Precision improves when the prompt defines categories to report and skip, rather than relying on vague confidence language. Reviewing fewer files may hide bugs; “be conservative” is explicitly noted as ineffective; determinism does not improve relevance."
        },
        {
          "id": "s1q41",
          "d": "D4",
          "t": "4.1",
          "type": "multi",
          "n": 2,
          "q": "One review category produces many false positives and is damaging trust in the reviewer's accurate categories. Which two actions are most appropriate? (Select two.)",
          "o": [
            "Define concrete, categorical criteria and examples for what should and should not be reported.",
            "Add “only report high-confidence findings” to every prompt.",
            "Temporarily disable that high-false-positive category while its prompt is improved.",
            "Ask developers to mentally discount findings from that category."
          ],
          "a": [
            0,
            2
          ],
          "e": "Removing a noisy category protects trust while targeted criteria and examples address its precision. Expecting developers to discount findings does not fix the system; confidence-based filtering is explicitly weaker than categorical criteria."
        },
        {
          "id": "s1q42",
          "d": "D4",
          "t": "4.2",
          "type": "single",
          "q": "Reviewers classify similar defects as “minor” in one file and “critical” in another. Detailed instructions have not produced consistency. What is the most effective next step?",
          "o": [
            "Provide two to four few-shot examples for each severity level, including the reasoning for the classification.",
            "Increase the size of the review prompt with more adjectives about importance.",
            "Remove severity labels and let developers decide.",
            "Ask the model to sort findings alphabetically before assigning severity."
          ],
          "a": [
            0
          ],
          "e": "Few-shot examples anchor judgment and demonstrate how to generalize ambiguous cases to new code. Alphabetical ordering and stronger adjectives add no decision rule; removing severity shifts the problem to developers."
        },
        {
          "id": "s1q43",
          "d": "D4",
          "t": "4.2",
          "type": "single",
          "q": "An invoice extractor works on standard invoices but returns empty values for documents with inline citations, tables or informal measurements. What intervention is most likely to improve consistency?",
          "o": [
            "Add few-shot examples showing correct extraction from each of the varied document layouts, including null handling.",
            "Make every schema field required so the model must return something.",
            "Switch to a model with a larger context window.",
            "Retry the same extraction until the fields are populated."
          ],
          "a": [
            0
          ],
          "e": "Few-shot examples demonstrate how to handle structural variety and reduce hallucination or empty extraction. Requiring fields encourages fabrication; blind retries cannot create information the model does not know how to locate; a larger window does not teach layout handling."
        },
        {
          "id": "s1q44",
          "d": "D4",
          "t": "4.3",
          "type": "single",
          "q": "A downstream service requires syntactically valid JSON that matches an exact schema. Which approach most reliably guarantees compliance?",
          "o": [
            "Instruct the model to “respond only with JSON” and validate afterward.",
            "Use a low temperature and a detailed prose description of the schema.",
            "Define an extraction tool whose input schema is the JSON schema, then read the structured tool_use input.",
            "Ask for JSON inside a Markdown code fence and strip the fence."
          ],
          "a": [
            2
          ],
          "e": "Tool use with a JSON schema constrains output structure at generation time and eliminates JSON syntax errors. Prompt-only JSON, fenced blocks and low temperature remain probabilistic and still require parsing and repair; they do not guarantee the schema."
        },
        {
          "id": "s1q45",
          "d": "D4",
          "t": "4.3",
          "type": "single",
          "q": "A pipeline receives several document types and has one extraction schema per type, but the type is unknown until the document is read. You need guaranteed structured output without knowing which schema applies. Which tool_choice setting fits?",
          "o": [
            "No tool_choice, because schemas are only advisory.",
            "\"auto\" so the model can answer in prose when it is unsure.",
            "A forced selection of the most common extraction tool.",
            "\"any\" so the model must call one of the extraction tools but may choose which."
          ],
          "a": [
            3
          ],
          "e": "tool_choice “any” requires a tool call while letting the model select the appropriate schema after reading the document. “auto” permits a text response and breaks the guarantee; forcing the most common tool misclassifies rare types; omitting tool_choice provides no enforcement."
        },
        {
          "id": "s1q46",
          "d": "D4",
          "t": "4.4",
          "type": "single",
          "q": "A structured extraction passes schema validation but fails business validation because line items do not sum to the stated total. What retry design is most likely to correct this?",
          "o": [
            "Resend the document with no explanation and ask for a better extraction.",
            "Send the original document, the failed extraction, and the specific validation error so the model can self-correct.",
            "Increase the retry count until the totals happen to match.",
            "Drop the validation rule and accept the output as-is."
          ],
          "a": [
            1
          ],
          "e": "Retry-with-error-feedback gives the model the evidence and the precise discrepancy to correct. A blind retry lacks signal, repeated guessing is wasteful, and ignoring the rule pushes bad data downstream."
        },
        {
          "id": "s1q47",
          "d": "D4",
          "t": "4.4",
          "type": "single",
          "q": "An extractor keeps retrying a required field that is genuinely absent because the value exists only in a separate appendix that was never provided. What is the correct interpretation?",
          "o": [
            "Retries cannot recover information that is absent from the source; provide the appendix or mark the field unavailable.",
            "The retry limit should be increased because persistence usually works.",
            "The schema should make the field required so the model tries harder.",
            "A higher temperature will help the model infer the missing value."
          ],
          "a": [
            0
          ],
          "e": "Retries fix format and structural errors, not missing evidence. The system should supply the external document or return an explicit unavailable value. Requiring the field encourages fabrication; temperature and more retries cannot create source data."
        },
        {
          "id": "s1q48",
          "d": "D4",
          "t": "4.5",
          "type": "single",
          "q": "A team wants to cut API cost by moving two workflows to the Message Batches API: a blocking pre-merge security check and an overnight technical-debt report. How should they proceed?",
          "o": [
            "Keep both synchronous because batch results cannot be correlated to requests.",
            "Use batch processing for the overnight report only; keep synchronous calls for the pre-merge check.",
            "Move both to batch processing and rely on batches usually finishing quickly.",
            "Move both to batch processing with a real-time fallback after five minutes."
          ],
          "a": [
            1
          ],
          "e": "Batches offer 50% savings but can take up to 24 hours with no latency SLA, so they fit latency-tolerant overnight work, not blocking checks. custom_id correlates batch requests. A fallback adds complexity when the correct fix is matching each workflow to its latency requirement."
        },
        {
          "id": "s1q49",
          "d": "D4",
          "t": "4.5",
          "type": "single",
          "q": "A nightly batch of 5,000 documents completes with 120 failures, mostly oversized files and a few malformed requests. What is the most efficient recovery?",
          "o": [
            "Resubmit the entire 5,000-document batch unchanged.",
            "Use custom_id to identify the failed requests, chunk oversized documents, and resubmit only the failures.",
            "Ignore the failures because 97.6% of the batch succeeded.",
            "Abandon the batch and process all 5,000 documents synchronously."
          ],
          "a": [
            1
          ],
          "e": "custom_id maps responses back to inputs, enabling targeted recovery. Only failures need modification and resubmission, which minimizes cost and time. Resubmitting everything repeats successful work; switching all to synchronous calls is expensive; ignoring failures leaves gaps."
        },
        {
          "id": "s1q50",
          "d": "D4",
          "t": "4.6",
          "type": "single",
          "q": "A model generates a patch and then reviews it in the same session. It consistently misses a subtle authorization bug in its own change. What is the most effective review change?",
          "o": [
            "Ask the same session to review the patch three times with extended thinking.",
            "Send the patch to an independent Claude instance that did not produce the code or its reasoning context.",
            "Increase the model's temperature during self-review to encourage skepticism.",
            "Instruct the generator to review more carefully and double-check its reasoning."
          ],
          "a": [
            1
          ],
          "e": "Self-review retains the generator's reasoning and commitments, making it less likely to question its own decisions. An independent instance sees only the artifact and can catch issues the generator rationalized away. Stronger instructions, repeated self-review or higher temperature do not remove that anchor."
        },
        {
          "id": "s1q51",
          "d": "D4",
          "t": "4.6",
          "type": "single",
          "q": "A high-stakes review produces findings but limited reviewer capacity. You want to route only uncertain findings to humans. Which architecture is most appropriate?",
          "o": [
            "Run the same review three times and send only unanimous findings to humans.",
            "Ask developers to review every finding because model confidence is never useful.",
            "Have the generating model label each finding as certain or uncertain.",
            "Run a separate verification pass that reports per-finding confidence and evidence, then route low-confidence findings to humans."
          ],
          "a": [
            3
          ],
          "e": "A verification pass that reports calibrated confidence alongside evidence supports targeted routing. The generator's own certainty is poorly calibrated; consensus among repeated runs does not measure correctness; reviewing everything ignores the capacity constraint."
        },
        {
          "id": "s1q52",
          "d": "D5",
          "t": "5.1",
          "type": "single",
          "q": "A long support conversation is repeatedly summarized. The agent eventually forgets the refund amount, order number and the customer's stated deadline, even though the prose summary sounds coherent. What is the best mitigation?",
          "o": [
            "Delete older turns so the model focuses on the latest message.",
            "Maintain a persistent case-facts block with amounts, dates, order IDs and statuses outside the summarized history.",
            "Increase the model temperature so it reconstructs missing facts.",
            "Rely on progressive summarization but ask it to preserve “important details”."
          ],
          "a": [
            1
          ],
          "e": "Summaries tend to blur exact values and expectations. A structured facts block preserves transactional details across turns and can be injected into every prompt. Vaguer summarization instructions are unreliable; temperature cannot recover facts; deleting history loses context."
        },
        {
          "id": "s1q53",
          "d": "D5",
          "t": "5.1",
          "type": "single",
          "q": "An order-lookup tool returns 40 fields, but the returns workflow only needs five. Across a long session these results consume most of the context window. What should you do?",
          "o": [
            "Stop appending tool results and let the model remember the previous response.",
            "Switch to a model with a larger context window and keep every field.",
            "Trim each tool result to the relevant fields before appending it to conversation context.",
            "Ask the model to summarize each result after it has already been appended."
          ],
          "a": [
            2
          ],
          "e": "Tool output should be reduced at the boundary where relevance is known. Trimming before accumulation prevents waste. Summarizing after appending still pays the token cost; omitting results breaks reasoning; a bigger window postpones rather than fixes context bloat."
        },
        {
          "id": "s1q54",
          "d": "D5",
          "t": "5.2",
          "type": "multi",
          "n": 2,
          "q": "Which two situations are appropriate triggers to escalate a customer-support case? (Select two.)",
          "o": [
            "The customer explicitly asks to speak with a human.",
            "The request requires a policy exception, or the policy is silent on the request.",
            "The agent's self-reported confidence score is below 6 out of 10.",
            "The customer's message contains strongly negative sentiment."
          ],
          "a": [
            0,
            1
          ],
          "e": "Explicit requests and genuine policy gaps or ambiguity are sound escalation triggers. Sentiment does not correlate with case complexity, and self-reported confidence is poorly calibrated; both are explicitly unreliable proxies."
        },
        {
          "id": "s1q55",
          "d": "D5",
          "t": "5.2",
          "type": "single",
          "q": "get_customer returns three plausible matches for a common name. The agent is about to choose the most recently active account and process a refund. What should it do instead?",
          "o": [
            "Merge the three accounts so the refund reaches the right one.",
            "Ask the customer for an additional identifier and resolve the ambiguity before proceeding.",
            "Select the account with the highest lifetime value because that is usually the right customer.",
            "Use the customer's geolocation to eliminate two of the matches."
          ],
          "a": [
            1
          ],
          "e": "Multiple matches require clarification, not a heuristic guess. Recency, value, geolocation and account merging all risk acting on the wrong person or corrupting records. The agent should pause the financial action until identity is unambiguous."
        },
        {
          "id": "s1q56",
          "d": "D5",
          "t": "5.3",
          "type": "single",
          "q": "A subagent times out and returns only “search unavailable” to the coordinator. The coordinator cannot decide whether to retry, switch sources or proceed with partial data. What is the root cause?",
          "o": [
            "The workflow needs a larger context window to hold the failed request.",
            "The coordinator does not have enough tools to perform the search itself.",
            "The error lacks structured context such as failure type, attempted query, partial results and alternatives.",
            "The subagent should have suppressed the error and returned an empty list."
          ],
          "a": [
            2
          ],
          "e": "Recovery decisions require actionable error context. A generic status hides what happened and prevents informed retry or fallback. More coordinator tools, suppressed errors or a larger window do not supply the missing diagnostic information."
        },
        {
          "id": "s1q57",
          "d": "D5",
          "t": "5.3",
          "type": "single",
          "q": "One source in a multi-source research run is unavailable, but the other sources support a useful report. How should the final synthesis represent this?",
          "o": [
            "Omit any mention of the unavailable source so the report appears complete.",
            "Fill the gap with the model's general knowledge and label it as analysis.",
            "Terminate the workflow because a complete report is impossible.",
            "Include coverage annotations identifying which findings are well-supported and which topic areas have gaps."
          ],
          "a": [
            3
          ],
          "e": "Coverage annotations preserve transparency and let readers judge confidence. Hiding the gap misrepresents completeness; substituting unsourced general knowledge undermines provenance; terminating discards valid partial results."
        },
        {
          "id": "s1q58",
          "d": "D5",
          "t": "5.4",
          "type": "single",
          "q": "After a long codebase exploration, the agent starts saying “this follows the typical pattern” instead of naming the classes it discovered earlier. Which intervention best counters this degradation?",
          "o": [
            "Have the agent maintain a scratchpad of key findings and consult it for later questions.",
            "Start a new session with no summary and re-read every file.",
            "Raise the temperature so the agent generates more specific language.",
            "Ask the agent to keep the entire repository in its context window."
          ],
          "a": [
            0
          ],
          "e": "A scratchpad externalizes verified findings across context boundaries and gives later turns a source of specific facts. Restarting without memory loses work; temperature does not restore recall; keeping everything in context is exactly what is degrading."
        },
        {
          "id": "s1q59",
          "d": "D5",
          "t": "5.5",
          "type": "single",
          "q": "An extraction pipeline reports 97% aggregate accuracy. The team wants to reduce human review from 20% to 5%. What should they do first?",
          "o": [
            "Remove review entirely for the most common document type.",
            "Trust the aggregate metric and reduce review immediately.",
            "Measure accuracy by document type and field, and run stratified sampling on high-confidence extractions before changing the threshold.",
            "Review only documents the model marks as low confidence."
          ],
          "a": [
            2
          ],
          "e": "Aggregate accuracy can hide weak segments. Segment-level accuracy and stratified sampling of supposedly high-confidence output reveal novel error patterns before review capacity is reduced. Low-confidence routing alone can miss confident errors; removing review by type ignores segment risk."
        },
        {
          "id": "s1q60",
          "d": "D5",
          "t": "5.6",
          "type": "single",
          "q": "Two credible sources report different market-growth figures for the same year. The synthesis agent must combine them into one report. What is the correct handling?",
          "o": [
            "Select the newer-looking figure and omit the other to keep the report consistent.",
            "Average the two figures and present the result as a single fact.",
            "Exclude both findings because conflicting sources are unusable.",
            "Preserve both values with source attribution and annotate the conflict, distinguishing well-established findings from contested ones."
          ],
          "a": [
            3
          ],
          "e": "Synthesis must preserve claim-source mappings and surface conflicts rather than silently choosing or averaging. Attribution lets the coordinator or reader reconcile the difference. Omitting or excluding data loses information; averaging invents a statistic."
        }
      ]
    },
    {
      "id": 2,
      "title": "Production failure modes",
      "blurb": "Heavier on orchestration edge cases, error semantics, CI review passes and context budgeting. Different scenarios, same blueprint.",
      "mode": "mixed",
      "questions": [
        {
          "id": "s2q01",
          "d": "D1",
          "t": "1.1",
          "type": "single",
          "q": "An agent loop executes a tool but appends the result as ordinary assistant text. On the next iteration the model calls the same tool again with identical arguments. What is the correct fix?",
          "o": [
            "Convert the tool into an MCP server so its results are cached.",
            "Raise the iteration cap so the agent has more chances to finish.",
            "Append the tool output as a tool_result block tied to the tool_use ID, then continue the loop.",
            "Add a system-prompt instruction telling the model not to repeat tool calls."
          ],
          "a": [
            2
          ],
          "e": "The model needs a properly linked tool_result containing the tool_use ID to incorporate the result. Text that merely mentions the output does not close the tool-use turn, so the model repeats its request. Prompting, iteration caps and MCP caching do not repair the message structure."
        },
        {
          "id": "s2q02",
          "d": "D1",
          "t": "1.1",
          "type": "single",
          "q": "A complex invoice workflow sometimes stops after 12 tool calls because the loop breaks on a hard-coded iteration cap. Most runs finish in 5–7 calls. What is the best control-flow change?",
          "o": [
            "Increase the cap to 30 and keep it as the primary termination mechanism.",
            "Remove the cap entirely and rely on the model to stop eventually.",
            "Check whether the assistant's last message contains “done” and break when it does.",
            "Terminate based on stop_reason, using a generous safety cap only as a last-resort guard against runaway loops."
          ],
          "a": [
            3
          ],
          "e": "The semantic stop signal is stop_reason (“end_turn”), not an arbitrary count. A high safety cap can exist as a guard, but it must not be the primary stopping rule. Removing all bounds risks runaway loops, and keyword checks are explicitly fragile anti-patterns."
        },
        {
          "id": "s2q03",
          "d": "D1",
          "t": "1.2",
          "type": "single",
          "q": "A coordinator sends a short instruction to the synthesis subagent: “Use the research from the other agents.” The synthesis output is generic and omits most findings. Why?",
          "o": [
            "The synthesis model is too small to understand the instruction.",
            "The synthesis agent needs access to all search tools to reconstruct the findings.",
            "Subagents have isolated context and do not inherit the coordinator's conversation or other agents' outputs automatically.",
            "The coordinator should have used an MCP resource instead of a subagent."
          ],
          "a": [
            2
          ],
          "e": "Subagents start with isolated context; the coordinator must explicitly include the complete findings and metadata in the synthesis prompt. Model size is not the stated issue, MCP resources are a different mechanism, and re-searching is wasteful when findings already exist."
        },
        {
          "id": "s2q04",
          "d": "D1",
          "t": "1.2",
          "type": "single",
          "q": "The coordinator evaluates a synthesis report and finds that two important subtopics are thinly supported. What should the coordinator do next?",
          "o": [
            "Accept the report because all subagents completed successfully.",
            "Ask the synthesis agent to “try harder” with the same findings.",
            "Restart the entire pipeline from the original broad query.",
            "Re-delegate targeted queries to the search and analysis agents, then re-invoke synthesis with the new evidence."
          ],
          "a": [
            3
          ],
          "e": "The coordinator owns iterative refinement: evaluate coverage, identify gaps, re-delegate targeted work, and re-synthesize. Accepting the report leaves gaps; repeating synthesis without new evidence cannot improve coverage; a full restart wastes valid work."
        },
        {
          "id": "s2q05",
          "d": "D1",
          "t": "1.3",
          "type": "single",
          "q": "A coordinator is configured with tools for search, analysis and reporting, but every attempt to spawn a subagent fails. The coordinator's allowedTools list does not include “Task”. What is the fix?",
          "o": [
            "Give the coordinator the subagents' system prompts directly.",
            "Add “Task” to the coordinator's allowedTools so it can spawn subagents.",
            "Enable shared memory between the coordinator and subagents.",
            "Convert each subagent into a built-in Bash command."
          ],
          "a": [
            1
          ],
          "e": "The Task tool is the mechanism for spawning subagents, and it must be allowed for the coordinator. System prompts alone do not create invocations; shell commands and shared memory are unrelated to the missing capability."
        },
        {
          "id": "s2q06",
          "d": "D1",
          "t": "1.3",
          "type": "multi",
          "n": 2,
          "q": "A search subagent begins editing repository files even though its role is only to find sources. The coordinator passes one general system prompt to every subagent. Which two changes in the subagent's AgentDefinition best enforce its role? (Select two.)",
          "o": [
            "A restricted tool set that excludes file-editing tools.",
            "A role-specific system prompt that states the search-only responsibility.",
            "A larger context window so the agent understands its role.",
            "A shared conversation history inherited from the coordinator."
          ],
          "a": [
            0,
            1
          ],
          "e": "AgentDefinition carries a description, system prompt and tool restrictions. A role prompt plus restricted tools enforces behavior rather than relying on a global instruction. Shared history is not automatic, and a larger window does not restrict what the agent can do."
        },
        {
          "id": "s2q07",
          "d": "D1",
          "t": "1.3",
          "type": "single",
          "q": "A coordinator passes only the latest search result to the synthesis agent. Sources found by earlier subagent runs disappear from the final citations. What should the coordinator pass?",
          "o": [
            "A link to the coordinator's conversation history so synthesis can look up earlier turns.",
            "A request for synthesis to search the web again for any missing citations.",
            "Only the final answer from each subagent, with URLs removed to reduce tokens.",
            "The complete structured findings from all prior agents, including content and source metadata."
          ],
          "a": [
            3
          ],
          "e": "Synthesis needs all relevant findings, not just the latest, and attribution metadata must travel with them. Subagents cannot inspect the coordinator's history; re-searching duplicates work; stripping URLs destroys provenance."
        },
        {
          "id": "s2q08",
          "d": "D1",
          "t": "1.4",
          "type": "single",
          "q": "A lending workflow must run a sanctions screening before an application can be approved. The agent occasionally approves first and screens afterward. The business requires guaranteed ordering. What should be implemented?",
          "o": [
            "A programmatic prerequisite that blocks the approval tool until a successful screening record exists.",
            "A system prompt that lists the required steps in capital letters.",
            "A dashboard that alerts managers when the order is wrong.",
            "A few-shot example showing the correct order in three applications."
          ],
          "a": [
            0
          ],
          "e": "Guaranteed ordering for a regulated step requires deterministic enforcement. A gate tied to a screening record prevents approval regardless of model behavior. Prompting and examples are probabilistic; after-the-fact alerts do not prevent the violation."
        },
        {
          "id": "s2q09",
          "d": "D1",
          "t": "1.4",
          "type": "single",
          "q": "A customer changes their delivery address while a replacement is already in progress. The agent restarts the entire case, re-verifies identity and re-opens the replacement, creating a duplicate shipment. What handoff/workflow design would prevent this?",
          "o": [
            "Increase the model's context window so it remembers the first request.",
            "Escalate every address change to a human because workflow state is too complex.",
            "Ask the customer to close the first case and open a new one.",
            "Carry forward completed steps and pass a structured case state with what is done, what is pending and the relevant IDs."
          ],
          "a": [
            3
          ],
          "e": "Multi-step workflows need explicit state so completed steps are not repeated. A structured case state preserves progress and pending actions across the change. Escalating everything is disproportionate; forcing a new case loses continuity; a bigger window does not guarantee state tracking."
        },
        {
          "id": "s2q10",
          "d": "D1",
          "t": "1.5",
          "type": "single",
          "q": "Tool results sometimes contain full customer email addresses and card fragments. Policy requires that the model never see the raw values. Where should redaction occur?",
          "o": [
            "In a downstream report filter after the model has produced an answer.",
            "In a PostToolUse hook that redacts the fields before the result enters model context.",
            "In the system prompt, instructing the model to ignore sensitive fields.",
            "In the user-facing UI, replacing sensitive strings before display."
          ],
          "a": [
            1
          ],
          "e": "A PostToolUse hook can transform tool output before the model processes it, which is the deterministic control point for preventing exposure. Prompt instructions do not guarantee redaction; downstream filters act too late; UI masking does not stop the model from seeing the data."
        },
        {
          "id": "s2q11",
          "d": "D1",
          "t": "1.5",
          "type": "single",
          "q": "A browsing tool must never fetch domains outside an approved allowlist. The agent has occasionally ignored prompt instructions and fetched unapproved URLs. What control is appropriate?",
          "o": [
            "A monitoring alert that notifies security after an unapproved fetch.",
            "A tool-call interception hook that rejects any URL not on the allowlist before execution.",
            "A prompt that says “only use approved domains” and lists examples.",
            "A post-processing step that removes unapproved URLs from the final answer."
          ],
          "a": [
            1
          ],
          "e": "Blocking at the tool boundary prevents the unsafe action itself. Prompt guidance is probabilistic; removing URLs after the fetch still exposes the system; alerting detects but does not enforce the policy."
        },
        {
          "id": "s2q12",
          "d": "D1",
          "t": "1.6",
          "type": "single",
          "q": "A test-generation workflow always follows the same stages: inventory modules, generate unit tests per module, then generate integration tests. The stages and their order are predictable. Which decomposition pattern fits?",
          "o": [
            "Fully dynamic decomposition where each run discovers a new stage order.",
            "A coordinator that randomly selects one specialist per run.",
            "A single prompt asking for every test at once with no staging.",
            "Prompt chaining with fixed sequential stages, passing each stage's output forward."
          ],
          "a": [
            3
          ],
          "e": "Predictable multi-stage work benefits from prompt chaining: each stage has a clear input and output and feeds the next. Dynamic decomposition is for open-ended discovery; one giant prompt dilutes attention; random specialist selection abandons the known process."
        },
        {
          "id": "s2q13",
          "d": "D1",
          "t": "1.6",
          "type": "single",
          "q": "You must diagnose a production incident in an unfamiliar service. The next investigation step depends on what the logs and dependency graph reveal. Which approach is most appropriate?",
          "o": [
            "Ask the model to produce the final root cause from the incident title alone.",
            "Read every source file in the repository before forming any hypothesis.",
            "An adaptive investigation plan that generates subtasks based on each intermediate finding.",
            "A fixed five-step checklist chosen before looking at any evidence."
          ],
          "a": [
            2
          ],
          "e": "Open-ended investigation benefits from adaptive decomposition: evidence determines the next question. A pre-set checklist may miss the actual failure path; reading everything is wasteful; answering from the title is not investigation."
        },
        {
          "id": "s2q14",
          "d": "D1",
          "t": "1.6",
          "type": "single",
          "q": "A security audit covers 60 microservices. Reviewers need both service-local issues and vulnerabilities that cross trust boundaries. How should the work be split?",
          "o": [
            "A per-service local analysis pass, followed by a separate cross-service integration pass focused on trust boundaries and data flow.",
            "Randomly assign each service to one of three reviewers and merge the prose.",
            "Only per-service passes, because cross-service analysis is impossible.",
            "One pass over all services so the model sees the whole system at once."
          ],
          "a": [
            0
          ],
          "e": "Local and cross-cutting concerns need different scopes. Per-service passes preserve depth; a dedicated integration pass examines flows that no single service review can see. One giant pass dilutes attention, per-service only misses integration risks, and random prose merging is not analysis."
        },
        {
          "id": "s2q15",
          "d": "D1",
          "t": "1.7",
          "type": "single",
          "q": "You want to continue a named investigation tomorrow without losing its prior conclusions. Which command behavior fits?",
          "o": [
            "Use --resume with the named session to continue that specific prior conversation.",
            "Use fork_session and discard the original branch immediately.",
            "Start an unrelated session and paste the old final answer only.",
            "Create a new subagent and assume it inherits the old session's memory."
          ],
          "a": [
            0
          ],
          "e": "Named session resumption continues the intended conversation with its context intact. Pasting only the final answer loses evidence and reasoning; forking is for divergent branches; subagents do not automatically inherit parent or prior session context."
        },
        {
          "id": "s2q16",
          "d": "D1",
          "t": "1.7",
          "type": "single",
          "q": "After a shared analysis baseline, you want to explore two competing database migration plans independently, then compare them. Which approach preserves the baseline while preventing cross-contamination?",
          "o": [
            "Start two new sessions with no baseline and ask each to rediscover the schema.",
            "Run both plans in the same context and ask the model to keep them separate.",
            "Run plan A to completion, then ask the same session to undo it and run plan B.",
            "Use fork_session twice from the baseline so each branch explores one plan independently."
          ],
          "a": [
            3
          ],
          "e": "Forking creates independent branches from a common baseline, which is ideal for comparing alternatives. Sequential undo contaminates the context and may leave artifacts; rediscovery loses the baseline; asking one context to segregate two plans invites confusion."
        },
        {
          "id": "s2q17",
          "d": "D2",
          "t": "2.1",
          "type": "single",
          "q": "The system prompt contains “Always analyze content before responding.” The agent now calls analyze_content even for order-status questions that need lookup_order. Both tools have clear descriptions. What is the best diagnosis and fix?",
          "o": [
            "A keyword-sensitive system-prompt instruction is overriding the tool descriptions; remove or rewrite the instruction.",
            "Merge both tools into analyze_content so the instruction is always correct.",
            "The lookup_order description is still too short; expand it further.",
            "The model needs a higher temperature to explore other tools."
          ],
          "a": [
            0
          ],
          "e": "System-prompt wording can create unintended tool associations that overpower otherwise good descriptions. The instruction is the root cause, so it should be removed or scoped. Expanding an already-clear description, changing temperature, or merging tools does not address the override."
        },
        {
          "id": "s2q18",
          "d": "D2",
          "t": "2.1",
          "type": "single",
          "q": "An extract_metadata tool description says only “Extracts metadata.” The agent often omits the `currency` and `effective_date` outputs, then downstream code fails. What description change is most useful?",
          "o": [
            "Add a second tool with the same description and let the model choose.",
            "Rename the tool to extract_all_metadata.",
            "List the exact output fields, their formats, example inputs and boundary cases where fields may be absent.",
            "Add the phrase “be thorough” to the end of the description."
          ],
          "a": [
            2
          ],
          "e": "The description is the model's contract for when and how to use a tool. Documenting outputs, formats, examples and absent-field behavior makes the contract usable. “Be thorough” adds no information; renaming does not define outputs; a duplicate tool worsens ambiguity."
        },
        {
          "id": "s2q19",
          "d": "D2",
          "t": "2.2",
          "type": "multi",
          "n": 2,
          "q": "A refund tool rejects a request because the order is outside the 30-day policy. The agent retries four times, then invents an exception. Which two response elements best guide the agent? (Select two.)",
          "o": [
            "A raw stack trace with no policy context.",
            "A transient error flag so the agent retries with the same input.",
            "A customer-friendly policy explanation that the agent can relay.",
            "errorCategory set to a business error and isRetryable set to false."
          ],
          "a": [
            2,
            3
          ],
          "e": "A policy rejection is a non-retryable business error, and a plain-language explanation lets the agent communicate the outcome. Retrying cannot change policy, and a stack trace does not tell the agent what to say or do next."
        },
        {
          "id": "s2q20",
          "d": "D2",
          "t": "2.2",
          "type": "single",
          "q": "An MCP tool returns a permission error because the service account lacks access to a billing table. Which metadata best guides the agent?",
          "o": [
            "errorCategory: transient, isRetryable: true, with a request to retry immediately.",
            "A generic error string with no category so the agent stays flexible.",
            "errorCategory: permission, isRetryable: false, with the missing scope and an escalation path.",
            "An empty successful result with a note to try a different question."
          ],
          "a": [
            2
          ],
          "e": "A permission error needs a non-retryable classification plus the missing access and an escalation route. Retrying without new credentials cannot succeed; generic errors hide the cause; empty success misrepresents an access failure as a valid no-match."
        },
        {
          "id": "s2q21",
          "d": "D2",
          "t": "2.3",
          "type": "single",
          "q": "An extraction pipeline must always capture document metadata before any enrichment tool runs, but the model sometimes begins with enrichment. How can the first step be guaranteed?",
          "o": [
            "Set tool_choice to a forced selection of extract_metadata on the first turn, then continue processing in follow-up turns.",
            "Give the enrichment tool a longer description that mentions metadata.",
            "Set tool_choice to “auto” and mention metadata first in the prompt.",
            "Put all tools behind one generic tool with an internal ordering rule."
          ],
          "a": [
            0
          ],
          "e": "A forced tool selection guarantees the specific first call. Follow-up turns can then use the extracted metadata for enrichment. “auto” permits the model to skip the required first tool; description changes and a generic wrapper do not enforce ordering."
        },
        {
          "id": "s2q22",
          "d": "D2",
          "t": "2.3",
          "type": "single",
          "q": "A document workflow expects the model to call one of several extraction tools, but on some inputs it answers in prose instead. You do not know the document type in advance. Which tool_choice setting guarantees a tool call?",
          "o": [
            "\"auto\"",
            "\"none\"",
            "A forced selection of the first extraction tool",
            "\"any\""
          ],
          "a": [
            3
          ],
          "e": "“any” requires the model to call a tool while letting it choose the appropriate one. “auto” permits text, “none” forbids tools, and forcing the first tool misclassifies other document types."
        },
        {
          "id": "s2q23",
          "d": "D2",
          "t": "2.3",
          "type": "single",
          "q": "A general fetch_url tool lets the agent retrieve any URL, including non-document pages that derail analysis. Most use cases only need to load approved documents. What change best constrains behavior?",
          "o": [
            "Keep fetch_url but add a warning label to its description.",
            "Replace fetch_url with a load_document tool that accepts and validates document URLs.",
            "Add “only fetch documents” to the system prompt.",
            "Remove all URL-related tools and rely on the model's prior knowledge."
          ],
          "a": [
            1
          ],
          "e": "Replacing a generic tool with a constrained alternative makes the valid input space explicit and rejects invalid URLs by construction. Prompt guidance and warning labels remain advisory; removing retrieval entirely loses needed capability."
        },
        {
          "id": "s2q24",
          "d": "D2",
          "t": "2.4",
          "type": "single",
          "q": "A developer wants a personal experimental MCP server available in every Claude Code project on their machine, without sharing it with teammates. Where should it be configured?",
          "o": [
            "In .claude/settings.json under a globalServers key.",
            "In ~/.claude.json for user-scoped access across projects.",
            "In each project's .mcp.json so it travels with the repository.",
            "In the root CLAUDE.md as a documented setup step."
          ],
          "a": [
            1
          ],
          "e": "User-scoped configuration in ~/.claude.json is for personal or experimental servers available across projects. Project .mcp.json is shared team tooling; CLAUDE.md is instructions; there is no globalServers key for this purpose."
        },
        {
          "id": "s2q25",
          "d": "D2",
          "t": "2.4",
          "type": "single",
          "q": "An agent repeatedly calls exploratory MCP tools to discover what tables and columns a data warehouse contains. This consumes many turns. What design would reduce that exploration?",
          "o": [
            "Give the agent a tool that returns every row from every table.",
            "Add more exploratory tools with overlapping descriptions.",
            "Expose the database schema as an MCP resource that the agent can read as a content catalog.",
            "Disable the exploratory tools so the agent must guess the schema."
          ],
          "a": [
            2
          ],
          "e": "MCP resources expose catalogs such as schemas, issue summaries or documentation hierarchies without requiring a sequence of exploratory calls. Dumping rows is excessive and unsafe; guessing is unreliable; more overlapping tools worsen selection."
        },
        {
          "id": "s2q26",
          "d": "D2",
          "t": "2.5",
          "type": "single",
          "q": "You need every TypeScript test file in a monorepo, regardless of package location. Which built-in tool and pattern should you use?",
          "o": [
            "Read the root package.json and infer the test paths.",
            "Bash with ls on each package directory.",
            "Grep for the text “test” in all files.",
            "Glob with **/*.test.tsx."
          ],
          "a": [
            3
          ],
          "e": "Glob matches file paths by name and extension pattern, exactly what is needed for **/*.test.tsx. Grep searches contents and would include non-test files; package metadata may not enumerate files; directory listings miss nested paths."
        },
        {
          "id": "s2q27",
          "d": "D2",
          "t": "2.5",
          "type": "single",
          "q": "In an unfamiliar 400-file codebase, you must trace how a refund flows from an HTTP route to the database. What is the most effective built-in-tool strategy?",
          "o": [
            "Use Bash to print every file containing the word “refund” in full.",
            "Start with Grep to find route and refund entry points, then Read the files along the imports and call chain.",
            "Glob for every file, then read only the largest ones.",
            "Read all 400 files upfront so nothing is missed."
          ],
          "a": [
            1
          ],
          "e": "Incremental understanding starts from entry points and follows references, keeping context focused. Reading everything or dumping every match overwhelms the window; file size is unrelated to relevance."
        },
        {
          "id": "s2q28",
          "d": "D3",
          "t": "3.1",
          "type": "single",
          "q": "A monorepo has separate packages with different standards: the API package follows REST conventions, while the worker package follows queue conventions. You want each package's CLAUDE.md to include only relevant standards. What is the best mechanism?",
          "o": [
            "Create one user-level CLAUDE.md with all package rules.",
            "Copy the entire standards library into every package's CLAUDE.md.",
            "Put every standard in the root CLAUDE.md and ask the model to infer which applies.",
            "Use @import in each package's CLAUDE.md to reference only that package's standards file."
          ],
          "a": [
            3
          ],
          "e": "@import keeps shared standards modular and lets each package include only what applies. A monolithic root file invites inference and irrelevant context; duplicating everything is a maintenance burden; user-level configuration is not shared with the team."
        },
        {
          "id": "s2q29",
          "d": "D3",
          "t": "3.1",
          "type": "single",
          "q": "Two developers on the same project get different behavior from Claude Code, and you suspect different memory files are loading. Which command helps diagnose which memory files are active?",
          "o": [
            "/memory",
            "/compact",
            "/init",
            "/review"
          ],
          "a": [
            0
          ],
          "e": "/memory shows which memory files are loaded and is the diagnostic tool for inconsistent CLAUDE.md behavior. /compact reduces context, /review is a workflow command, and /init initializes project memory rather than inspecting the active hierarchy."
        },
        {
          "id": "s2q30",
          "d": "D3",
          "t": "3.2",
          "type": "single",
          "q": "A developer wants a personal variant of the team's /review command with an extra checklist, without changing what teammates get. What is the correct approach?",
          "o": [
            "Put the extra checklist in the project CLAUDE.md.",
            "Edit the project's .claude/commands/review.md directly.",
            "Create a differently named personal command in ~/.claude/commands/.",
            "Delete the team command and recreate it under the same name in the home directory."
          ],
          "a": [
            2
          ],
          "e": "User-scoped commands live in ~/.claude/commands/ and stay personal. A different name avoids confusion with the shared command. Editing the project file changes teammates' behavior; CLAUDE.md is not a command definition; deleting the team command breaks shared workflow."
        },
        {
          "id": "s2q31",
          "d": "D3",
          "t": "3.2",
          "type": "single",
          "q": "A skill requires a ticket ID, but developers often invoke it without arguments and it fails. Which SKILL.md frontmatter option prompts them for the required parameter?",
          "o": [
            "description",
            "argument-hint",
            "allowed-tools",
            "context: fork"
          ],
          "a": [
            1
          ],
          "e": "argument-hint displays the expected parameters when the skill is invoked without them. allowed-tools restricts tools, context: fork isolates execution, and description helps discovery but does not collect missing input."
        },
        {
          "id": "s2q32",
          "d": "D3",
          "t": "3.3",
          "type": "single",
          "q": "SQL migration files live under db/migrations, services/billing/migrations and services/auth/migrations. All should follow the same migration conventions. What rule configuration is most maintainable?",
          "o": [
            "A skill invoked manually before editing each migration.",
            "A separate CLAUDE.md in each migrations directory.",
            "A .claude/rules/ file with paths: [\"**/migrations/**/*.sql\"]",
            "A root CLAUDE.md section that says “migration files” and relies on inference."
          ],
          "a": [
            2
          ],
          "e": "A glob spanning directories applies the convention wherever matching SQL migrations appear. Directory-bound CLAUDE.md files require duplication; inference is unreliable; manual skill invocation is not automatic."
        },
        {
          "id": "s2q33",
          "d": "D3",
          "t": "3.3",
          "type": "single",
          "q": "A convention applies to every file of a given type, no matter which directory it sits in. Why are path-specific rules preferable to subdirectory CLAUDE.md files?",
          "o": [
            "Subdirectory CLAUDE.md files always override project instructions.",
            "Subdirectory CLAUDE.md files cannot contain code conventions.",
            "Path rules load only for matching files, so they can target file types across directories without duplicate files.",
            "Path rules are the only way to use YAML in Claude Code."
          ],
          "a": [
            2
          ],
          "e": "Glob-based path rules provide conditional loading by file pattern and are not tied to one directory. Directory CLAUDE.md files can hold conventions but are bound to their directory, which forces duplication when the same convention spans the codebase."
        },
        {
          "id": "s2q34",
          "d": "D3",
          "t": "3.4",
          "type": "single",
          "q": "During a multi-phase task, a verbose discovery step is filling the main conversation with file listings and search output. You need the findings but not the noise. What is the best approach?",
          "o": [
            "Use the Explore subagent for discovery so verbose output stays isolated and only a summary returns.",
            "Run discovery in the main session and delete messages manually afterward.",
            "Increase the context window and keep every discovery message.",
            "Avoid discovery and implement based on assumptions."
          ],
          "a": [
            0
          ],
          "e": "The Explore subagent isolates verbose discovery and returns a summary, preserving the main conversation's context for coordination and implementation. Manual deletion is error-prone; skipping discovery risks wrong assumptions; a larger window postpones exhaustion."
        },
        {
          "id": "s2q35",
          "d": "D3",
          "t": "3.4",
          "type": "single",
          "q": "A migration needs investigation of several integration approaches followed by implementation of the chosen one. How should plan mode and direct execution be combined?",
          "o": [
            "Use direct execution for both investigation and implementation to save time.",
            "Use plan mode to investigate and choose an approach, then switch to direct execution for the chosen implementation.",
            "Fork a session for each approach and never converge on one.",
            "Stay in plan mode through implementation so no code is written until the end."
          ],
          "a": [
            1
          ],
          "e": "Plan mode is valuable for exploration and architectural choice; direct execution is efficient once the approach is known. Remaining in plan mode blocks implementation; direct investigation risks costly rework; forking without convergence does not deliver the change."
        },
        {
          "id": "s2q36",
          "d": "D3",
          "t": "3.5",
          "type": "single",
          "q": "You must add caching to a system whose invalidation rules you do not fully understand. Before implementing, you want to surface design considerations you may have missed. Which technique fits best?",
          "o": [
            "Skip design and let the test suite reveal the invalidation strategy.",
            "Provide a complete implementation and ask Claude to approve it.",
            "Raise the temperature and accept the first design that appears.",
            "Use the interview pattern and have Claude ask you questions about invalidation, failure modes and constraints."
          ],
          "a": [
            3
          ],
          "e": "The interview pattern surfaces unanticipated considerations before code is written, which is valuable in unfamiliar domains. Self-approval lacks independent scrutiny; random design is not analysis; tests verify behavior but do not choose a coherent strategy."
        },
        {
          "id": "s2q37",
          "d": "D3",
          "t": "3.5",
          "type": "single",
          "q": "A refactor has four issues, but fixing the null handling changes how the retry logic behaves, which in turn affects logging. How should the issues be presented?",
          "o": [
            "Ask for four independent patches and merge them without review.",
            "Fix only the first issue and wait for the tests to reveal the rest.",
            "Address all interacting issues in one detailed message that explains the dependencies.",
            "Fix them one at a time in separate messages and never mention the interactions."
          ],
          "a": [
            2
          ],
          "e": "When fixes interact, separate iterations can produce conflicting local solutions. A single detailed message lets the model reason about the dependencies together. Sequential blind fixes may thrash; withholding known issues wastes cycles; merging independent patches ignores interactions."
        },
        {
          "id": "s2q38",
          "d": "D3",
          "t": "3.6",
          "type": "single",
          "q": "A CI job must post each review finding as an inline pull-request comment. The pipeline needs machine-parseable output with a fixed finding schema. Which invocation is appropriate?",
          "o": [
            "claude --output-format json --json-schema findings.schema.json -p \"Review this PR\"",
            "claude -p \"Review this PR\" with a request to “please return JSON”.",
            "claude --interactive --format markdown \"Review this PR\"",
            "claude -p \"Review this PR\" with prose output parsed by a regex."
          ],
          "a": [
            0
          ],
          "e": "--output-format json plus --json-schema gives a structured, schema-constrained payload for automated posting. Prose plus regex is brittle; an interactive flag defeats CI; a prompt-only JSON request is not enforced."
        },
        {
          "id": "s2q39",
          "d": "D3",
          "t": "3.6",
          "type": "single",
          "q": "A pull request is re-reviewed after new commits, but the bot reposts comments that were already addressed. What change fixes the duplicate feedback?",
          "o": [
            "Disable review on updates and run it only when the PR is opened.",
            "Run the review on only the newest commit and ignore the rest of the PR.",
            "Include the prior review findings in context and instruct the reviewer to report only new or still-unaddressed issues.",
            "Increase the review model's temperature so it produces different comments."
          ],
          "a": [
            2
          ],
          "e": "Prior findings let the reviewer distinguish resolved issues from new ones and avoid duplicates. Reviewing only the newest commit may miss unresolved issues elsewhere; disabling updates removes useful feedback; randomness is not deduplication."
        },
        {
          "id": "s2q40",
          "d": "D4",
          "t": "4.1",
          "type": "single",
          "q": "A code-comment reviewer is told to “check that comments are accurate”. It flags harmless wording differences and misses comments that contradict actual behavior. What instruction change most improves precision?",
          "o": [
            "Add more examples of comments it should not flag, without changing the criteria.",
            "Ask it to be more conservative and only report high-confidence findings.",
            "Tell it to review comments only in changed files.",
            "Specify that it should flag a comment only when the claimed behavior contradicts the code, and skip wording or style differences."
          ],
          "a": [
            3
          ],
          "e": "A categorical criterion defines the exact condition to report and excludes style noise. “Be conservative” is vague; limiting files reduces coverage; negative examples without a clear rule leave the decision boundary fuzzy."
        },
        {
          "id": "s2q41",
          "d": "D4",
          "t": "4.1",
          "type": "single",
          "q": "A security reviewer flags many theoretical issues that cannot be exploited in this architecture, while missing real vulnerabilities. Developers no longer trust it. What is the best prompt change?",
          "o": [
            "Lower the temperature and repeat the same instruction.",
            "Define explicit criteria for exploitable vulnerabilities versus theoretical concerns, with concrete examples of each.",
            "Reduce the review to the five largest files.",
            "Add “only report high-confidence findings” to the system prompt."
          ],
          "a": [
            1
          ],
          "e": "Precision requires a decision rule tied to the architecture and exploitability, not a confidence slogan. Concrete categories and examples calibrate judgment. File-count limits reduce coverage; lower temperature does not change relevance."
        },
        {
          "id": "s2q42",
          "d": "D4",
          "t": "4.2",
          "type": "single",
          "q": "A support agent must choose between a knowledge-base search and an order-database lookup for ambiguous requests. Instructions alone produce inconsistent choices. What few-shot design is most useful?",
          "o": [
            "Two to four examples of ambiguous requests that show the chosen tool and the reasoning for rejecting the plausible alternative.",
            "Twenty examples that list only the final tool name with no explanation.",
            "One example for every possible customer phrase.",
            "Examples of successful answers but not of tool selection."
          ],
          "a": [
            0
          ],
          "e": "Targeted examples that expose the decision rationale teach the model how to generalize to new ambiguous cases. Tool names alone do not explain boundaries; enumerating phrases is brittle; answer examples do not demonstrate routing."
        },
        {
          "id": "s2q43",
          "d": "D4",
          "t": "4.2",
          "type": "single",
          "q": "A reviewer keeps flagging an accepted repository pattern as a bug. You want it to distinguish that pattern from genuine defects and still catch novel variants. What is the best approach?",
          "o": [
            "Provide few-shot examples that contrast acceptable uses of the pattern with genuine defects, explaining the distinction.",
            "Remove all such code from the training examples.",
            "Add a blanket rule that suppresses every finding containing that pattern name.",
            "Ask developers to close those findings manually each time."
          ],
          "a": [
            0
          ],
          "e": "Contrastive examples teach the boundary and support generalization to new variants. A blanket suppression rule creates false negatives; removing examples leaves the model without context; manual triage does not improve the reviewer."
        },
        {
          "id": "s2q44",
          "d": "D4",
          "t": "4.3",
          "type": "single",
          "q": "A document-classification schema must support a known set of categories plus emerging categories not yet enumerated, without losing the specific label. Which schema design fits?",
          "o": [
            "A free-text category field with no constraints.",
            "A numeric confidence field with no category field.",
            "A required enum containing only today's categories.",
            "An enum that includes “other” plus a companion detail string for the specific label."
          ],
          "a": [
            3
          ],
          "e": "An “other” enum member preserves schema validity while a detail string captures the unanticipated category. Free text loses enumeration; a closed enum rejects new categories; a confidence score does not classify the document."
        },
        {
          "id": "s2q45",
          "d": "D4",
          "t": "4.3",
          "type": "single",
          "q": "An extraction schema requires a `termination_reason` field, but some contracts are silent on termination and others use ambiguous language. What schema change best avoids fabricated values?",
          "o": [
            "Make the field required and instruct the model to infer the most likely reason.",
            "Allow nullable values and add an “unclear” enum member for ambiguous cases.",
            "Remove the field entirely from the schema.",
            "Add a default value of “breach” so every document has an answer."
          ],
          "a": [
            1
          ],
          "e": "Nullable fields and an explicit “unclear” option let the model represent absence or ambiguity honestly. Forcing inference or a default fabricates data; removing the field loses a legitimate output when the source does state a reason."
        },
        {
          "id": "s2q46",
          "d": "D4",
          "t": "4.4",
          "type": "single",
          "q": "Developers dismiss many review findings, but you cannot tell which code constructs cause the false positives. What schema addition best enables systematic analysis?",
          "o": [
            "A timestamp field showing when the finding was generated.",
            "A longer explanation field with more prose.",
            "A free-text “notes” field on every finding.",
            "A detected_pattern field identifying the construct that triggered each finding."
          ],
          "a": [
            3
          ],
          "e": "A structured detected_pattern field lets you aggregate dismissals by construct and improve the prompt or rules where false positives cluster. Free-text notes are hard to aggregate; timestamps and longer prose do not identify the cause."
        },
        {
          "id": "s2q47",
          "d": "D4",
          "t": "4.4",
          "type": "single",
          "q": "Invoice extraction sometimes returns a line-item total that disagrees with the stated total, yet the JSON is schema-valid. What design best detects this semantic error?",
          "o": [
            "Retry the extraction until the two values happen to match.",
            "Extract both calculated_total and stated_total, then flag any discrepancy for review.",
            "Make the schema stricter so JSON syntax errors cannot occur.",
            "Trust the model because schema validation already passed."
          ],
          "a": [
            1
          ],
          "e": "Tool use eliminates syntax errors but not semantic inconsistencies. Capturing both values makes the disagreement explicit and routable. Stricter syntax does not compare totals; retrying without feedback is guessing; schema validity says nothing about correctness."
        },
        {
          "id": "s2q48",
          "d": "D4",
          "t": "4.5",
          "type": "single",
          "q": "A workflow needs to call a tool, inspect its result, and then make another model call within the same logical job. A manager proposes the Message Batches API for its cost savings. What should you advise?",
          "o": [
            "Use the batch API with a larger model to avoid the need for tools.",
            "Use the synchronous API because batch requests do not support multi-turn tool calling within a single request.",
            "Use the batch API and poll every minute for the intermediate result.",
            "Use the batch API because custom_id can coordinate the intermediate tool calls."
          ],
          "a": [
            1
          ],
          "e": "The Message Batches API cannot execute tools mid-request and return results for another turn, so it does not fit this interactive tool loop. custom_id correlates requests but does not add tool execution; polling and model size do not change the batch contract."
        },
        {
          "id": "s2q49",
          "d": "D4",
          "t": "4.5",
          "type": "single",
          "q": "A report pipeline has a 30-hour delivery SLA. Batch processing can take up to 24 hours, and documents arrive continuously. How should submissions be scheduled to stay within the SLA?",
          "o": [
            "Submit in 4-hour windows so the oldest document waits at most 24 hours of processing plus 4 hours of queueing.",
            "Submit one batch every 24 hours.",
            "Submit only when 10,000 documents have accumulated.",
            "Submit one batch every 30 hours."
          ],
          "a": [
            0
          ],
          "e": "With up to 24 hours of batch processing, a 4-hour submission window keeps worst-case age within 28 hours, inside the 30-hour SLA. Daily or 30-hour cadence can exceed the SLA; volume-triggered submission ignores arrival time."
        },
        {
          "id": "s2q50",
          "d": "D4",
          "t": "4.6",
          "type": "multi",
          "n": 2,
          "q": "A 40-file pull request produces contradictory review comments and misses cross-file data-flow bugs. Which two review passes best address both problems? (Select two.)",
          "o": [
            "A separate cross-file integration pass for data-flow and trust boundaries.",
            "Three identical full-PR passes with majority voting.",
            "A larger context window with all 40 files in one pass.",
            "A per-file local analysis pass for issues within each file."
          ],
          "a": [
            0,
            3
          ],
          "e": "Per-file passes prevent attention dilution, while a separate integration pass finds issues that only appear across files. Majority voting can suppress real intermittent findings, and a larger context window does not guarantee consistent attention."
        },
        {
          "id": "s2q51",
          "d": "D4",
          "t": "4.6",
          "type": "single",
          "q": "A model generates a security-sensitive patch and then checks it in the same conversation. It approves a flaw it introduced. What is the most reliable review setup?",
          "o": [
            "Ask the same model to review again with a stronger instruction to be skeptical.",
            "Have an independent Claude instance review the patch without the generator's reasoning context.",
            "Ask the generator to explain why the patch is secure and accept if the explanation is coherent.",
            "Increase the generator's temperature during self-review."
          ],
          "a": [
            1
          ],
          "e": "Independent review removes the generator's anchoring reasoning and is better at questioning subtle decisions. Re-prompting the same context retains its commitments; temperature does not create independence; a coherent self-justification can rationalize the same flaw."
        },
        {
          "id": "s2q52",
          "d": "D5",
          "t": "5.1",
          "type": "single",
          "q": "A long aggregated input contains a key summary in the middle, followed by hundreds of pages of detail. The model repeatedly misses the summary's findings. What layout change best mitigates position effects?",
          "o": [
            "Move the key findings summary to the beginning and organize the details under explicit section headers.",
            "Interleave the summary randomly throughout the document.",
            "Put the summary at the very end and remove all headers.",
            "Compress the details into one unbroken paragraph."
          ],
          "a": [
            0
          ],
          "e": "Models reliably process the beginning and end of long inputs better than the middle. Leading with the summary and using explicit headers reduces the chance that key findings are lost. Random placement or a wall of text worsens retrieval."
        },
        {
          "id": "s2q53",
          "d": "D5",
          "t": "5.1",
          "type": "single",
          "q": "A multi-turn support application sends only the newest user message on each API request. The model keeps losing earlier commitments and order details. What is the underlying problem?",
          "o": [
            "The model's temperature is too low to remember previous turns.",
            "Tool results are always cached by the API and should not be resent.",
            "The API is stateless, so the application must pass the relevant conversation history on each request.",
            "The system prompt is too short to store the full transcript."
          ],
          "a": [
            2
          ],
          "e": "The Messages API does not maintain conversation state between calls; the application supplies history. Sending only the newest message discards the context the model needs. Temperature and system-prompt length do not replace history, and tool results are not automatically preserved."
        },
        {
          "id": "s2q54",
          "d": "D5",
          "t": "5.2",
          "type": "multi",
          "n": 2,
          "q": "A customer writes an angry message about a simple password reset and uses strong language. The agent escalates solely because of negative sentiment. Which two behaviors are more appropriate? (Select two.)",
          "o": [
            "Ask the customer to calm down before diagnosing the issue.",
            "Escalate if the customer explicitly reiterates a preference for a human.",
            "Acknowledge the frustration and offer to resolve the straightforward issue.",
            "Escalate every message that contains profanity."
          ],
          "a": [
            1,
            2
          ],
          "e": "Sentiment is not a reliable proxy for case complexity. Acknowledging frustration while using the agent's capability serves the customer, and an explicit preference for a human is a valid escalation trigger. Blanket profanity escalation and tone policing are poor service."
        },
        {
          "id": "s2q55",
          "d": "D5",
          "t": "5.3",
          "type": "single",
          "q": "A subagent wraps every tool call in a broad exception handler and returns an empty list on failure. The coordinator treats the result as “no matches found”. What is the design flaw?",
          "o": [
            "The empty list should be cached to reduce future errors.",
            "The subagent needs more tools so it can retry every failure.",
            "The subagent is suppressing access failures and misrepresenting them as valid empty results.",
            "The coordinator should have used a larger context window."
          ],
          "a": [
            2
          ],
          "e": "Access failures and valid empty results are semantically different. Suppressing exceptions prevents the coordinator from deciding whether to retry, switch sources or annotate a gap. Context size, tool count and caching do not fix mislabeled outcomes."
        },
        {
          "id": "s2q56",
          "d": "D5",
          "t": "5.4",
          "type": "single",
          "q": "A long-running multi-agent codebase analysis crashes overnight. On restart, the coordinator cannot tell which modules were already analyzed or which findings are trustworthy. What design would enable recovery?",
          "o": [
            "Rely on the model's memory of the previous run.",
            "Have each agent export structured state and findings to a known location, and have the coordinator load a manifest on resume.",
            "Keep the whole repository in one agent's context to avoid handoffs.",
            "Restart the entire analysis from scratch every time."
          ],
          "a": [
            1
          ],
          "e": "Structured state exports and a manifest give the coordinator durable knowledge of completed work and validated findings. Model memory does not survive a crash; full restarts waste work; a single giant context is fragile and does not provide recovery metadata."
        },
        {
          "id": "s2q57",
          "d": "D5",
          "t": "5.4",
          "type": "single",
          "q": "During an extended exploration session, the context window fills with verbose discovery output, leaving little room for reasoning. Which action is specifically intended to reduce context usage in this situation?",
          "o": [
            "Use /review to start a code review.",
            "Use /memory to load more instructions.",
            "Use /compact to condense the conversation while preserving essential context.",
            "Use /init to reinitialize the project."
          ],
          "a": [
            2
          ],
          "e": "/compact reduces context usage by summarizing the session while retaining important context, which fits extended exploration. /init, /memory and /review serve different purposes and do not compact the current context."
        },
        {
          "id": "s2q58",
          "d": "D5",
          "t": "5.5",
          "type": "single",
          "q": "An extraction system is highly accurate overall, and the team wants ongoing evidence that confident extractions remain correct. Which monitoring approach best detects novel error patterns?",
          "o": [
            "Stratified random sampling of high-confidence extractions, reviewed against ground truth.",
            "Increase the confidence threshold until errors disappear from the dashboard.",
            "Review only documents the model marks as low confidence.",
            "Track only the aggregate accuracy metric once per month."
          ],
          "a": [
            0
          ],
          "e": "Stratified sampling of high-confidence output provides ongoing error-rate estimates and can surface new patterns that aggregate metrics hide. Aggregate-only tracking misses segment drift; low-confidence-only review ignores confident errors; raising thresholds hides rather than fixes them."
        },
        {
          "id": "s2q59",
          "d": "D5",
          "t": "5.5",
          "type": "single",
          "q": "You have field-level confidence scores from an extractor but no principled way to set the human-review threshold. What should you use?",
          "o": [
            "The model's overall confidence for the whole document.",
            "A fixed threshold of 0.9 for every field and document type.",
            "The threshold from a different vendor's extraction system.",
            "A labeled validation set to calibrate field-level thresholds against observed accuracy."
          ],
          "a": [
            3
          ],
          "e": "Confidence scores must be calibrated against labeled outcomes to choose thresholds that reflect real accuracy. A universal 0.9 ignores field and document differences; document-level confidence hides field variation; another system's calibration does not transfer."
        },
        {
          "id": "s2q60",
          "d": "D5",
          "t": "5.6",
          "type": "single",
          "q": "Two sources disagree on a market statistic. One was published in 2023 and the other in 2026, and the difference may reflect timing rather than a real conflict. What should the structured findings include?",
          "o": [
            "Publication or data-collection dates alongside each value and claim.",
            "Only the most recent value, with the older source omitted.",
            "A single averaged value without dates.",
            "A note that all statistics are inherently unreliable."
          ],
          "a": [
            0
          ],
          "e": "Temporal metadata lets synthesis distinguish a genuine conflict from a change over time. Dropping the older value hides evidence; averaging invents a number; a blanket disclaimer is not provenance."
        }
      ]
    },
    {
      "id": 3,
      "title": "Trap-heavy finale",
      "blurb": "Designed around plausible wrong-layer fixes: prompt tweaks, confidence heuristics, larger context windows and over-provisioned tools.",
      "mode": "mixed",
      "questions": [
        {
          "id": "s3q01",
          "d": "D1",
          "t": "1.1",
          "type": "single",
          "q": "Each time the agent loop calls the model again, it sends only the newest tool result instead of the full conversation. The model forgets the original request and contradicts earlier findings. What is the defect?",
          "o": [
            "The loop needs a higher iteration cap to recover the lost context.",
            "The request omits prior assistant and tool messages, so the model cannot reason over the conversation so far.",
            "The tool result should be returned as a user message with no tool_use ID.",
            "The model temperature is too high for a multi-step task."
          ],
          "a": [
            1
          ],
          "e": "Every model call must include the accumulated conversation, including prior assistant tool_use blocks and matching tool_result blocks. Sending only the latest result removes the evidence and reasoning the model needs. Temperature, ID removal and iteration caps do not restore history."
        },
        {
          "id": "s3q02",
          "d": "D1",
          "t": "1.1",
          "type": "single",
          "q": "The model returns three parallel tool_use blocks in one assistant turn. The loop executes only the first block and sends one tool_result, so the model repeats the other two calls. What should the loop do?",
          "o": [
            "Ask the model to return a single tool call in every response.",
            "Execute every requested tool_use block and append a matching tool_result for each before the next model turn.",
            "Execute only the first tool and instruct the model to request the others one at a time.",
            "Discard the extra tool_use blocks because parallel calls are unsupported."
          ],
          "a": [
            1
          ],
          "e": "A single assistant turn can contain multiple tool_use blocks. All should be executed and all matching tool_result blocks returned so the model can continue. Dropping or serializing them breaks the protocol and adds unnecessary turns."
        },
        {
          "id": "s3q03",
          "d": "D1",
          "t": "1.1",
          "type": "single",
          "q": "A support workflow was built as a fixed sequence: get_customer, then lookup_order, then process_refund. It fails whenever a customer asks only about an order or has a billing dispute with no refund. What is the better design?",
          "o": [
            "Add more branches to the fixed decision tree until every request type is covered.",
            "Let the model choose the next tool based on context, while keeping programmatic gates for critical rules such as identity before refund.",
            "Randomize the tool order so the agent explores different workflows.",
            "Always execute all three tools in sequence so no path is missed."
          ],
          "a": [
            1
          ],
          "e": "Model-driven tool selection handles varied requests, while deterministic gates protect critical invariants. Enumerating every branch is brittle, running irrelevant tools wastes calls and can cause harm, and randomization is not a workflow."
        },
        {
          "id": "s3q04",
          "d": "D1",
          "t": "1.2",
          "type": "multi",
          "n": 2,
          "q": "In a hub-and-spoke multi-agent system, which two responsibilities belong to the coordinator? (Select two.)",
          "o": [
            "Implementing each subagent's specialized tool integrations.",
            "Aggregating results, routing information and handling errors across subagents.",
            "Allowing subagents to negotiate directly with each other outside the hub.",
            "Decomposing the query and deciding which subagents to invoke."
          ],
          "a": [
            1,
            3
          ],
          "e": "The coordinator owns decomposition, delegation, aggregation, routing and consistent error handling. Subagent tool implementation is local to each specialist, and peer negotiation bypasses the observability and control the hub provides."
        },
        {
          "id": "s3q05",
          "d": "D1",
          "t": "1.2",
          "type": "single",
          "q": "A coordinator sends the same broad query to four research subagents. Their outputs overlap heavily and still miss two important subtopics. What decomposition change is most effective?",
          "o": [
            "Reduce the team to one subagent so duplication is impossible.",
            "Send the same query to six subagents to increase the chance of coverage.",
            "Ask each subagent to work sequentially after reading the previous agent's output.",
            "Assign distinct subtopics or source types to each subagent so coverage is partitioned."
          ],
          "a": [
            3
          ],
          "e": "Partitioning scope across specialists reduces duplicated effort and makes coverage gaps visible. Repeating the same query scales duplication rather than coverage; sequential sharing reduces parallelism; collapsing to one agent loses specialization."
        },
        {
          "id": "s3q06",
          "d": "D1",
          "t": "1.3",
          "type": "single",
          "q": "The coordinator invokes the same search subagent twice. On the second call, it asks the subagent to “use what you found earlier”, but the subagent returns unrelated results. Why?",
          "o": [
            "The Task tool caches results only when tool_choice is forced.",
            "The subagent's model has a smaller context window than the coordinator.",
            "Subagent invocations do not share memory automatically; earlier findings must be included in the new prompt.",
            "The coordinator should have used a fork instead of a fresh invocation."
          ],
          "a": [
            2
          ],
          "e": "Each subagent invocation starts with isolated context. Findings from a previous call must be explicitly passed in the new prompt. Context-window size, tool_choice and forking do not create automatic memory between invocations."
        },
        {
          "id": "s3q07",
          "d": "D1",
          "t": "1.3",
          "type": "single",
          "q": "A coordinator prompt gives each subagent a rigid ten-step procedure. When a source is unavailable, subagents cannot adapt and return incomplete work. What prompt change best improves adaptability?",
          "o": [
            "Specify the research goal, constraints and quality criteria, and let the subagent choose how to achieve them.",
            "Add five more procedural steps to cover more failure cases.",
            "Give the subagent every tool in the system so no step is blocked.",
            "Raise the subagent's temperature so it improvises more."
          ],
          "a": [
            0
          ],
          "e": "Goal-and-criteria prompts preserve the objective while allowing the subagent to adapt its method to what it discovers. More steps are still brittle, temperature is not a strategy, and over-provisioning tools increases misuse."
        },
        {
          "id": "s3q08",
          "d": "D1",
          "t": "1.4",
          "type": "single",
          "q": "A returns workflow must not refund an order until lookup_order confirms the item was delivered. The agent sometimes refunds undelivered orders despite a clear prompt. What control best guarantees the order?",
          "o": [
            "Few-shot examples of correct refunds after delivery.",
            "A programmatic prerequisite that blocks process_refund until a delivered status is present in the case state.",
            "A stronger prompt that underlines the delivery requirement.",
            "A daily report that lists refunds issued before delivery."
          ],
          "a": [
            1
          ],
          "e": "A gate tied to verified delivered status enforces the workflow deterministically. Prompting and examples remain probabilistic, and after-the-fact reporting does not prevent the financial error."
        },
        {
          "id": "s3q09",
          "d": "D1",
          "t": "1.4",
          "type": "single",
          "q": "The agent issues a partial refund, then escalates the remaining dispute to a human. The customer is refunded twice because the handoff does not mention the first transaction. What should the handoff contain?",
          "o": [
            "Only the customer's original message and the escalation reason.",
            "A request for the customer to repeat the case history to the human agent.",
            "The full tool-call log with every request and response payload.",
            "The completed action with transaction ID and amount, plus pending steps and a recommended next action."
          ],
          "a": [
            3
          ],
          "e": "A safe handoff summarizes state: what has already happened, identifiable transaction references, what remains, and what should happen next. Without completed-action context, the human can duplicate work. Raw logs are noisy, and asking the customer to repeat is poor service."
        },
        {
          "id": "s3q10",
          "d": "D1",
          "t": "1.5",
          "type": "single",
          "q": "A multi-tenant agent must ensure every backend tool call is scoped to the current tenant. The model sometimes omits the tenant ID from tool arguments, leaking data across tenants. What control is appropriate?",
          "o": [
            "A PostToolUse hook that filters the response after the query has run.",
            "A few-shot example showing a tenant-scoped request.",
            "A tool-call interception hook that validates or injects the tenant ID before the tool executes.",
            "A system-prompt reminder to always include the tenant ID."
          ],
          "a": [
            2
          ],
          "e": "Tenant isolation is a security invariant and must be enforced before execution. A pre-execution hook can inject or reject calls lacking tenant scope. Prompting and examples are probabilistic; filtering after the query has already accessed another tenant's data is too late."
        },
        {
          "id": "s3q11",
          "d": "D1",
          "t": "1.5",
          "type": "single",
          "q": "Compliance requires an audit record for every tool invocation, including arguments and outcome. A prompt instruction to “remember to log” still misses about 2% of calls. What should be used?",
          "o": [
            "A hook that records each tool call and result at the tool boundary.",
            "A larger system prompt that repeats the logging requirement.",
            "Random sampling of tool calls followed by manual reconstruction.",
            "A weekly report generated from the model's memory of the session."
          ],
          "a": [
            0
          ],
          "e": "A hook at the tool boundary observes every invocation deterministically, independent of model compliance. Prompt repetition is still probabilistic; sampling misses calls; model memory is not an audit trail."
        },
        {
          "id": "s3q12",
          "d": "D1",
          "t": "1.6",
          "type": "single",
          "q": "A contract review must analyze every clause in a fixed order, then run a consistency pass across clauses. The stages are known and repeatable. Which decomposition fits?",
          "o": [
            "Prompt chaining: clause-level passes in a fixed order followed by a cross-clause consistency pass.",
            "Dynamic decomposition that invents a new review order each time.",
            "A coordinator that randomly assigns clauses to available agents.",
            "A single prompt containing the whole contract and no staging."
          ],
          "a": [
            0
          ],
          "e": "Predictable, repeatable stages fit prompt chaining, which preserves order and passes each stage's output forward. Dynamic decomposition is for uncertain investigation; one giant pass dilutes attention; random assignment breaks the required review order."
        },
        {
          "id": "s3q13",
          "d": "D1",
          "t": "1.6",
          "type": "single",
          "q": "You need to improve a slow API endpoint, but you do not know whether the bottleneck is database queries, serialization or an external call. What decomposition strategy fits?",
          "o": [
            "Ask the model to guess the bottleneck from the endpoint name.",
            "Rewrite the entire service before measuring anything.",
            "A fixed plan that optimizes the database first because that is usually the cause.",
            "An adaptive plan: profile, identify the current hot path, then choose the next investigation or fix based on evidence."
          ],
          "a": [
            3
          ],
          "e": "Performance work is evidence-driven. Adaptive decomposition uses profiling results to direct the next step. A fixed guess may optimize the wrong layer; a rewrite is risky and unfocused; guessing from a name is not diagnosis."
        },
        {
          "id": "s3q14",
          "d": "D1",
          "t": "1.7",
          "type": "single",
          "q": "You resume a named session after modifying three files that the agent previously analyzed. The agent starts re-reading the entire repository. What instruction would make the resumed work more efficient?",
          "o": [
            "Ask the agent to forget all previous analysis and start over.",
            "Resume without any note and let the agent discover changes by reading everything.",
            "Tell the agent exactly which files changed and ask it to re-analyze only those, reusing prior findings elsewhere.",
            "Fork the session and delete the original branch."
          ],
          "a": [
            2
          ],
          "e": "Resumption is most efficient when the agent knows which evidence is stale. Naming changed files enables targeted re-analysis while preserving valid prior work. Full re-reading wastes effort; forgetting everything discards useful context; forking does not communicate changes."
        },
        {
          "id": "s3q15",
          "d": "D1",
          "t": "1.7",
          "type": "single",
          "q": "After a shared schema analysis, you want one branch to test a normalized-table design and another to test a document-store design, then compare results. Which session pattern fits?",
          "o": [
            "Delete the original analysis so each design starts without bias.",
            "Use fork_session to create independent branches from the shared analysis baseline.",
            "Use --resume to alternate between designs in the same conversation.",
            "Run both designs in one session and ask the model to keep them mentally separate."
          ],
          "a": [
            1
          ],
          "e": "Forking preserves the common baseline while isolating divergent experiments. Mixing designs in one context creates cross-contamination; alternating in one session has the same problem; deleting the baseline wastes valid analysis."
        },
        {
          "id": "s3q16",
          "d": "D1",
          "t": "1.7",
          "type": "single",
          "q": "You fork a session into branch A and branch B. Branch A discovers a critical constraint and updates its plan. Branch B continues with the old assumptions. What is the correct interpretation?",
          "o": [
            "Forked branches are independent; findings from A must be explicitly passed to B if they should influence it.",
            "Forked branches share updates automatically, so branch B must have a bug.",
            "Branch B will inherit the update on its next model call.",
            "Forking should only be used after all analysis is complete."
          ],
          "a": [
            0
          ],
          "e": "Forking creates independent branches from a shared starting point; later changes do not synchronize automatically. If branch B should use A's constraint, the coordinator or developer must pass it explicitly. Automatic inheritance and deferred sync are misconceptions."
        },
        {
          "id": "s3q17",
          "d": "D2",
          "t": "2.1",
          "type": "single",
          "q": "Two tools, search_web and search_news, have nearly identical descriptions. The agent uses search_news for general product documentation and search_web for recent headlines. What is the best fix?",
          "o": [
            "Rename both tools with random IDs so the model cannot confuse them.",
            "Rewrite each description to define its source scope, typical queries, output type and boundary versus the other tool.",
            "Consolidate them into one tool that returns every source type.",
            "Add a rule that search_news must always be called first."
          ],
          "a": [
            1
          ],
          "e": "Overlapping descriptions cause misrouting. Explicit source scope, query examples, output type and boundaries let the model distinguish them. A forced order is wrong for many requests, random names remove meaning, and consolidation may be a larger design choice rather than the first fix."
        },
        {
          "id": "s3q18",
          "d": "D2",
          "t": "2.1",
          "type": "single",
          "q": "A billing tool returns amounts in cents, but its description does not say so. The agent tells customers their $49.00 charge is $4,900. What description change best prevents this?",
          "o": [
            "Increase the model temperature so it considers alternative interpretations.",
            "Add “be careful with numbers” to the system prompt.",
            "State the output units, format and an example value in the tool description.",
            "Rename the tool to billing_amounts_cents."
          ],
          "a": [
            2
          ],
          "e": "Tool descriptions should define output formats and units; an example removes ambiguity. A vague caution does not supply the missing contract, renaming alone is weaker than documented units, and higher temperature adds variance."
        },
        {
          "id": "s3q19",
          "d": "D2",
          "t": "2.1",
          "type": "single",
          "q": "A generic manage_account tool can look up, update or close accounts. The agent closes an account when the user only asks for its status. What change most directly reduces this risk?",
          "o": [
            "Add “do not close accounts unless asked” to the system prompt.",
            "Increase the number of few-shot examples that use manage_account for status.",
            "Split the tool into get_account_status, update_account and close_account with distinct descriptions and permissions.",
            "Make manage_account require a confirmation code for every call."
          ],
          "a": [
            2
          ],
          "e": "Purpose-specific tools with explicit contracts and permissions make destructive actions distinct from read-only ones. A prompt warning is probabilistic; examples for the generic tool reinforce the ambiguity; blanket confirmation adds friction without separating capabilities."
        },
        {
          "id": "s3q20",
          "d": "D2",
          "t": "2.2",
          "type": "single",
          "q": "A payment-status tool times out because the upstream service is briefly overloaded. What error response best enables the agent to recover?",
          "o": [
            "A generic “Operation failed” with no category so the agent stays flexible.",
            "errorCategory: transient, isRetryable: true, with a short explanation and guidance to retry with backoff.",
            "An empty successful response so the workflow can continue.",
            "errorCategory: validation, isRetryable: false, because the timeout is the caller's fault."
          ],
          "a": [
            1
          ],
          "e": "A timeout is typically transient and retryable, ideally with backoff. Correct classification lets the agent recover without guessing. Mislabeling it as validation prevents retry; generic errors hide the decision; empty success suppresses a recoverable failure."
        },
        {
          "id": "s3q21",
          "d": "D2",
          "t": "2.2",
          "type": "single",
          "q": "A tool rejects a request because the `account_id` field is missing from the arguments. Which response best helps the agent correct the call?",
          "o": [
            "errorCategory: validation, isRetryable: false, naming the missing field and its expected format.",
            "errorCategory: transient, isRetryable: true, with no further detail.",
            "An empty successful response so the agent moves on.",
            "A generic “Bad request” with an HTTP status code only."
          ],
          "a": [
            0
          ],
          "e": "A validation error should identify the offending field and expected input so the agent can repair the arguments. Repeating the identical call will fail; a generic status lacks the correction path; empty success hides the problem."
        },
        {
          "id": "s3q22",
          "d": "D2",
          "t": "2.3",
          "type": "single",
          "q": "A synthesis agent needs to verify publication dates for about 85% of its claims; the remaining 15% require deeper source investigation. Currently every check round-trips through the coordinator. What is the best change?",
          "o": [
            "Give the synthesis agent every search and retrieval tool so it never needs help.",
            "Give the synthesis agent a scoped verify_source_date tool for simple date checks, while complex investigations still route through the coordinator.",
            "Make the synthesis agent return all verification requests in one batch at the end.",
            "Preload every possible date from the initial search results."
          ],
          "a": [
            1
          ],
          "e": "A narrow cross-role tool covers the high-frequency, low-risk case while preserving the coordinator path for complex work. Granting all tools violates specialization; batching creates blocking dependencies; speculative preloading cannot cover every claim."
        },
        {
          "id": "s3q23",
          "d": "D2",
          "t": "2.3",
          "type": "single",
          "q": "To guarantee metadata extraction, a pipeline forces tool_choice to extract_metadata on the first turn. The same forced setting remains active on later turns, so enrichment tools can never run. What is the correct configuration?",
          "o": [
            "Remove all enrichment tools from the pipeline.",
            "Set tool_choice to “auto” from the start and hope metadata is chosen first.",
            "Force extract_metadata only on the first turn, then switch to “auto” or “any” for subsequent turns.",
            "Keep the forced selection forever and add enrichment as a second schema field."
          ],
          "a": [
            2
          ],
          "e": "tool_choice applies per request. Forcing the first step guarantees metadata extraction, but subsequent turns need a different setting so other tools can be selected. Keeping the force locks the workflow; “auto” from the start does not guarantee order; removing enrichment loses functionality."
        },
        {
          "id": "s3q24",
          "d": "D2",
          "t": "2.4",
          "type": "single",
          "q": "A developer adds a new MCP server to the project configuration while a Claude Code session is already running. The agent cannot see the server's tools. What is the most likely explanation?",
          "o": [
            "MCP tools are discovered at connection time, so the session must reconnect or restart to load the new server.",
            "The server's tools must be copied into CLAUDE.md before they appear.",
            "The model must be given a tool_choice forcing the new server by name.",
            "MCP servers only work in user-scoped configuration."
          ],
          "a": [
            0
          ],
          "e": "Tools from configured MCP servers are discovered when the connection is established. A running session does not automatically see a newly added server until it reconnects or restarts. CLAUDE.md, user scope and tool_choice do not perform discovery."
        },
        {
          "id": "s3q25",
          "d": "D2",
          "t": "2.4",
          "type": "single",
          "q": "A team needs standard Jira integration: search issues, read comments and create tickets. A developer proposes writing a custom MCP server from scratch. What is the better decision?",
          "o": [
            "Build a custom server for every integration to maximize control.",
            "Expose the Jira CLI through Bash and let the model construct commands.",
            "Avoid MCP entirely and paste Jira data into prompts manually.",
            "Use a maintained community MCP server for standard Jira capabilities, reserving custom servers for team-specific workflows."
          ],
          "a": [
            3
          ],
          "e": "For standard integrations, an existing community MCP server reduces build and maintenance effort. Custom servers make sense for workflows unique to the team. Rebuilding standard integrations, manual pasting and shell command construction add risk and effort."
        },
        {
          "id": "s3q26",
          "d": "D2",
          "t": "2.5",
          "type": "single",
          "q": "An agent needs to run the project's test suite and inspect the failure output before proposing a fix. Which built-in tool is appropriate?",
          "o": [
            "Glob, to list every test file.",
            "Edit, to rewrite the failing test before running it.",
            "Grep, to search test files for the word “fail”.",
            "Bash, to execute the test command and capture its output."
          ],
          "a": [
            3
          ],
          "e": "Bash executes commands and returns stdout/stderr, which is needed to run tests and see failures. Grep and Glob inspect files but do not execute the suite; editing before seeing the failure skips diagnosis."
        },
        {
          "id": "s3q27",
          "d": "D2",
          "t": "2.5",
          "type": "single",
          "q": "A search for the symbol `apply_discount` returns dozens of matches in comments, documentation and unrelated strings. You need the actual import and call sites. What is the best search strategy?",
          "o": [
            "Use Glob for files named apply_discount.",
            "Use Bash to print every line containing the word and ignore the surrounding context.",
            "Use Grep with patterns for imports and definitions, then Read the matching files along the call chain.",
            "Read every source file to avoid missing a match."
          ],
          "a": [
            2
          ],
          "e": "Targeted content patterns narrow the result set to meaningful import or definition sites, and Reading the surrounding files confirms usage. Glob only matches filenames; reading everything is wasteful; raw word matches still include comments and docs."
        },
        {
          "id": "s3q28",
          "d": "D3",
          "t": "3.1",
          "type": "single",
          "q": "A package inside a monorepo has special build conventions that should apply only when working inside that package. Where should those instructions live?",
          "o": [
            "In the user-level ~/.claude/CLAUDE.md so they are always available.",
            "In a personal skill stored outside the repository.",
            "In a CLAUDE.md at that package's directory level, scoped to the package.",
            "In the root CLAUDE.md without any directory scoping."
          ],
          "a": [
            2
          ],
          "e": "Directory-level CLAUDE.md files scope instructions to their subtree, which matches package-specific conventions. User-level memory is personal and global; root instructions apply everywhere; an external personal skill is not shared project context."
        },
        {
          "id": "s3q29",
          "d": "D3",
          "t": "3.1",
          "type": "single",
          "q": "A developer wants a set of shortcuts and preferences available in every project on their own machine, without imposing them on teammates. Which configuration level fits?",
          "o": [
            "A .claude/rules/ file scoped to one package.",
            "A root CLAUDE.md with a note that the rules are optional.",
            "User-level ~/.claude/CLAUDE.md on that developer's machine.",
            "Project-level .claude/CLAUDE.md committed to each repository."
          ],
          "a": [
            2
          ],
          "e": "User-level memory applies only to that user across projects and is not shared through version control. Project and path-scoped files would affect teammates or be limited to one repository."
        },
        {
          "id": "s3q30",
          "d": "D3",
          "t": "3.2",
          "type": "single",
          "q": "A release checklist is used only occasionally and should not consume context on every task. What is the best way to package it?",
          "o": [
            "Add it to the system prompt of every subagent.",
            "Create an on-demand skill or slash command that developers invoke when needed.",
            "Put it in every developer's user-level CLAUDE.md.",
            "Put the full checklist in the root CLAUDE.md so it is always loaded."
          ],
          "a": [
            1
          ],
          "e": "On-demand workflows belong in skills or commands so they load when invoked. CLAUDE.md is for always-loaded standards; duplicating the checklist in user memory or every subagent still wastes context and spreads maintenance."
        },
        {
          "id": "s3q31",
          "d": "D3",
          "t": "3.2",
          "type": "multi",
          "n": 2,
          "q": "A skill performs verbose exploratory analysis and must only read files, never edit or run shell commands. Which two SKILL.md frontmatter settings best implement this? (Select two.)",
          "o": [
            "argument-hint, to list the files the skill may read.",
            "allowed-tools limited to the read-only tools the skill needs.",
            "context: fork, to run the skill in an isolated sub-agent context.",
            "description, to state that the skill is exploratory."
          ],
          "a": [
            1,
            2
          ],
          "e": "context: fork isolates verbose output from the main conversation, and allowed-tools restricts execution to the permitted read-only tools. argument-hint documents inputs but does not isolate or restrict; description aids discovery but is not an enforcement mechanism."
        },
        {
          "id": "s3q32",
          "d": "D3",
          "t": "3.3",
          "type": "single",
          "q": "Frontend conventions should apply to every .tsx and .jsx file across apps/web, apps/admin and packages/ui. What is the most maintainable rule configuration?",
          "o": [
            "A root CLAUDE.md paragraph describing frontend style.",
            "A skill that must be invoked before editing each component.",
            "A separate CLAUDE.md in every frontend directory.",
            "A .claude/rules/ file with paths for **/*.tsx and **/*.jsx."
          ],
          "a": [
            3
          ],
          "e": "Glob-scoped rules apply by file pattern across directories, so one rule covers all matching frontend files. Directory-bound CLAUDE.md files require duplication; inference from root prose is unreliable; manual skill invocation is not automatic."
        },
        {
          "id": "s3q33",
          "d": "D3",
          "t": "3.3",
          "type": "single",
          "q": "Why should conventions for a narrow file type live in a path-scoped rule rather than the always-loaded root CLAUDE.md?",
          "o": [
            "Path-scoped rules override all security policies.",
            "Path-scoped rules load only for matching files, reducing irrelevant context and token usage.",
            "Always-loaded files cannot be edited after the first session.",
            "Root CLAUDE.md cannot contain more than one convention."
          ],
          "a": [
            1
          ],
          "e": "Conditional loading keeps irrelevant guidance out of context until it applies, which saves tokens and attention. Root memory does not have a one-convention limit, path rules do not override policy, and CLAUDE.md files remain editable."
        },
        {
          "id": "s3q34",
          "d": "D3",
          "t": "3.4",
          "type": "single",
          "q": "A team must choose between two event-bus integration approaches with different infrastructure costs and operational implications. Several services will be affected. Which mode should they start in?",
          "o": [
            "A single large edit that applies both approaches behind feature flags.",
            "Direct execution, making changes in one service to see what happens.",
            "Direct execution with a prompt that says “choose the cheaper option”.",
            "Plan mode, to investigate the options and design the integration before editing code."
          ],
          "a": [
            3
          ],
          "e": "Architectural choices with multiple valid approaches and broad impact benefit from plan mode's exploration and design phase. Incremental direct execution risks costly rework; a one-line cost heuristic ignores operational tradeoffs; applying both approaches at once is not a design decision."
        },
        {
          "id": "s3q35",
          "d": "D3",
          "t": "3.4",
          "type": "single",
          "q": "A utility function is renamed and its three call sites and tests are known. The change is mechanical and well-scoped. Which approach is appropriate?",
          "o": [
            "Fork two sessions to compare rename strategies.",
            "Plan mode with a full architecture review.",
            "Direct execution of the rename and test updates.",
            "A research subagent to rediscover the call sites from scratch."
          ],
          "a": [
            2
          ],
          "e": "A mechanical, well-understood change with a known scope fits direct execution. Plan mode, forked experiments and rediscovery add overhead without reducing meaningful risk."
        },
        {
          "id": "s3q36",
          "d": "D3",
          "t": "3.5",
          "type": "single",
          "q": "A migration script mishandles null values in one specific input shape. You want the most precise correction signal. What should you provide?",
          "o": [
            "A specific failing test case with input and expected output, plus the observed incorrect output.",
            "A higher temperature so the model explores more null-handling styles.",
            "A general instruction to “handle nulls better”.",
            "A request to rewrite the entire script from scratch."
          ],
          "a": [
            0
          ],
          "e": "A concrete failing case and expected result pinpoint the transformation to fix and let the model verify its change. Vague guidance leaves the edge case undefined; a full rewrite loses working behavior; higher temperature adds variance."
        },
        {
          "id": "s3q37",
          "d": "D3",
          "t": "3.5",
          "type": "single",
          "q": "You are implementing a compliance workflow in an unfamiliar domain and may not know the right questions to ask. Which technique best surfaces hidden design considerations before coding?",
          "o": [
            "Copy a design from a different regulated industry without review.",
            "Ask for the final implementation immediately to save time.",
            "Run the test suite first and let failures define the compliance rules.",
            "Use the interview pattern: have Claude ask about obligations, failure modes and constraints before proposing a design."
          ],
          "a": [
            3
          ],
          "e": "The interview pattern surfaces considerations the developer may not have anticipated, which is valuable in unfamiliar domains. Jumping to code skips discovery; cross-industry copying may import wrong assumptions; tests cannot define obligations they were not written to check."
        },
        {
          "id": "s3q38",
          "d": "D3",
          "t": "3.6",
          "type": "single",
          "q": "A CI pipeline uses Claude Code to generate tests, but the output often ignores the team's fixture conventions and proposes low-value tests. What is the most direct improvement?",
          "o": [
            "Ask the model to use a higher temperature for creativity.",
            "Remove all existing tests so the model has more freedom.",
            "Increase the CI timeout so the agent can generate more tests.",
            "Document testing standards, valuable test criteria and available fixtures in CLAUDE.md so the CI-invoked agent receives project context."
          ],
          "a": [
            3
          ],
          "e": "CLAUDE.md supplies project-specific context such as standards, fixture conventions and what makes a valuable test, which directly improves generation. Timeouts, deleting tests and higher temperature do not teach the agent the conventions."
        },
        {
          "id": "s3q39",
          "d": "D3",
          "t": "3.6",
          "type": "single",
          "q": "A CI test-generation job keeps proposing scenarios that already exist in the repository. What context change most directly reduces duplicate tests?",
          "o": [
            "Run the job only on branches with no tests.",
            "Lower the temperature so the model repeats itself less.",
            "Ask the model to generate fewer tests overall.",
            "Include the existing test files in the generation context and ask for only uncovered scenarios."
          ],
          "a": [
            3
          ],
          "e": "Existing tests define current coverage; providing them lets the model identify gaps instead of duplicating. Arbitrarily generating fewer tests lowers coverage; restricting branches avoids the problem; temperature does not provide coverage knowledge."
        },
        {
          "id": "s3q40",
          "d": "D4",
          "t": "4.1",
          "type": "single",
          "q": "A reviewer treats every TODO comment as a defect, producing noise that hides real bugs. What instruction is most likely to improve precision?",
          "o": [
            "Ask it to review fewer files per run.",
            "Add a reminder that false positives are bad.",
            "Define explicit criteria: flag a TODO only when it marks a known correctness or security gap, and skip informational TODOs.",
            "Tell the reviewer to be conservative and report only high-confidence findings."
          ],
          "a": [
            2
          ],
          "e": "A categorical rule defines which TODOs matter and which do not, giving the model a clear boundary. Generic conservatism and reminders do not define the condition; reducing file coverage hides bugs rather than improving classification."
        },
        {
          "id": "s3q41",
          "d": "D4",
          "t": "4.1",
          "type": "single",
          "q": "A style-check category produces so many false positives that developers have started ignoring the reviewer's security findings too. What is the best trust-recovery action?",
          "o": [
            "Temporarily disable the style category while improving its criteria and examples.",
            "Increase the number of style findings so the category appears more thorough.",
            "Tell developers to read only findings labeled critical.",
            "Keep every category enabled so developers learn to distinguish good from bad findings."
          ],
          "a": [
            0
          ],
          "e": "A high false-positive category damages trust in accurate categories. Disabling it temporarily stops the noise while the criteria are improved. Keeping it enabled continues the harm; adding noise is worse; asking developers to filter manually shifts the burden."
        },
        {
          "id": "s3q42",
          "d": "D4",
          "t": "4.2",
          "type": "single",
          "q": "Generated tests cover the happy path but miss branch-level cases such as expired tokens and empty collections. Instructions alone have not helped. What few-shot design is most effective?",
          "o": [
            "Examples of test names without the corresponding code or assertions.",
            "Examples of many happy-path tests to establish a pattern.",
            "A single example of a test file with no explanation.",
            "Examples of branch-level coverage gaps that show the uncovered branch and the reasoning for adding each test."
          ],
          "a": [
            3
          ],
          "e": "Examples that demonstrate the reasoning behind branch coverage teach the model to look for decision points and edge conditions in new code. Happy-path examples reinforce the existing gap; unexplained or name-only examples do not show judgment."
        },
        {
          "id": "s3q43",
          "d": "D4",
          "t": "4.2",
          "type": "single",
          "q": "Review findings vary in structure: some include a file and line, others only prose. You need a consistent format with location, issue, severity and suggested fix. What is the most effective technique?",
          "o": [
            "Provide two to four few-shot examples that show the complete desired output shape for representative findings.",
            "Ask the model to “be consistent” in the system prompt.",
            "Describe the desired fields once in a long paragraph.",
            "Post-process the prose with an unrelated parser."
          ],
          "a": [
            0
          ],
          "e": "Few-shot examples make the target structure concrete and demonstrate how to handle representative cases. A long description is weaker, “be consistent” gives no format, and a downstream parser cannot recover information the model never produced."
        },
        {
          "id": "s3q44",
          "d": "D4",
          "t": "4.3",
          "type": "single",
          "q": "An extraction passes a strict JSON schema but puts the shipping address in the billing-address field. What does this reveal?",
          "o": [
            "The model needs a larger context window to understand field names.",
            "The schema needs to be less strict so the model can choose the best field.",
            "Strict schemas eliminate syntax errors but do not prevent semantic errors such as values in the wrong field.",
            "Tool use cannot produce structured output reliably."
          ],
          "a": [
            2
          ],
          "e": "Schema validity guarantees shape, not meaning. Wrong-field placement requires semantic validation, clearer field descriptions or examples, and possibly cross-field checks. Relaxing the schema or blaming tool use does not address semantics; a larger window is not the missing control."
        },
        {
          "id": "s3q45",
          "d": "D4",
          "t": "4.3",
          "type": "single",
          "q": "A purchase-order extractor sometimes invents an approval date because the schema marks the field as required, even though many documents never state one. What schema change is appropriate?",
          "o": [
            "Make the field nullable or optional and instruct the model to return null when the source is silent.",
            "Keep it required and add a default date of today.",
            "Remove all validation from the extraction pipeline.",
            "Ask the model to infer the date from surrounding text and label it as fact."
          ],
          "a": [
            0
          ],
          "e": "Nullable fields let the model represent absence honestly instead of fabricating a value. A default invents data; removing validation weakens quality; inferred dates presented as facts undermine accuracy."
        },
        {
          "id": "s3q46",
          "d": "D4",
          "t": "4.4",
          "type": "single",
          "q": "An extractor returns “03/04/2026” for a date field that requires ISO 8601. The schema rejects it. What retry message is most likely to correct the output?",
          "o": [
            "Increase the retry count and keep the same prompt.",
            "Resend only the instruction “return valid JSON”.",
            "Include the original document, the failed extraction and the specific format error with the expected ISO format.",
            "Start a new session with no mention of the previous failure."
          ],
          "a": [
            2
          ],
          "e": "Retry-with-error-feedback gives the model the source, its prior output and the precise defect to correct. A generic validity reminder lacks the format target; a fresh session loses the failure context; repeated identical attempts are unlikely to converge."
        },
        {
          "id": "s3q47",
          "d": "D4",
          "t": "4.4",
          "type": "single",
          "q": "A required tax ID appears only in a separate certificate that was never included in the document bundle. The extractor has retried five times. What should the pipeline do?",
          "o": [
            "Stop retrying: the evidence is absent. Supply the certificate or mark the field unavailable.",
            "Increase the retry budget because most missing fields eventually appear.",
            "Retry with a higher temperature to infer the tax ID.",
            "Change the field to a default placeholder so validation passes."
          ],
          "a": [
            0
          ],
          "e": "Retries can correct format and structural mistakes, not missing evidence. The pipeline should retrieve the source document or return an explicit unavailable value. Inference, placeholders and more retries risk fabrication."
        },
        {
          "id": "s3q48",
          "d": "D4",
          "t": "4.5",
          "type": "single",
          "q": "Before submitting 20,000 invoices to the Message Batches API, you want to maximize first-pass success and avoid costly resubmission. What should you do?",
          "o": [
            "Submit all 20,000 immediately and fix failures after the batch returns.",
            "Refine the prompt and schema on a small sample set, measure quality, then batch the full volume.",
            "Skip validation because batch processing guarantees correct structured output.",
            "Use the synchronous API for all 20,000 because it is always cheaper."
          ],
          "a": [
            1
          ],
          "e": "Sample-set refinement exposes schema and prompt problems before committing the full batch, improving first-pass success. Large-scale trial-and-error increases resubmission cost; synchronous processing defeats the batch savings; batching does not guarantee semantic correctness."
        },
        {
          "id": "s3q49",
          "d": "D4",
          "t": "4.5",
          "type": "single",
          "q": "A batch returns results out of order, and some requests failed. How should the application correlate each response with its input and identify failures?",
          "o": [
            "Use the custom_id assigned to each request to map responses and select failures for resubmission.",
            "Resubmit the entire batch and discard the first result set.",
            "Assume responses are in the same order as requests.",
            "Use the response timestamp as the primary key."
          ],
          "a": [
            0
          ],
          "e": "custom_id is the stable correlation key for batch request/response pairs. Order is not guaranteed, timestamps are not unique identifiers, and resubmitting everything repeats successful work."
        },
        {
          "id": "s3q50",
          "d": "D4",
          "t": "4.6",
          "type": "single",
          "q": "A model writes a patch and then reviews it in the same session. It misses a subtle concurrency bug it introduced, even with extended thinking. What is the most reliable improvement?",
          "o": [
            "Ask the generator to explain why the patch cannot have bugs.",
            "Review the patch in an independent Claude instance that lacks the generator's reasoning context.",
            "Ask the same session to review again with a stronger instruction.",
            "Increase the generator's temperature during the review."
          ],
          "a": [
            1
          ],
          "e": "Self-review retains the generator's assumptions and rationalizations, so subtle issues can survive. An independent instance examines the artifact without that anchor. Re-prompting, temperature changes and self-justification do not create independence."
        },
        {
          "id": "s3q51",
          "d": "D4",
          "t": "4.6",
          "type": "single",
          "q": "A 60-file review produces shallow comments on some files and misses an integration bug that spans three modules. How should the review be restructured?",
          "o": [
            "Use per-file local review passes plus a separate cross-file integration pass.",
            "Use one pass with a larger context window and a request for thoroughness.",
            "Review only the three modules involved in the integration bug.",
            "Run two identical full reviews and keep only duplicate findings."
          ],
          "a": [
            0
          ],
          "e": "Per-file passes give consistent local depth, and a separate integration pass focuses on cross-module flows. A larger window does not guarantee attention; reviewing only known modules misses unknown issues; duplicate-only findings suppress real bugs."
        },
        {
          "id": "s3q52",
          "d": "D5",
          "t": "5.1",
          "type": "single",
          "q": "Subagents return long reasoning chains to a downstream synthesis agent with a limited context budget. The synthesis misses key facts and citations. What change best fits the downstream constraint?",
          "o": [
            "Ask the synthesis agent to summarize the reasoning before reading it.",
            "Increase every upstream agent's temperature so the reasoning is shorter.",
            "Pass the full reasoning chains but remove all citations.",
            "Have upstream agents return structured key facts, citations and relevance scores instead of verbose reasoning."
          ],
          "a": [
            3
          ],
          "e": "Structured, compact outputs preserve what downstream synthesis needs: facts, provenance and relevance, without consuming the budget on reasoning chains. Temperature does not shorten content; removing citations destroys attribution; asking synthesis to summarize still requires ingesting the oversized input."
        },
        {
          "id": "s3q53",
          "d": "D5",
          "t": "5.2",
          "type": "multi",
          "n": 2,
          "q": "Which two conditions are appropriate escalation triggers? (Select two.)",
          "o": [
            "The request needs a policy exception, or policy is silent on the specific request.",
            "The model's self-reported confidence is below an arbitrary threshold.",
            "The customer explicitly requests a human agent.",
            "The customer uses negative language in the first message."
          ],
          "a": [
            0,
            2
          ],
          "e": "Explicit customer preference and genuine policy gaps are valid triggers. Self-reported confidence is poorly calibrated, and sentiment does not reliably indicate complexity or authority needs."
        },
        {
          "id": "s3q54",
          "d": "D5",
          "t": "5.2",
          "type": "single",
          "q": "An agent escalates when its self-reported confidence is below 6/10, but it is confidently wrong on hard policy cases and unconfidently correct on easy ones. What is the best fix?",
          "o": [
            "Raise the threshold to 8/10 so fewer cases are escalated.",
            "Replace the confidence threshold with explicit escalation criteria and few-shot examples of escalate-versus-resolve decisions.",
            "Remove escalation entirely and let the agent decide every case.",
            "Use sentiment analysis instead of confidence to trigger escalation."
          ],
          "a": [
            1
          ],
          "e": "Self-reported confidence is poorly calibrated for case difficulty. Explicit criteria and examples define when authority, policy or capability requires a human. Adjusting the threshold or switching to sentiment keeps an unreliable proxy; removing escalation violates policy and safety needs."
        },
        {
          "id": "s3q55",
          "d": "D5",
          "t": "5.3",
          "type": "single",
          "q": "A research subagent catches all exceptions and returns an empty list so the coordinator “does not crash”. The final report silently omits an entire source category. What is the flaw?",
          "o": [
            "The report needs a higher temperature to fill the gaps.",
            "The subagent should catch fewer exceptions but still return empty lists.",
            "Errors are suppressed instead of being propagated with structured context and coverage annotations.",
            "The coordinator should have used a larger model."
          ],
          "a": [
            2
          ],
          "e": "Suppressing errors converts failures into false success and hides coverage gaps. The subagent should recover locally where possible and propagate unresolved errors with failure type, attempted work, partial results and annotations. Model size, partial suppression and temperature do not fix the missing signal."
        },
        {
          "id": "s3q56",
          "d": "D5",
          "t": "5.3",
          "type": "single",
          "q": "An MCP search returns zero matches after a successful request, while another call times out. The coordinator currently treats both as “empty”. Why is this a problem?",
          "o": [
            "Zero matches should be reported as a permission error.",
            "Both should always trigger a retry with the same query.",
            "Timeouts should be returned as successful empty results to keep the workflow moving.",
            "A valid empty result is a successful query with no matches, while a timeout is an access failure that may warrant retry or a source change."
          ],
          "a": [
            3
          ],
          "e": "The two outcomes require different recovery decisions. A valid empty result means the query ran; a timeout means access failed and may be retried or replaced. Collapsing them prevents intelligent recovery and can hide coverage gaps."
        },
        {
          "id": "s3q57",
          "d": "D5",
          "t": "5.4",
          "type": "single",
          "q": "A multi-phase codebase investigation is about to spawn a new set of subagents for the next phase. The main agent's context is near its limit. What should happen before spawning?",
          "o": [
            "Summarize the key findings from the completed phase and inject those summaries into the next subagents' initial context.",
            "Ask the new subagents to rediscover the codebase independently.",
            "Pass the entire raw discovery log to every new subagent.",
            "Delete all prior findings so the next phase starts clean."
          ],
          "a": [
            0
          ],
          "e": "Phase summaries preserve validated knowledge in a compact form and give the next subagents a useful starting point. Raw logs consume the same context problem; independent rediscovery wastes work; deleting findings loses progress."
        },
        {
          "id": "s3q58",
          "d": "D5",
          "t": "5.5",
          "type": "multi",
          "n": 2,
          "q": "Which two extraction results should be prioritized for human review when reviewer capacity is limited? (Select two.)",
          "o": [
            "Fields with low calibrated confidence scores.",
            "All documents from the most common document type.",
            "Extractions with high overall document confidence but no field-level review.",
            "Documents whose sources are ambiguous or internally contradictory."
          ],
          "a": [
            0,
            3
          ],
          "e": "Low field-level confidence and ambiguous or contradictory source documents are the strongest signals for human attention. Reviewing an entire common document type ignores risk concentration, and high overall confidence can mask field-level errors."
        },
        {
          "id": "s3q59",
          "d": "D5",
          "t": "5.5",
          "type": "single",
          "q": "An extraction system reports 96% accuracy overall. Before reducing human review, what analysis is most important?",
          "o": [
            "The average length of the extracted JSON.",
            "Accuracy by document type and field segment, to verify consistent performance across all segments.",
            "The model's overall confidence score for the last week.",
            "The number of documents processed per hour."
          ],
          "a": [
            1
          ],
          "e": "Aggregate accuracy can hide poor performance on a document type or field. Segment-level analysis is required before reducing review. Overall confidence, throughput and output length do not establish consistent correctness."
        },
        {
          "id": "s3q60",
          "d": "D5",
          "t": "5.6",
          "type": "single",
          "q": "A synthesis agent compresses findings from several sources into a narrative and loses which source supported each claim. What should upstream agents provide to prevent this?",
          "o": [
            "Only the final statistics without source metadata to reduce tokens.",
            "A single confidence score for the entire report.",
            "Longer narrative summaries so the source is implied by the writing style.",
            "Structured claim-source mappings with source URLs, document names and relevant excerpts that synthesis must preserve and merge."
          ],
          "a": [
            3
          ],
          "e": "Claim-source mappings carry provenance through summarization and can be merged during synthesis. Narrative style does not identify a source; dropping metadata makes attribution unrecoverable; a single score does not map claims to evidence."
        }
      ]
    }
  ]
};
