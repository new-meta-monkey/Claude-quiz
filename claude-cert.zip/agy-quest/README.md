# Claude Certified Architect — Foundations (CCA-F / CCAR-F) Quiz Lab

An interactive, responsive mock exam and study lab designed to prepare candidates for the **Anthropic Claude Certified Architect — Foundations** certification.

---

## 🎯 Exam Blueprint & Domain Weightage

The official CCA-F exam contains **60 scenario-based questions**, has a **120-minute** time limit, and requires a scaled passing score of **720 / 1000** (~72%).

| Domain | Focus Area | Exam Weight | Questions / 60 |
| :--- | :--- | :---: | :---: |
| **Domain 1** | **Agentic Architecture & Orchestration** | **27%** | **16** |
| **Domain 2** | **Tool Design & MCP Integration** | **18%** | **11** |
| **Domain 3** | **Claude Code Configuration & Workflows** | **20%** | **12** |
| **Domain 4** | **Prompt Engineering & Structured Output** | **20%** | **12** |
| **Domain 5** | **Context Management & Reliability** | **15%** | **9** |
| **Total** | | **100%** | **60 Items** |

---

## 📦 What's Inside `agy-quest/`

This folder contains **180 unique, non-repeating scenario questions** divided across three complete mock sets:

1. **Set 1: Core Judgment (60 questions)**  
   Balanced real-world architectural scenarios evaluating agent loops, subagent boundaries, MCP tool schemas, and prompt caching.
2. **Set 2: Production Failure Modes (60 questions)**  
   Heavier on orchestration error recovery, multi-agent degradation, CI/CD headless execution, and context budget management.
3. **Set 3: Trap-Heavy Finale (60 questions)**  
   Specifically models common candidate traps: prompt-level band-aids vs architectural fixes, self-review bias, tool over-provisioning, and prefix caching invalidation.

### Files Overview
* [`index.html`](file:///data/data/com.termux/files/home/claude-cert/agy-quest/index.html) — **Complete standalone single-file Web App**. Works completely offline in any modern browser on mobile, tablet, or desktop with zero external dependencies.
* [`questions.js`](file:///data/data/com.termux/files/home/claude-cert/agy-quest/questions.js) — Unified JSON dataset containing all 180 questions and metadata.
* [`data-set1.js`](file:///data/data/com.termux/files/home/claude-cert/agy-quest/data-set1.js) — Set 1 modular question array.
* [`data-set2.js`](file:///data/data/com.termux/files/home/claude-cert/agy-quest/data-set2.js) — Set 2 modular question array.
* [`data-set3.js`](file:///data/data/com.termux/files/home/claude-cert/agy-quest/data-set3.js) — Set 3 modular question array.

---

## ⚡ Quiz App Features

* **Two Distinct Modes**:
  * **Practice Mode**: Answers, keys, and in-depth rationales are revealed **immediately** upon selecting an option (or checking multi-select items).
  * **Exam Simulation Mode**: Feedback is hidden until the entire set is submitted. Features an official **120-minute countdown timer** with auto-submission, scaled 100–1000 scoring, domain-by-domain diagnostic bar charts, and a pass/fail indicator based on the 720 standard.
* **Full Mobile & Touch Responsiveness**:
  * Floating bottom toolbar on mobile devices (`<= 880px`) with **Prev**, **Next**, and **Map** controls.
  * Slide-over Question Palette drawer for rapid jumping between questions.
  * Visual indicators for Answered, Flagged, and Current questions.
  * Safe-area insets supported for modern mobile gesture bars.
* **In-Depth Rationale & Review**:
  * Filter review by **All**, **Incorrect**, or **Flagged**.
  * Explains not only why the key is correct, but why plausible distractors (traps) fail in production architectures.
* **Persistence & Dynamic Shuffling**:
  * Questions are automatically shuffled using the Fisher-Yates algorithm every time a new attempt or mock set is entered.
  * Automatically saves in-progress attempts to `localStorage` (preserving your active shuffled order) so you never lose your answers when switching tabs or refreshing. Option to resume or start fresh with a new shuffle.

---

## 🚀 How to Run the Quiz App

### Option A: Direct Browser File (Fastest)
Open [`index.html`](file:///data/data/com.termux/files/home/claude-cert/agy-quest/index.html) directly in any web browser (Chrome, Firefox, Safari, Edge).

### Option B: Local Web Server
Run Python's built-in HTTP server from the `agy-quest` directory:
```bash
cd /data/data/com.termux/files/home/claude-cert/agy-quest
python3 -m http.server 8080
```
Then navigate to `http://localhost:8080` in your browser.

---

## 🧠 Core Exam Trap Patterns Tested

Based on candidate reviews and dumps, watch out for these recurring pitfalls:
1. **Loop Termination**: Never parse natural language strings (e.g., *"I have completed your request"*). The programmatic termination signal is checking `stop_reason === "end_turn"`.
2. **Subagent Memory**: Subagents **never** inherit the coordinator's conversation history implicitly. The coordinator must explicitly provide required context in the subagent's prompt.
3. **Self-Review Bias**: An agent cannot objectively audit code it generated within the same session. Production pipelines require an independent review instance with fresh context.
4. **Structured Outputs**: Forcing negative prompts (*"Do not include markdown or explanations"*) is fragile; use tool calling (`tool_choice: {"type": "tool", "name": "..."}`) or assistant message prefill (`{`).
5. **Prompt Caching Rules**: Cache invalidation is 100% prefix-matched. Putting dynamic variables (like timestamps) at the start of a prompt breaks cache hits for all subsequent tokens. Also note the minimum token thresholds (1,024 for Sonnet/Opus, 2,048 for Haiku).
