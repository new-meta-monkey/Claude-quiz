window.SET3_QUESTIONS = [
  {
    "id": "s3q01",
    "d": "D1",
    "t": "1.1",
    "type": "single",
    "q": "Each time the agent loop calls the model again, it sends only the newest tool result instead of the full conversation. The model forgets the original request and contradicts earlier findings. What is the defect?",
    "o": [
      "The loop needs a higher iteration cap to recover the lost context.",
      "The request omits prior assistant and tool messages, so the model cannot reason over the conversation so far.",
      "The tool result should be returned as a user message with no tool_use ID.",
      "The model temperature is too high for a multi-step task."
    ],
    "a": [
      1
    ],
    "e": "Every model call must include the accumulated conversation, including prior assistant tool_use blocks and matching tool_result blocks. Sending only the latest result removes the evidence and reasoning the model needs. Temperature, ID removal and iteration caps do not restore history."
  },
  {
    "id": "s3q02",
    "d": "D1",
    "t": "1.1",
    "type": "single",
    "q": "The model returns three parallel tool_use blocks in one assistant turn. The loop executes only the first block and sends one tool_result, so the model repeats the other two calls. What should the loop do?",
    "o": [
      "Ask the model to return a single tool call in every response.",
      "Execute every requested tool_use block and append a matching tool_result for each before the next model turn.",
      "Execute only the first tool and instruct the model to request the others one at a time.",
      "Discard the extra tool_use blocks because parallel calls are unsupported."
    ],
    "a": [
      1
    ],
    "e": "A single assistant turn can contain multiple tool_use blocks. All should be executed and all matching tool_result blocks returned so the model can continue. Dropping or serializing them breaks the protocol and adds unnecessary turns."
  },
  {
    "id": "s3q03",
    "d": "D1",
    "t": "1.1",
    "type": "single",
    "q": "A support workflow was built as a fixed sequence: get_customer, then lookup_order, then process_refund. It fails whenever a customer asks only about an order or has a billing dispute with no refund. What is the better design?",
    "o": [
      "Add more branches to the fixed decision tree until every request type is covered.",
      "Let the model choose the next tool based on context, while keeping programmatic gates for critical rules such as identity before refund.",
      "Randomize the tool order so the agent explores different workflows.",
      "Always execute all three tools in sequence so no path is missed."
    ],
    "a": [
      1
    ],
    "e": "Model-driven tool selection handles varied requests, while deterministic gates protect critical invariants. Enumerating every branch is brittle, running irrelevant tools wastes calls and can cause harm, and randomization is not a workflow."
  },
  {
    "id": "s3q04",
    "d": "D1",
    "t": "1.2",
    "type": "multi",
    "n": 2,
    "q": "In a hub-and-spoke multi-agent system, which two responsibilities belong to the coordinator? (Select two.)",
    "o": [
      "Implementing each subagent's specialized tool integrations.",
      "Aggregating results, routing information and handling errors across subagents.",
      "Allowing subagents to negotiate directly with each other outside the hub.",
      "Decomposing the query and deciding which subagents to invoke."
    ],
    "a": [
      1,
      3
    ],
    "e": "The coordinator owns decomposition, delegation, aggregation, routing and consistent error handling. Subagent tool implementation is local to each specialist, and peer negotiation bypasses the observability and control the hub provides."
  },
  {
    "id": "s3q05",
    "d": "D1",
    "t": "1.2",
    "type": "single",
    "q": "A coordinator sends the same broad query to four research subagents. Their outputs overlap heavily and still miss two important subtopics. What decomposition change is most effective?",
    "o": [
      "Reduce the team to one subagent so duplication is impossible.",
      "Send the same query to six subagents to increase the chance of coverage.",
      "Ask each subagent to work sequentially after reading the previous agent's output.",
      "Assign distinct subtopics or source types to each subagent so coverage is partitioned."
    ],
    "a": [
      3
    ],
    "e": "Partitioning scope across specialists reduces duplicated effort and makes coverage gaps visible. Repeating the same query scales duplication rather than coverage; sequential sharing reduces parallelism; collapsing to one agent loses specialization."
  },
  {
    "id": "s3q06",
    "d": "D1",
    "t": "1.3",
    "type": "single",
    "q": "The coordinator invokes the same search subagent twice. On the second call, it asks the subagent to “use what you found earlier”, but the subagent returns unrelated results. Why?",
    "o": [
      "The Task tool caches results only when tool_choice is forced.",
      "The subagent's model has a smaller context window than the coordinator.",
      "Subagent invocations do not share memory automatically; earlier findings must be included in the new prompt.",
      "The coordinator should have used a fork instead of a fresh invocation."
    ],
    "a": [
      2
    ],
    "e": "Each subagent invocation starts with isolated context. Findings from a previous call must be explicitly passed in the new prompt. Context-window size, tool_choice and forking do not create automatic memory between invocations."
  },
  {
    "id": "s3q07",
    "d": "D1",
    "t": "1.3",
    "type": "single",
    "q": "A coordinator prompt gives each subagent a rigid ten-step procedure. When a source is unavailable, subagents cannot adapt and return incomplete work. What prompt change best improves adaptability?",
    "o": [
      "Specify the research goal, constraints and quality criteria, and let the subagent choose how to achieve them.",
      "Add five more procedural steps to cover more failure cases.",
      "Give the subagent every tool in the system so no step is blocked.",
      "Raise the subagent's temperature so it improvises more."
    ],
    "a": [
      0
    ],
    "e": "Goal-and-criteria prompts preserve the objective while allowing the subagent to adapt its method to what it discovers. More steps are still brittle, temperature is not a strategy, and over-provisioning tools increases misuse."
  },
  {
    "id": "s3q08",
    "d": "D1",
    "t": "1.4",
    "type": "single",
    "q": "A returns workflow must not refund an order until lookup_order confirms the item was delivered. The agent sometimes refunds undelivered orders despite a clear prompt. What control best guarantees the order?",
    "o": [
      "Few-shot examples of correct refunds after delivery.",
      "A programmatic prerequisite that blocks process_refund until a delivered status is present in the case state.",
      "A stronger prompt that underlines the delivery requirement.",
      "A daily report that lists refunds issued before delivery."
    ],
    "a": [
      1
    ],
    "e": "A gate tied to verified delivered status enforces the workflow deterministically. Prompting and examples remain probabilistic, and after-the-fact reporting does not prevent the financial error."
  },
  {
    "id": "s3q09",
    "d": "D1",
    "t": "1.4",
    "type": "single",
    "q": "The agent issues a partial refund, then escalates the remaining dispute to a human. The customer is refunded twice because the handoff does not mention the first transaction. What should the handoff contain?",
    "o": [
      "Only the customer's original message and the escalation reason.",
      "A request for the customer to repeat the case history to the human agent.",
      "The full tool-call log with every request and response payload.",
      "The completed action with transaction ID and amount, plus pending steps and a recommended next action."
    ],
    "a": [
      3
    ],
    "e": "A safe handoff summarizes state: what has already happened, identifiable transaction references, what remains, and what should happen next. Without completed-action context, the human can duplicate work. Raw logs are noisy, and asking the customer to repeat is poor service."
  },
  {
    "id": "s3q10",
    "d": "D1",
    "t": "1.5",
    "type": "single",
    "q": "A multi-tenant agent must ensure every backend tool call is scoped to the current tenant. The model sometimes omits the tenant ID from tool arguments, leaking data across tenants. What control is appropriate?",
    "o": [
      "A PostToolUse hook that filters the response after the query has run.",
      "A few-shot example showing a tenant-scoped request.",
      "A tool-call interception hook that validates or injects the tenant ID before the tool executes.",
      "A system-prompt reminder to always include the tenant ID."
    ],
    "a": [
      2
    ],
    "e": "Tenant isolation is a security invariant and must be enforced before execution. A pre-execution hook can inject or reject calls lacking tenant scope. Prompting and examples are probabilistic; filtering after the query has already accessed another tenant's data is too late."
  },
  {
    "id": "s3q11",
    "d": "D1",
    "t": "1.5",
    "type": "single",
    "q": "Compliance requires an audit record for every tool invocation, including arguments and outcome. A prompt instruction to “remember to log” still misses about 2% of calls. What should be used?",
    "o": [
      "A hook that records each tool call and result at the tool boundary.",
      "A larger system prompt that repeats the logging requirement.",
      "Random sampling of tool calls followed by manual reconstruction.",
      "A weekly report generated from the model's memory of the session."
    ],
    "a": [
      0
    ],
    "e": "A hook at the tool boundary observes every invocation deterministically, independent of model compliance. Prompt repetition is still probabilistic; sampling misses calls; model memory is not an audit trail."
  },
  {
    "id": "s3q12",
    "d": "D1",
    "t": "1.6",
    "type": "single",
    "q": "A contract review must analyze every clause in a fixed order, then run a consistency pass across clauses. The stages are known and repeatable. Which decomposition fits?",
    "o": [
      "Prompt chaining: clause-level passes in a fixed order followed by a cross-clause consistency pass.",
      "Dynamic decomposition that invents a new review order each time.",
      "A coordinator that randomly assigns clauses to available agents.",
      "A single prompt containing the whole contract and no staging."
    ],
    "a": [
      0
    ],
    "e": "Predictable, repeatable stages fit prompt chaining, which preserves order and passes each stage's output forward. Dynamic decomposition is for uncertain investigation; one giant pass dilutes attention; random assignment breaks the required review order."
  },
  {
    "id": "s3q13",
    "d": "D1",
    "t": "1.6",
    "type": "single",
    "q": "You need to improve a slow API endpoint, but you do not know whether the bottleneck is database queries, serialization or an external call. What decomposition strategy fits?",
    "o": [
      "Ask the model to guess the bottleneck from the endpoint name.",
      "Rewrite the entire service before measuring anything.",
      "A fixed plan that optimizes the database first because that is usually the cause.",
      "An adaptive plan: profile, identify the current hot path, then choose the next investigation or fix based on evidence."
    ],
    "a": [
      3
    ],
    "e": "Performance work is evidence-driven. Adaptive decomposition uses profiling results to direct the next step. A fixed guess may optimize the wrong layer; a rewrite is risky and unfocused; guessing from a name is not diagnosis."
  },
  {
    "id": "s3q14",
    "d": "D1",
    "t": "1.7",
    "type": "single",
    "q": "You resume a named session after modifying three files that the agent previously analyzed. The agent starts re-reading the entire repository. What instruction would make the resumed work more efficient?",
    "o": [
      "Ask the agent to forget all previous analysis and start over.",
      "Resume without any note and let the agent discover changes by reading everything.",
      "Tell the agent exactly which files changed and ask it to re-analyze only those, reusing prior findings elsewhere.",
      "Fork the session and delete the original branch."
    ],
    "a": [
      2
    ],
    "e": "Resumption is most efficient when the agent knows which evidence is stale. Naming changed files enables targeted re-analysis while preserving valid prior work. Full re-reading wastes effort; forgetting everything discards useful context; forking does not communicate changes."
  },
  {
    "id": "s3q15",
    "d": "D1",
    "t": "1.7",
    "type": "single",
    "q": "After a shared schema analysis, you want one branch to test a normalized-table design and another to test a document-store design, then compare results. Which session pattern fits?",
    "o": [
      "Delete the original analysis so each design starts without bias.",
      "Use fork_session to create independent branches from the shared analysis baseline.",
      "Use --resume to alternate between designs in the same conversation.",
      "Run both designs in one session and ask the model to keep them mentally separate."
    ],
    "a": [
      1
    ],
    "e": "Forking preserves the common baseline while isolating divergent experiments. Mixing designs in one context creates cross-contamination; alternating in one session has the same problem; deleting the baseline wastes valid analysis."
  },
  {
    "id": "s3q16",
    "d": "D1",
    "t": "1.7",
    "type": "single",
    "q": "You fork a session into branch A and branch B. Branch A discovers a critical constraint and updates its plan. Branch B continues with the old assumptions. What is the correct interpretation?",
    "o": [
      "Forked branches are independent; findings from A must be explicitly passed to B if they should influence it.",
      "Forked branches share updates automatically, so branch B must have a bug.",
      "Branch B will inherit the update on its next model call.",
      "Forking should only be used after all analysis is complete."
    ],
    "a": [
      0
    ],
    "e": "Forking creates independent branches from a shared starting point; later changes do not synchronize automatically. If branch B should use A's constraint, the coordinator or developer must pass it explicitly. Automatic inheritance and deferred sync are misconceptions."
  },
  {
    "id": "s3q17",
    "d": "D2",
    "t": "2.1",
    "type": "single",
    "q": "Two tools, search_web and search_news, have nearly identical descriptions. The agent uses search_news for general product documentation and search_web for recent headlines. What is the best fix?",
    "o": [
      "Rename both tools with random IDs so the model cannot confuse them.",
      "Rewrite each description to define its source scope, typical queries, output type and boundary versus the other tool.",
      "Consolidate them into one tool that returns every source type.",
      "Add a rule that search_news must always be called first."
    ],
    "a": [
      1
    ],
    "e": "Overlapping descriptions cause misrouting. Explicit source scope, query examples, output type and boundaries let the model distinguish them. A forced order is wrong for many requests, random names remove meaning, and consolidation may be a larger design choice rather than the first fix."
  },
  {
    "id": "s3q18",
    "d": "D2",
    "t": "2.1",
    "type": "single",
    "q": "A billing tool returns amounts in cents, but its description does not say so. The agent tells customers their $49.00 charge is $4,900. What description change best prevents this?",
    "o": [
      "Increase the model temperature so it considers alternative interpretations.",
      "Add “be careful with numbers” to the system prompt.",
      "State the output units, format and an example value in the tool description.",
      "Rename the tool to billing_amounts_cents."
    ],
    "a": [
      2
    ],
    "e": "Tool descriptions should define output formats and units; an example removes ambiguity. A vague caution does not supply the missing contract, renaming alone is weaker than documented units, and higher temperature adds variance."
  },
  {
    "id": "s3q19",
    "d": "D2",
    "t": "2.1",
    "type": "single",
    "q": "A generic manage_account tool can look up, update or close accounts. The agent closes an account when the user only asks for its status. What change most directly reduces this risk?",
    "o": [
      "Add “do not close accounts unless asked” to the system prompt.",
      "Increase the number of few-shot examples that use manage_account for status.",
      "Split the tool into get_account_status, update_account and close_account with distinct descriptions and permissions.",
      "Make manage_account require a confirmation code for every call."
    ],
    "a": [
      2
    ],
    "e": "Purpose-specific tools with explicit contracts and permissions make destructive actions distinct from read-only ones. A prompt warning is probabilistic; examples for the generic tool reinforce the ambiguity; blanket confirmation adds friction without separating capabilities."
  },
  {
    "id": "s3q20",
    "d": "D2",
    "t": "2.2",
    "type": "single",
    "q": "A payment-status tool times out because the upstream service is briefly overloaded. What error response best enables the agent to recover?",
    "o": [
      "A generic “Operation failed” with no category so the agent stays flexible.",
      "errorCategory: transient, isRetryable: true, with a short explanation and guidance to retry with backoff.",
      "An empty successful response so the workflow can continue.",
      "errorCategory: validation, isRetryable: false, because the timeout is the caller's fault."
    ],
    "a": [
      1
    ],
    "e": "A timeout is typically transient and retryable, ideally with backoff. Correct classification lets the agent recover without guessing. Mislabeling it as validation prevents retry; generic errors hide the decision; empty success suppresses a recoverable failure."
  },
  {
    "id": "s3q21",
    "d": "D2",
    "t": "2.2",
    "type": "single",
    "q": "A tool rejects a request because the `account_id` field is missing from the arguments. Which response best helps the agent correct the call?",
    "o": [
      "errorCategory: validation, isRetryable: false, naming the missing field and its expected format.",
      "errorCategory: transient, isRetryable: true, with no further detail.",
      "An empty successful response so the agent moves on.",
      "A generic “Bad request” with an HTTP status code only."
    ],
    "a": [
      0
    ],
    "e": "A validation error should identify the offending field and expected input so the agent can repair the arguments. Repeating the identical call will fail; a generic status lacks the correction path; empty success hides the problem."
  },
  {
    "id": "s3q22",
    "d": "D2",
    "t": "2.3",
    "type": "single",
    "q": "A synthesis agent needs to verify publication dates for about 85% of its claims; the remaining 15% require deeper source investigation. Currently every check round-trips through the coordinator. What is the best change?",
    "o": [
      "Give the synthesis agent every search and retrieval tool so it never needs help.",
      "Give the synthesis agent a scoped verify_source_date tool for simple date checks, while complex investigations still route through the coordinator.",
      "Make the synthesis agent return all verification requests in one batch at the end.",
      "Preload every possible date from the initial search results."
    ],
    "a": [
      1
    ],
    "e": "A narrow cross-role tool covers the high-frequency, low-risk case while preserving the coordinator path for complex work. Granting all tools violates specialization; batching creates blocking dependencies; speculative preloading cannot cover every claim."
  },
  {
    "id": "s3q23",
    "d": "D2",
    "t": "2.3",
    "type": "single",
    "q": "To guarantee metadata extraction, a pipeline forces tool_choice to extract_metadata on the first turn. The same forced setting remains active on later turns, so enrichment tools can never run. What is the correct configuration?",
    "o": [
      "Remove all enrichment tools from the pipeline.",
      "Set tool_choice to “auto” from the start and hope metadata is chosen first.",
      "Force extract_metadata only on the first turn, then switch to “auto” or “any” for subsequent turns.",
      "Keep the forced selection forever and add enrichment as a second schema field."
    ],
    "a": [
      2
    ],
    "e": "tool_choice applies per request. Forcing the first step guarantees metadata extraction, but subsequent turns need a different setting so other tools can be selected. Keeping the force locks the workflow; “auto” from the start does not guarantee order; removing enrichment loses functionality."
  },
  {
    "id": "s3q24",
    "d": "D2",
    "t": "2.4",
    "type": "single",
    "q": "A developer adds a new MCP server to the project configuration while a Claude Code session is already running. The agent cannot see the server's tools. What is the most likely explanation?",
    "o": [
      "MCP tools are discovered at connection time, so the session must reconnect or restart to load the new server.",
      "The server's tools must be copied into CLAUDE.md before they appear.",
      "The model must be given a tool_choice forcing the new server by name.",
      "MCP servers only work in user-scoped configuration."
    ],
    "a": [
      0
    ],
    "e": "Tools from configured MCP servers are discovered when the connection is established. A running session does not automatically see a newly added server until it reconnects or restarts. CLAUDE.md, user scope and tool_choice do not perform discovery."
  },
  {
    "id": "s3q25",
    "d": "D2",
    "t": "2.4",
    "type": "single",
    "q": "A team needs standard Jira integration: search issues, read comments and create tickets. A developer proposes writing a custom MCP server from scratch. What is the better decision?",
    "o": [
      "Build a custom server for every integration to maximize control.",
      "Expose the Jira CLI through Bash and let the model construct commands.",
      "Avoid MCP entirely and paste Jira data into prompts manually.",
      "Use a maintained community MCP server for standard Jira capabilities, reserving custom servers for team-specific workflows."
    ],
    "a": [
      3
    ],
    "e": "For standard integrations, an existing community MCP server reduces build and maintenance effort. Custom servers make sense for workflows unique to the team. Rebuilding standard integrations, manual pasting and shell command construction add risk and effort."
  },
  {
    "id": "s3q26",
    "d": "D2",
    "t": "2.5",
    "type": "single",
    "q": "An agent needs to run the project's test suite and inspect the failure output before proposing a fix. Which built-in tool is appropriate?",
    "o": [
      "Glob, to list every test file.",
      "Edit, to rewrite the failing test before running it.",
      "Grep, to search test files for the word “fail”.",
      "Bash, to execute the test command and capture its output."
    ],
    "a": [
      3
    ],
    "e": "Bash executes commands and returns stdout/stderr, which is needed to run tests and see failures. Grep and Glob inspect files but do not execute the suite; editing before seeing the failure skips diagnosis."
  },
  {
    "id": "s3q27",
    "d": "D2",
    "t": "2.5",
    "type": "single",
    "q": "A search for the symbol `apply_discount` returns dozens of matches in comments, documentation and unrelated strings. You need the actual import and call sites. What is the best search strategy?",
    "o": [
      "Use Glob for files named apply_discount.",
      "Use Bash to print every line containing the word and ignore the surrounding context.",
      "Use Grep with patterns for imports and definitions, then Read the matching files along the call chain.",
      "Read every source file to avoid missing a match."
    ],
    "a": [
      2
    ],
    "e": "Targeted content patterns narrow the result set to meaningful import or definition sites, and Reading the surrounding files confirms usage. Glob only matches filenames; reading everything is wasteful; raw word matches still include comments and docs."
  },
  {
    "id": "s3q28",
    "d": "D3",
    "t": "3.1",
    "type": "single",
    "q": "A package inside a monorepo has special build conventions that should apply only when working inside that package. Where should those instructions live?",
    "o": [
      "In the user-level ~/.claude/CLAUDE.md so they are always available.",
      "In a personal skill stored outside the repository.",
      "In a CLAUDE.md at that package's directory level, scoped to the package.",
      "In the root CLAUDE.md without any directory scoping."
    ],
    "a": [
      2
    ],
    "e": "Directory-level CLAUDE.md files scope instructions to their subtree, which matches package-specific conventions. User-level memory is personal and global; root instructions apply everywhere; an external personal skill is not shared project context."
  },
  {
    "id": "s3q29",
    "d": "D3",
    "t": "3.1",
    "type": "single",
    "q": "A developer wants a set of shortcuts and preferences available in every project on their own machine, without imposing them on teammates. Which configuration level fits?",
    "o": [
      "A .claude/rules/ file scoped to one package.",
      "A root CLAUDE.md with a note that the rules are optional.",
      "User-level ~/.claude/CLAUDE.md on that developer's machine.",
      "Project-level .claude/CLAUDE.md committed to each repository."
    ],
    "a": [
      2
    ],
    "e": "User-level memory applies only to that user across projects and is not shared through version control. Project and path-scoped files would affect teammates or be limited to one repository."
  },
  {
    "id": "s3q30",
    "d": "D3",
    "t": "3.2",
    "type": "single",
    "q": "A release checklist is used only occasionally and should not consume context on every task. What is the best way to package it?",
    "o": [
      "Add it to the system prompt of every subagent.",
      "Create an on-demand skill or slash command that developers invoke when needed.",
      "Put it in every developer's user-level CLAUDE.md.",
      "Put the full checklist in the root CLAUDE.md so it is always loaded."
    ],
    "a": [
      1
    ],
    "e": "On-demand workflows belong in skills or commands so they load when invoked. CLAUDE.md is for always-loaded standards; duplicating the checklist in user memory or every subagent still wastes context and spreads maintenance."
  },
  {
    "id": "s3q31",
    "d": "D3",
    "t": "3.2",
    "type": "multi",
    "n": 2,
    "q": "A skill performs verbose exploratory analysis and must only read files, never edit or run shell commands. Which two SKILL.md frontmatter settings best implement this? (Select two.)",
    "o": [
      "argument-hint, to list the files the skill may read.",
      "allowed-tools limited to the read-only tools the skill needs.",
      "context: fork, to run the skill in an isolated sub-agent context.",
      "description, to state that the skill is exploratory."
    ],
    "a": [
      1,
      2
    ],
    "e": "context: fork isolates verbose output from the main conversation, and allowed-tools restricts execution to the permitted read-only tools. argument-hint documents inputs but does not isolate or restrict; description aids discovery but is not an enforcement mechanism."
  },
  {
    "id": "s3q32",
    "d": "D3",
    "t": "3.3",
    "type": "single",
    "q": "Frontend conventions should apply to every .tsx and .jsx file across apps/web, apps/admin and packages/ui. What is the most maintainable rule configuration?",
    "o": [
      "A root CLAUDE.md paragraph describing frontend style.",
      "A skill that must be invoked before editing each component.",
      "A separate CLAUDE.md in every frontend directory.",
      "A .claude/rules/ file with paths for **/*.tsx and **/*.jsx."
    ],
    "a": [
      3
    ],
    "e": "Glob-scoped rules apply by file pattern across directories, so one rule covers all matching frontend files. Directory-bound CLAUDE.md files require duplication; inference from root prose is unreliable; manual skill invocation is not automatic."
  },
  {
    "id": "s3q33",
    "d": "D3",
    "t": "3.3",
    "type": "single",
    "q": "Why should conventions for a narrow file type live in a path-scoped rule rather than the always-loaded root CLAUDE.md?",
    "o": [
      "Path-scoped rules override all security policies.",
      "Path-scoped rules load only for matching files, reducing irrelevant context and token usage.",
      "Always-loaded files cannot be edited after the first session.",
      "Root CLAUDE.md cannot contain more than one convention."
    ],
    "a": [
      1
    ],
    "e": "Conditional loading keeps irrelevant guidance out of context until it applies, which saves tokens and attention. Root memory does not have a one-convention limit, path rules do not override policy, and CLAUDE.md files remain editable."
  },
  {
    "id": "s3q34",
    "d": "D3",
    "t": "3.4",
    "type": "single",
    "q": "A team must choose between two event-bus integration approaches with different infrastructure costs and operational implications. Several services will be affected. Which mode should they start in?",
    "o": [
      "A single large edit that applies both approaches behind feature flags.",
      "Direct execution, making changes in one service to see what happens.",
      "Direct execution with a prompt that says “choose the cheaper option”.",
      "Plan mode, to investigate the options and design the integration before editing code."
    ],
    "a": [
      3
    ],
    "e": "Architectural choices with multiple valid approaches and broad impact benefit from plan mode's exploration and design phase. Incremental direct execution risks costly rework; a one-line cost heuristic ignores operational tradeoffs; applying both approaches at once is not a design decision."
  },
  {
    "id": "s3q35",
    "d": "D3",
    "t": "3.4",
    "type": "single",
    "q": "A utility function is renamed and its three call sites and tests are known. The change is mechanical and well-scoped. Which approach is appropriate?",
    "o": [
      "Fork two sessions to compare rename strategies.",
      "Plan mode with a full architecture review.",
      "Direct execution of the rename and test updates.",
      "A research subagent to rediscover the call sites from scratch."
    ],
    "a": [
      2
    ],
    "e": "A mechanical, well-understood change with a known scope fits direct execution. Plan mode, forked experiments and rediscovery add overhead without reducing meaningful risk."
  },
  {
    "id": "s3q36",
    "d": "D3",
    "t": "3.5",
    "type": "single",
    "q": "A migration script mishandles null values in one specific input shape. You want the most precise correction signal. What should you provide?",
    "o": [
      "A specific failing test case with input and expected output, plus the observed incorrect output.",
      "A higher temperature so the model explores more null-handling styles.",
      "A general instruction to “handle nulls better”.",
      "A request to rewrite the entire script from scratch."
    ],
    "a": [
      0
    ],
    "e": "A concrete failing case and expected result pinpoint the transformation to fix and let the model verify its change. Vague guidance leaves the edge case undefined; a full rewrite loses working behavior; higher temperature adds variance."
  },
  {
    "id": "s3q37",
    "d": "D3",
    "t": "3.5",
    "type": "single",
    "q": "You are implementing a compliance workflow in an unfamiliar domain and may not know the right questions to ask. Which technique best surfaces hidden design considerations before coding?",
    "o": [
      "Copy a design from a different regulated industry without review.",
      "Ask for the final implementation immediately to save time.",
      "Run the test suite first and let failures define the compliance rules.",
      "Use the interview pattern: have Claude ask about obligations, failure modes and constraints before proposing a design."
    ],
    "a": [
      3
    ],
    "e": "The interview pattern surfaces considerations the developer may not have anticipated, which is valuable in unfamiliar domains. Jumping to code skips discovery; cross-industry copying may import wrong assumptions; tests cannot define obligations they were not written to check."
  },
  {
    "id": "s3q38",
    "d": "D3",
    "t": "3.6",
    "type": "single",
    "q": "A CI pipeline uses Claude Code to generate tests, but the output often ignores the team's fixture conventions and proposes low-value tests. What is the most direct improvement?",
    "o": [
      "Ask the model to use a higher temperature for creativity.",
      "Remove all existing tests so the model has more freedom.",
      "Increase the CI timeout so the agent can generate more tests.",
      "Document testing standards, valuable test criteria and available fixtures in CLAUDE.md so the CI-invoked agent receives project context."
    ],
    "a": [
      3
    ],
    "e": "CLAUDE.md supplies project-specific context such as standards, fixture conventions and what makes a valuable test, which directly improves generation. Timeouts, deleting tests and higher temperature do not teach the agent the conventions."
  },
  {
    "id": "s3q39",
    "d": "D3",
    "t": "3.6",
    "type": "single",
    "q": "A CI test-generation job keeps proposing scenarios that already exist in the repository. What context change most directly reduces duplicate tests?",
    "o": [
      "Run the job only on branches with no tests.",
      "Lower the temperature so the model repeats itself less.",
      "Ask the model to generate fewer tests overall.",
      "Include the existing test files in the generation context and ask for only uncovered scenarios."
    ],
    "a": [
      3
    ],
    "e": "Existing tests define current coverage; providing them lets the model identify gaps instead of duplicating. Arbitrarily generating fewer tests lowers coverage; restricting branches avoids the problem; temperature does not provide coverage knowledge."
  },
  {
    "id": "s3q40",
    "d": "D4",
    "t": "4.1",
    "type": "single",
    "q": "A reviewer treats every TODO comment as a defect, producing noise that hides real bugs. What instruction is most likely to improve precision?",
    "o": [
      "Ask it to review fewer files per run.",
      "Add a reminder that false positives are bad.",
      "Define explicit criteria: flag a TODO only when it marks a known correctness or security gap, and skip informational TODOs.",
      "Tell the reviewer to be conservative and report only high-confidence findings."
    ],
    "a": [
      2
    ],
    "e": "A categorical rule defines which TODOs matter and which do not, giving the model a clear boundary. Generic conservatism and reminders do not define the condition; reducing file coverage hides bugs rather than improving classification."
  },
  {
    "id": "s3q41",
    "d": "D4",
    "t": "4.1",
    "type": "single",
    "q": "A style-check category produces so many false positives that developers have started ignoring the reviewer's security findings too. What is the best trust-recovery action?",
    "o": [
      "Temporarily disable the style category while improving its criteria and examples.",
      "Increase the number of style findings so the category appears more thorough.",
      "Tell developers to read only findings labeled critical.",
      "Keep every category enabled so developers learn to distinguish good from bad findings."
    ],
    "a": [
      0
    ],
    "e": "A high false-positive category damages trust in accurate categories. Disabling it temporarily stops the noise while the criteria are improved. Keeping it enabled continues the harm; adding noise is worse; asking developers to filter manually shifts the burden."
  },
  {
    "id": "s3q42",
    "d": "D4",
    "t": "4.2",
    "type": "single",
    "q": "Generated tests cover the happy path but miss branch-level cases such as expired tokens and empty collections. Instructions alone have not helped. What few-shot design is most effective?",
    "o": [
      "Examples of test names without the corresponding code or assertions.",
      "Examples of many happy-path tests to establish a pattern.",
      "A single example of a test file with no explanation.",
      "Examples of branch-level coverage gaps that show the uncovered branch and the reasoning for adding each test."
    ],
    "a": [
      3
    ],
    "e": "Examples that demonstrate the reasoning behind branch coverage teach the model to look for decision points and edge conditions in new code. Happy-path examples reinforce the existing gap; unexplained or name-only examples do not show judgment."
  },
  {
    "id": "s3q43",
    "d": "D4",
    "t": "4.2",
    "type": "single",
    "q": "Review findings vary in structure: some include a file and line, others only prose. You need a consistent format with location, issue, severity and suggested fix. What is the most effective technique?",
    "o": [
      "Provide two to four few-shot examples that show the complete desired output shape for representative findings.",
      "Ask the model to “be consistent” in the system prompt.",
      "Describe the desired fields once in a long paragraph.",
      "Post-process the prose with an unrelated parser."
    ],
    "a": [
      0
    ],
    "e": "Few-shot examples make the target structure concrete and demonstrate how to handle representative cases. A long description is weaker, “be consistent” gives no format, and a downstream parser cannot recover information the model never produced."
  },
  {
    "id": "s3q44",
    "d": "D4",
    "t": "4.3",
    "type": "single",
    "q": "An extraction passes a strict JSON schema but puts the shipping address in the billing-address field. What does this reveal?",
    "o": [
      "The model needs a larger context window to understand field names.",
      "The schema needs to be less strict so the model can choose the best field.",
      "Strict schemas eliminate syntax errors but do not prevent semantic errors such as values in the wrong field.",
      "Tool use cannot produce structured output reliably."
    ],
    "a": [
      2
    ],
    "e": "Schema validity guarantees shape, not meaning. Wrong-field placement requires semantic validation, clearer field descriptions or examples, and possibly cross-field checks. Relaxing the schema or blaming tool use does not address semantics; a larger window is not the missing control."
  },
  {
    "id": "s3q45",
    "d": "D4",
    "t": "4.3",
    "type": "single",
    "q": "A purchase-order extractor sometimes invents an approval date because the schema marks the field as required, even though many documents never state one. What schema change is appropriate?",
    "o": [
      "Make the field nullable or optional and instruct the model to return null when the source is silent.",
      "Keep it required and add a default date of today.",
      "Remove all validation from the extraction pipeline.",
      "Ask the model to infer the date from surrounding text and label it as fact."
    ],
    "a": [
      0
    ],
    "e": "Nullable fields let the model represent absence honestly instead of fabricating a value. A default invents data; removing validation weakens quality; inferred dates presented as facts undermine accuracy."
  },
  {
    "id": "s3q46",
    "d": "D4",
    "t": "4.4",
    "type": "single",
    "q": "An extractor returns “03/04/2026” for a date field that requires ISO 8601. The schema rejects it. What retry message is most likely to correct the output?",
    "o": [
      "Increase the retry count and keep the same prompt.",
      "Resend only the instruction “return valid JSON”.",
      "Include the original document, the failed extraction and the specific format error with the expected ISO format.",
      "Start a new session with no mention of the previous failure."
    ],
    "a": [
      2
    ],
    "e": "Retry-with-error-feedback gives the model the source, its prior output and the precise defect to correct. A generic validity reminder lacks the format target; a fresh session loses the failure context; repeated identical attempts are unlikely to converge."
  },
  {
    "id": "s3q47",
    "d": "D4",
    "t": "4.4",
    "type": "single",
    "q": "A required tax ID appears only in a separate certificate that was never included in the document bundle. The extractor has retried five times. What should the pipeline do?",
    "o": [
      "Stop retrying: the evidence is absent. Supply the certificate or mark the field unavailable.",
      "Increase the retry budget because most missing fields eventually appear.",
      "Retry with a higher temperature to infer the tax ID.",
      "Change the field to a default placeholder so validation passes."
    ],
    "a": [
      0
    ],
    "e": "Retries can correct format and structural mistakes, not missing evidence. The pipeline should retrieve the source document or return an explicit unavailable value. Inference, placeholders and more retries risk fabrication."
  },
  {
    "id": "s3q48",
    "d": "D4",
    "t": "4.5",
    "type": "single",
    "q": "Before submitting 20,000 invoices to the Message Batches API, you want to maximize first-pass success and avoid costly resubmission. What should you do?",
    "o": [
      "Submit all 20,000 immediately and fix failures after the batch returns.",
      "Refine the prompt and schema on a small sample set, measure quality, then batch the full volume.",
      "Skip validation because batch processing guarantees correct structured output.",
      "Use the synchronous API for all 20,000 because it is always cheaper."
    ],
    "a": [
      1
    ],
    "e": "Sample-set refinement exposes schema and prompt problems before committing the full batch, improving first-pass success. Large-scale trial-and-error increases resubmission cost; synchronous processing defeats the batch savings; batching does not guarantee semantic correctness."
  },
  {
    "id": "s3q49",
    "d": "D4",
    "t": "4.5",
    "type": "single",
    "q": "A batch returns results out of order, and some requests failed. How should the application correlate each response with its input and identify failures?",
    "o": [
      "Use the custom_id assigned to each request to map responses and select failures for resubmission.",
      "Resubmit the entire batch and discard the first result set.",
      "Assume responses are in the same order as requests.",
      "Use the response timestamp as the primary key."
    ],
    "a": [
      0
    ],
    "e": "custom_id is the stable correlation key for batch request/response pairs. Order is not guaranteed, timestamps are not unique identifiers, and resubmitting everything repeats successful work."
  },
  {
    "id": "s3q50",
    "d": "D4",
    "t": "4.6",
    "type": "single",
    "q": "A model writes a patch and then reviews it in the same session. It misses a subtle concurrency bug it introduced, even with extended thinking. What is the most reliable improvement?",
    "o": [
      "Ask the generator to explain why the patch cannot have bugs.",
      "Review the patch in an independent Claude instance that lacks the generator's reasoning context.",
      "Ask the same session to review again with a stronger instruction.",
      "Increase the generator's temperature during the review."
    ],
    "a": [
      1
    ],
    "e": "Self-review retains the generator's assumptions and rationalizations, so subtle issues can survive. An independent instance examines the artifact without that anchor. Re-prompting, temperature changes and self-justification do not create independence."
  },
  {
    "id": "s3q51",
    "d": "D4",
    "t": "4.6",
    "type": "single",
    "q": "A 60-file review produces shallow comments on some files and misses an integration bug that spans three modules. How should the review be restructured?",
    "o": [
      "Use per-file local review passes plus a separate cross-file integration pass.",
      "Use one pass with a larger context window and a request for thoroughness.",
      "Review only the three modules involved in the integration bug.",
      "Run two identical full reviews and keep only duplicate findings."
    ],
    "a": [
      0
    ],
    "e": "Per-file passes give consistent local depth, and a separate integration pass focuses on cross-module flows. A larger window does not guarantee attention; reviewing only known modules misses unknown issues; duplicate-only findings suppress real bugs."
  },
  {
    "id": "s3q52",
    "d": "D5",
    "t": "5.1",
    "type": "single",
    "q": "Subagents return long reasoning chains to a downstream synthesis agent with a limited context budget. The synthesis misses key facts and citations. What change best fits the downstream constraint?",
    "o": [
      "Ask the synthesis agent to summarize the reasoning before reading it.",
      "Increase every upstream agent's temperature so the reasoning is shorter.",
      "Pass the full reasoning chains but remove all citations.",
      "Have upstream agents return structured key facts, citations and relevance scores instead of verbose reasoning."
    ],
    "a": [
      3
    ],
    "e": "Structured, compact outputs preserve what downstream synthesis needs: facts, provenance and relevance, without consuming the budget on reasoning chains. Temperature does not shorten content; removing citations destroys attribution; asking synthesis to summarize still requires ingesting the oversized input."
  },
  {
    "id": "s3q53",
    "d": "D5",
    "t": "5.2",
    "type": "multi",
    "n": 2,
    "q": "Which two conditions are appropriate escalation triggers? (Select two.)",
    "o": [
      "The request needs a policy exception, or policy is silent on the specific request.",
      "The model's self-reported confidence is below an arbitrary threshold.",
      "The customer explicitly requests a human agent.",
      "The customer uses negative language in the first message."
    ],
    "a": [
      0,
      2
    ],
    "e": "Explicit customer preference and genuine policy gaps are valid triggers. Self-reported confidence is poorly calibrated, and sentiment does not reliably indicate complexity or authority needs."
  },
  {
    "id": "s3q54",
    "d": "D5",
    "t": "5.2",
    "type": "single",
    "q": "An agent escalates when its self-reported confidence is below 6/10, but it is confidently wrong on hard policy cases and unconfidently correct on easy ones. What is the best fix?",
    "o": [
      "Raise the threshold to 8/10 so fewer cases are escalated.",
      "Replace the confidence threshold with explicit escalation criteria and few-shot examples of escalate-versus-resolve decisions.",
      "Remove escalation entirely and let the agent decide every case.",
      "Use sentiment analysis instead of confidence to trigger escalation."
    ],
    "a": [
      1
    ],
    "e": "Self-reported confidence is poorly calibrated for case difficulty. Explicit criteria and examples define when authority, policy or capability requires a human. Adjusting the threshold or switching to sentiment keeps an unreliable proxy; removing escalation violates policy and safety needs."
  },
  {
    "id": "s3q55",
    "d": "D5",
    "t": "5.3",
    "type": "single",
    "q": "A research subagent catches all exceptions and returns an empty list so the coordinator “does not crash”. The final report silently omits an entire source category. What is the flaw?",
    "o": [
      "The report needs a higher temperature to fill the gaps.",
      "The subagent should catch fewer exceptions but still return empty lists.",
      "Errors are suppressed instead of being propagated with structured context and coverage annotations.",
      "The coordinator should have used a larger model."
    ],
    "a": [
      2
    ],
    "e": "Suppressing errors converts failures into false success and hides coverage gaps. The subagent should recover locally where possible and propagate unresolved errors with failure type, attempted work, partial results and annotations. Model size, partial suppression and temperature do not fix the missing signal."
  },
  {
    "id": "s3q56",
    "d": "D5",
    "t": "5.3",
    "type": "single",
    "q": "An MCP search returns zero matches after a successful request, while another call times out. The coordinator currently treats both as “empty”. Why is this a problem?",
    "o": [
      "Zero matches should be reported as a permission error.",
      "Both should always trigger a retry with the same query.",
      "Timeouts should be returned as successful empty results to keep the workflow moving.",
      "A valid empty result is a successful query with no matches, while a timeout is an access failure that may warrant retry or a source change."
    ],
    "a": [
      3
    ],
    "e": "The two outcomes require different recovery decisions. A valid empty result means the query ran; a timeout means access failed and may be retried or replaced. Collapsing them prevents intelligent recovery and can hide coverage gaps."
  },
  {
    "id": "s3q57",
    "d": "D5",
    "t": "5.4",
    "type": "single",
    "q": "A multi-phase codebase investigation is about to spawn a new set of subagents for the next phase. The main agent's context is near its limit. What should happen before spawning?",
    "o": [
      "Summarize the key findings from the completed phase and inject those summaries into the next subagents' initial context.",
      "Ask the new subagents to rediscover the codebase independently.",
      "Pass the entire raw discovery log to every new subagent.",
      "Delete all prior findings so the next phase starts clean."
    ],
    "a": [
      0
    ],
    "e": "Phase summaries preserve validated knowledge in a compact form and give the next subagents a useful starting point. Raw logs consume the same context problem; independent rediscovery wastes work; deleting findings loses progress."
  },
  {
    "id": "s3q58",
    "d": "D5",
    "t": "5.5",
    "type": "multi",
    "n": 2,
    "q": "Which two extraction results should be prioritized for human review when reviewer capacity is limited? (Select two.)",
    "o": [
      "Fields with low calibrated confidence scores.",
      "All documents from the most common document type.",
      "Extractions with high overall document confidence but no field-level review.",
      "Documents whose sources are ambiguous or internally contradictory."
    ],
    "a": [
      0,
      3
    ],
    "e": "Low field-level confidence and ambiguous or contradictory source documents are the strongest signals for human attention. Reviewing an entire common document type ignores risk concentration, and high overall confidence can mask field-level errors."
  },
  {
    "id": "s3q59",
    "d": "D5",
    "t": "5.5",
    "type": "single",
    "q": "An extraction system reports 96% accuracy overall. Before reducing human review, what analysis is most important?",
    "o": [
      "The average length of the extracted JSON.",
      "Accuracy by document type and field segment, to verify consistent performance across all segments.",
      "The model's overall confidence score for the last week.",
      "The number of documents processed per hour."
    ],
    "a": [
      1
    ],
    "e": "Aggregate accuracy can hide poor performance on a document type or field. Segment-level analysis is required before reducing review. Overall confidence, throughput and output length do not establish consistent correctness."
  },
  {
    "id": "s3q60",
    "d": "D5",
    "t": "5.6",
    "type": "single",
    "q": "A synthesis agent compresses findings from several sources into a narrative and loses which source supported each claim. What should upstream agents provide to prevent this?",
    "o": [
      "Only the final statistics without source metadata to reduce tokens.",
      "A single confidence score for the entire report.",
      "Longer narrative summaries so the source is implied by the writing style.",
      "Structured claim-source mappings with source URLs, document names and relevant excerpts that synthesis must preserve and merge."
    ],
    "a": [
      3
    ],
    "e": "Claim-source mappings carry provenance through summarization and can be merged during synthesis. Narrative style does not identify a source; dropping metadata makes attribution unrecoverable; a single score does not map claims to evidence."
  }
];
