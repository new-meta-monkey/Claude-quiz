window.QUIZ_DATA = {
  meta: {
    exam: "Claude Certified Architect — Foundations (CCAR-F)",
    blueprintVersion: "1.0",
    sets: 3,
    questionsPerSet: 60,
    passScaled: 720
  },
  sets: [
    {
      id: 1,
      title: "Architectural Foundations",
      blurb: "60 scenario-based questions evaluating agentic loops, subagent context boundaries, MCP tool schemas, and prompt caching.",
      questions: window.SET1_QUESTIONS
    },
    {
      id: 2,
      title: "Production Patterns & Guardrails",
      blurb: "60 scenario questions focusing on orchestration recovery, CLAUDE.md hierarchy, schema compliance, and testing workflows.",
      questions: window.SET2_QUESTIONS
    },
    {
      id: 3,
      title: "Enterprise Scale & Edge Cases",
      blurb: "60 advanced scenario & trap questions on MCP transports, reasoning budgets, prefix caching, and CI/CD automation.",
      questions: window.SET3_QUESTIONS
    }
  ]
};
