const fs = require('fs');
const path = require('path');

const set1Raw = fs.readFileSync(path.join(__dirname, 'data-set1.js'), 'utf8');
const set2Raw = fs.readFileSync(path.join(__dirname, 'data-set2.js'), 'utf8');
const set3Raw = fs.readFileSync(path.join(__dirname, 'data-set3.js'), 'utf8');

const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#f4f1eb">
<meta name="description" content="Interactive 180-question mock exam lab for the Claude Certified Architect Foundations (CCA-F) certification with official weightage, real candidate traps, and timed proctored simulation.">
<title>CCA-F Exam Prep Lab — Claude Certified Architect Foundations</title>
<style>
:root{
  --bg:#f4f1eb; --bg-deep:#ece7dd; --card:#fffdf8; --card-2:#faf7f1;
  --ink:#19211d; --ink-2:#4d5751; --ink-3:#77817b; --line:#e3dccf; --line-2:#d4cabb;
  --accent:#bf5b37; --accent-deep:#9c4528; --accent-soft:#f7e5dc;
  --green:#2f6b4f; --green-soft:#e3f0e8; --red:#b23a34; --red-soft:#f8e6e4;
  --amber:#a96a12; --amber-soft:#f8eeda; --blue:#3d6688;
  --d1:#7657d6; --d2:#0d8588; --d3:#bf7410; --d4:#b84a70; --d5:#4d7443;
  --shadow:0 1px 2px rgba(30,35,28,.04),0 12px 34px rgba(30,35,28,.06);
  --shadow-lg:0 18px 60px rgba(30,35,28,.14);
  --r:18px; --r-sm:12px;
  --sans:"Avenir Next","Segoe UI",Roboto,Helvetica,Arial,sans-serif;
}
*{box-sizing:border-box}
html{-webkit-text-size-adjust:100%}
body{
  margin:0;background:
    radial-gradient(900px 500px at 12% -10%,#fdf8ef 0%,rgba(253,248,239,0) 60%),
    radial-gradient(800px 500px at 100% 0%,#f2ece1 0%,rgba(242,236,225,0) 55%),
    var(--bg);
  color:var(--ink);font-family:var(--sans);line-height:1.55;
  min-height:100vh;overflow-x:hidden;
}
button{font:inherit;color:inherit}
a{color:var(--accent-deep)}
.hidden{display:none!important}
.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
.wrap{width:min(1160px,100%);margin:0 auto;padding:0 clamp(16px,4vw,32px)}
.screen{min-height:100vh;min-height:100dvh}

/* ---------- top brand ---------- */
.topbar{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:22px 0 8px}
.brand{display:flex;align-items:center;gap:11px;text-decoration:none;color:var(--ink);min-width:0}
.logo{width:38px;height:38px;border-radius:11px;background:var(--ink);color:#fff8ef;display:grid;place-items:center;
  font-weight:800;font-size:15px;letter-spacing:-.04em;box-shadow:inset 0 1px 0 rgba(255,255,255,.18);flex:none}
.brand-txt{display:flex;flex-direction:column;line-height:1.12;min-width:0}
.brand-txt strong{font-size:14px;letter-spacing:.01em;white-space:nowrap}
.brand-txt span{font-size:11px;color:var(--ink-3);letter-spacing:.08em;text-transform:uppercase;white-space:nowrap}
.top-pill{display:inline-flex;align-items:center;gap:8px;padding:7px 11px;border:1px solid var(--line);border-radius:999px;
  background:rgba(255,253,248,.7);font-size:11.5px;font-weight:650;color:var(--ink-2);white-space:nowrap}
.dot{width:7px;height:7px;border-radius:50%;background:var(--green);box-shadow:0 0 0 3px rgba(47,107,79,.12)}

/* ---------- home ---------- */
.home{padding-bottom:70px}
.hero{padding:clamp(30px,6vw,66px) 0 26px;display:grid;grid-template-columns:minmax(0,1.45fr) minmax(280px,.75fr);gap:clamp(24px,5vw,64px);align-items:end}
.eyebrow{display:inline-flex;align-items:center;gap:9px;font-size:11.5px;font-weight:750;letter-spacing:.14em;text-transform:uppercase;color:var(--accent-deep);margin:0 0 18px}
.eyebrow:before{content:"";width:28px;height:1px;background:var(--accent);opacity:.55}
h1{font-size:clamp(34px,5.7vw,64px);line-height:1.02;letter-spacing:-.045em;font-weight:760;margin:0 0 20px;max-width:14ch}
h1 em{font-style:normal;color:var(--accent)}
.lede{font-size:clamp(15px,1.6vw,17.5px);color:var(--ink-2);max-width:58ch;margin:0 0 26px}
.hero-actions{display:flex;flex-wrap:wrap;gap:11px;align-items:center}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:46px;padding:0 18px;border-radius:12px;
  border:1px solid transparent;background:var(--ink);color:#fff9f1;font-weight:680;font-size:14px;cursor:pointer;
  transition:transform .15s ease,background .15s ease,box-shadow .15s ease,border-color .15s ease;text-decoration:none;user-select:none}
.btn:hover{transform:translateY(-1px);background:#2b3530;box-shadow:0 8px 22px rgba(30,35,28,.13)}
.btn:active{transform:translateY(0)}
.btn.accent{background:var(--accent);color:#fff}
.btn.accent:hover{background:var(--accent-deep)}
.btn.ghost{background:transparent;color:var(--ink);border-color:var(--line-2)}
.btn.ghost:hover{background:var(--card);box-shadow:var(--shadow)}
.btn.small{min-height:38px;padding:0 13px;font-size:12.5px;border-radius:10px}
.btn.large{min-height:50px;padding:0 24px;font-size:15px;border-radius:14px}
.btn[disabled]{opacity:.45;cursor:not-allowed;transform:none;box-shadow:none}
.btn .arrow{font-size:15px;line-height:1}
.hero-aside{background:linear-gradient(160deg,rgba(255,253,248,.92),rgba(250,246,238,.7));border:1px solid var(--line);border-radius:24px;padding:22px;box-shadow:var(--shadow)}
.hero-aside h3{font-size:12px;text-transform:uppercase;letter-spacing:.1em;color:var(--ink-3);margin:0 0 4px;font-weight:750}
.big-score{font-size:52px;letter-spacing:-.05em;font-weight:780;line-height:1.05;margin:0}
.big-score small{font-size:14px;letter-spacing:0;color:var(--ink-3);font-weight:600}
.hero-aside p{font-size:12.5px;color:var(--ink-2);margin:7px 0 0}
.mini-rule{height:1px;background:var(--line);margin:18px 0}
.mini-facts{display:grid;grid-template-columns:1fr 1fr;gap:13px}
.mini-facts strong{display:block;font-size:17px;letter-spacing:-.02em}
.mini-facts span{font-size:11px;color:var(--ink-3);text-transform:uppercase;letter-spacing:.07em;font-weight:650}

.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:1px;background:var(--line);border:1px solid var(--line);border-radius:16px;overflow:hidden;margin:10px 0 30px}
.stat{background:rgba(255,253,248,.76);padding:15px 18px;display:flex;align-items:baseline;gap:9px}
.stat strong{font-size:24px;letter-spacing:-.04em}
.stat span{font-size:11.5px;color:var(--ink-3);font-weight:650;letter-spacing:.05em;text-transform:uppercase}

.blueprint{background:var(--card);border:1px solid var(--line);border-radius:var(--r);padding:18px;margin:0 0 34px;box-shadow:var(--shadow)}
.bp-head{display:flex;align-items:baseline;justify-content:space-between;gap:14px;margin-bottom:13px}
.bp-head h3{margin:0;font-size:14px;letter-spacing:-.01em}
.bp-head span{font-size:11.5px;color:var(--ink-3)}
.bp-bar{display:flex;height:10px;border-radius:99px;overflow:hidden;gap:2px;background:var(--bg-deep)}
.bp-bar i{display:block;height:100%}
.bp-legend{display:flex;flex-wrap:wrap;gap:8px 16px;margin-top:13px;font-size:11.5px;color:var(--ink-2)}
.bp-legend span{display:inline-flex;align-items:center;gap:6px}
.bp-legend b{width:7px;height:7px;border-radius:2px}
.bp-legend em{font-style:normal;color:var(--ink-3);margin-left:2px}

.section-head{display:flex;align-items:end;justify-content:space-between;gap:18px;margin:0 0 16px}
.section-head h2{font-size:clamp(22px,3vw,30px);letter-spacing:-.035em;margin:0}
.section-head p{margin:4px 0 0;color:var(--ink-2);font-size:13.5px}
.mode-switch{display:inline-flex;background:var(--bg-deep);border:1px solid var(--line);padding:4px;border-radius:12px;gap:3px}
.mode-switch button{border:0;background:transparent;color:var(--ink-2);font-weight:680;font-size:12.5px;padding:8px 13px;border-radius:9px;cursor:pointer;min-height:38px;transition:background .14s,color .14s,box-shadow .14s}
.mode-switch button.active{background:var(--card);color:var(--ink);box-shadow:0 1px 4px rgba(30,35,28,.1)}
.mode-note{font-size:12.5px;color:var(--ink-3);margin:12px 0 0;max-width:70ch}
.sets{display:grid;grid-template-columns:repeat(3,1fr);gap:15px}
.set-card{background:var(--card);border:1px solid var(--line);border-radius:20px;padding:20px;display:flex;flex-direction:column;box-shadow:var(--shadow);position:relative;overflow:hidden;transition:transform .18s ease,box-shadow .18s ease,border-color .18s ease}
.set-card:hover{transform:translateY(-3px);box-shadow:var(--shadow-lg);border-color:var(--line-2)}
.set-card:before{content:"";position:absolute;inset:0 0 auto;height:3px;background:linear-gradient(90deg,var(--accent),#d89b6f)}
.set-num{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:18px}
.set-num b{font-size:11px;letter-spacing:.13em;text-transform:uppercase;color:var(--accent-deep)}
.set-num span{font-size:11px;color:var(--ink-3);border:1px solid var(--line);border-radius:99px;padding:3px 8px}
.set-card h3{font-size:21px;letter-spacing:-.03em;margin:0 0 6px}
.set-card p{font-size:12.5px;color:var(--ink-2);margin:0 0 15px;min-height:38px}
.chips{display:flex;flex-wrap:wrap;gap:5px;margin-bottom:18px}
.chip{font-size:10.5px;font-weight:680;color:var(--ink-2);background:var(--card-2);border:1px solid var(--line);border-radius:6px;padding:3px 7px;white-space:nowrap}
.chip.d1{color:#5b42b4;background:#f0edfc;border-color:#ddd6f8}
.chip.d2{color:#0a6a6d;background:#e5f4f4;border-color:#cce7e7}
.chip.d3{color:#8b5308;background:#fbf0dc;border-color:#f0dfbd}
.chip.d4{color:#8d3253;background:#fbeaf0;border-color:#f2d3df}
.chip.d5{color:#3a5c33;background:#eaf2e7;border-color:#d6e5d1}
.set-foot{margin-top:auto;display:flex;align-items:center;justify-content:space-between;gap:10px}
.progress-text{font-size:11.5px;color:var(--ink-3)}
.set-foot .btn{flex:none}
.resume-banner{display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;background:var(--amber-soft);border:1px solid #ecdbb9;border-radius:14px;padding:13px 16px;margin:0 0 18px;font-size:13px;color:#6e4a0e}
.resume-banner .btn{background:#6e4a0e;color:#fff8e8;flex:none}
.resume-banner .btn.ghost{background:transparent;color:#6e4a0e;border:1px solid #6e4a0e}
.footnote{margin:34px 0 0;padding-top:18px;border-top:1px solid var(--line);font-size:11.5px;color:var(--ink-3);display:flex;gap:14px;justify-content:space-between;flex-wrap:wrap}
.footnote a{color:var(--ink-2)}

/* ---------- quiz ---------- */
.quiz-top{position:sticky;top:0;z-index:30;background:rgba(244,241,235,.9);backdrop-filter:blur(12px);border-bottom:1px solid var(--line)}
.quiz-top-in{display:flex;align-items:center;gap:14px;padding:12px 0}
.back-btn{width:40px;height:40px;border-radius:10px;border:1px solid var(--line);background:var(--card);display:grid;place-items:center;cursor:pointer;flex:none;font-size:18px;transition:background .15s}
.back-btn:hover{background:var(--card-2)}
.quiz-title{min-width:0;flex:1}
.quiz-title strong{display:block;font-size:14px;letter-spacing:-.01em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.quiz-title span{display:block;font-size:11px;color:var(--ink-3);margin-top:1px}

/* Enhanced Timer Widget with Pause & Resume */
.timer{display:flex;align-items:center;gap:7px;border:1px solid var(--line);background:var(--card);border-radius:10px;padding:6px 10px;font-variant-numeric:tabular-nums;font-weight:720;font-size:13px;flex:none;transition:all .18s ease}
.timer .t-dot{width:7px;height:7px;border-radius:50%;background:var(--green);flex:none}
.timer.warn{border-color:#ebc9a6;background:var(--amber-soft);color:#7c510c}
.timer.warn .t-dot{background:var(--amber)}
.timer.danger{border-color:#e5b4b0;background:var(--red-soft);color:var(--red)}
.timer.danger .t-dot{background:var(--red);animation:pulse 1s infinite}
.timer.paused{border-color:#ebc9a6;background:var(--amber-soft);color:#7c510c}
.timer.paused .t-dot{background:var(--amber);animation:none}
.timer-btn{display:inline-flex;align-items:center;justify-content:center;background:transparent;border:0;cursor:pointer;color:inherit;padding:3px;border-radius:6px;transition:background .15s;flex:none}
.timer-btn:hover{background:rgba(0,0,0,.08)}
@keyframes pulse{50%{opacity:.35}}

.icon-btn{width:40px;height:40px;border-radius:10px;border:1px solid var(--line);background:var(--card);display:none;place-items:center;cursor:pointer;flex:none}
.quiz-progress{height:3px;background:var(--bg-deep)}
.quiz-progress i{display:block;height:100%;background:var(--accent);transition:width .25s ease}
.quiz-main{display:grid;grid-template-columns:minmax(0,1fr) 280px;gap:28px;padding-top:26px;padding-bottom:90px;align-items:start}

.q-card{background:var(--card);border:1px solid var(--line);border-radius:22px;padding:clamp(20px,3.5vw,34px);box-shadow:var(--shadow);transition:filter .2s,opacity .2s}
.q-card.content-blurred{filter:blur(9px);pointer-events:none;user-select:none;opacity:.3}

.q-meta{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin-bottom:17px}
.badge{display:inline-flex;align-items:center;gap:6px;border-radius:7px;padding:4px 8px;font-size:10.5px;font-weight:720;letter-spacing:.03em;text-transform:uppercase;border:1px solid var(--line);background:var(--card-2);color:var(--ink-2)}
.badge.domain[data-d="D1"]{color:#5b42b4;background:#f0edfc;border-color:#ddd6f8}
.badge.domain[data-d="D2"]{color:#0a6a6d;background:#e5f4f4;border-color:#cce7e7}
.badge.domain[data-d="D3"]{color:#8b5308;background:#fbf0dc;border-color:#f0dfbd}
.badge.domain[data-d="D4"]{color:#8d3253;background:#fbeaf0;border-color:#f2d3df}
.badge.domain[data-d="D5"]{color:#3a5c33;background:#eaf2e7;border-color:#d6e5d1}
.badge.plain{text-transform:none;letter-spacing:0;font-weight:600;color:var(--ink-3)}
.flag-btn{margin-left:auto;border:0;background:transparent;color:var(--ink-3);font-size:11.5px;font-weight:680;display:inline-flex;align-items:center;gap:5px;cursor:pointer;padding:6px;border-radius:8px;transition:background .14s,color .14s}
.flag-btn:hover{background:var(--card-2);color:var(--ink)}
.flag-btn.on{color:var(--accent-deep);background:var(--accent-soft)}

.q-text{font-size:clamp(18px,2.3vw,23px);line-height:1.4;letter-spacing:-.018em;font-weight:625;margin:0 0 8px}
.q-hint{font-size:12px;color:var(--ink-3);margin:0 0 20px}
.options{display:flex;flex-direction:column;gap:9px}
.option{display:flex;gap:13px;align-items:flex-start;text-align:left;width:100%;border:1px solid var(--line);background:var(--card);border-radius:13px;
  padding:14px 15px;cursor:pointer;transition:border-color .14s,background .14s,box-shadow .14s;min-height:52px;position:relative}
.option:hover:not(.locked){border-color:var(--line-2);background:var(--card-2);box-shadow:0 2px 8px rgba(30,35,28,.04)}
.option:focus-visible{outline:2px solid var(--ink);outline-offset:2px}
.option .letter{width:27px;height:27px;border-radius:8px;background:var(--bg-deep);color:var(--ink-2);display:grid;place-items:center;font-size:12px;font-weight:760;flex:none;margin-top:1px;border:1px solid transparent}
.option .opt-text{font-size:14px;line-height:1.48;color:var(--ink)}
.option.selected{border-color:#8b948d;background:#f7f5ef;box-shadow:inset 0 0 0 1px #8b948d}
.option.selected .letter{background:var(--ink);color:#fff}
.option.correct{border-color:#94c4a8;background:var(--green-soft)}
.option.correct .letter{background:var(--green);color:#fff}
.option.incorrect{border-color:#e0a29d;background:var(--red-soft)}
.option.incorrect .letter{background:var(--red);color:#fff}
.option.locked{cursor:default}
.option .mark{margin-left:auto;font-size:15px;font-weight:800;flex:none;align-self:center}
.option.correct .mark{color:var(--green)}
.option.incorrect .mark{color:var(--red)}

.q-actions{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:22px;flex-wrap:wrap}
.q-actions-right{display:flex;gap:9px;margin-left:auto}
.check-note{font-size:12px;color:var(--ink-3)}
.feedback{margin-top:20px;border-top:1px solid var(--line);padding-top:18px;animation:rise .22s ease}
@keyframes rise{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:none}}
.fb-head{display:flex;align-items:center;gap:9px;font-size:13px;font-weight:760;margin-bottom:8px}
.fb-head .fb-icon{width:25px;height:25px;border-radius:50%;display:grid;place-items:center;font-size:13px;color:#fff;flex:none}
.fb-head.ok{color:var(--green)}.fb-head.ok .fb-icon{background:var(--green)}
.fb-head.bad{color:var(--red)}.fb-head.bad .fb-icon{background:var(--red)}
.fb-head.miss{color:var(--amber)}.fb-head.miss .fb-icon{background:var(--amber)}
.fb-body{font-size:13.5px;color:var(--ink-2);line-height:1.62}
.fb-body strong{color:var(--ink)}
.fb-body p{margin:0 0 8px}
.fb-body p:last-child{margin-bottom:0}
.fb-task{font-size:11px;color:var(--ink-3);margin-top:10px;padding-top:10px;border-top:1px dashed var(--line)}

.side-panel{position:sticky;top:104px;display:flex;flex-direction:column;gap:14px}
.panel{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:16px;box-shadow:var(--shadow)}
.panel-head{display:flex;align-items:baseline;justify-content:space-between;gap:10px;margin-bottom:12px}
.panel-head h3{margin:0;font-size:12.5px;letter-spacing:.02em}
.panel-head span{font-size:11px;color:var(--ink-3)}
.palette-toolbar{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;gap:8px}
.mini-btn{background:transparent;border:1px solid var(--line);padding:4px 8px;border-radius:6px;font-size:11px;color:var(--ink-2);cursor:pointer;display:inline-flex;align-items:center;gap:4px;transition:all .14s}
.mini-btn:hover{background:var(--card-2);border-color:var(--line-2);color:var(--ink)}

.palette{display:grid;grid-template-columns:repeat(6,1fr);gap:5px}
.palette button{aspect-ratio:1;min-height:30px;border:1px solid var(--line);background:var(--card-2);border-radius:7px;font-size:11px;font-weight:680;color:var(--ink-2);cursor:pointer;padding:0;position:relative}
.palette button:hover{border-color:var(--ink-3)}
.palette button.current{outline:2px solid var(--ink);outline-offset:1px}
.palette button.answered{background:var(--ink);color:#fff;border-color:var(--ink)}
.palette button.flagged:after{content:"";position:absolute;top:3px;right:3px;width:5px;height:5px;border-radius:50%;background:var(--accent)}
.palette button.answered.flagged:after{background:#f4b39d}
.palette button.correct{background:var(--green);border-color:var(--green);color:#fff}
.palette button.wrong{background:var(--red);border-color:var(--red);color:#fff}
.legend{display:flex;flex-wrap:wrap;gap:8px 12px;margin-top:12px;font-size:10.5px;color:var(--ink-3)}
.legend span{display:inline-flex;align-items:center;gap:5px}
.legend i{width:9px;height:9px;border-radius:3px;background:var(--card-2);border:1px solid var(--line)}
.legend i.ans{background:var(--ink);border-color:var(--ink)}
.legend i.cur{outline:2px solid var(--ink);outline-offset:1px;background:var(--card)}
.legend i.flag{background:var(--accent);border-color:var(--accent)}
.panel .btn{width:100%}
.panel-note{font-size:11px;color:var(--ink-3);margin:10px 0 0;text-align:center}

.mobile-nav{display:none;position:fixed;left:0;right:0;bottom:0;z-index:40;background:rgba(255,253,248,.96);backdrop-filter:blur(12px);border-top:1px solid var(--line);padding:9px 14px calc(9px + env(safe-area-inset-bottom));gap:8px;align-items:center}
.mobile-nav .btn{flex:1;min-height:43px}
.mobile-nav .btn.icon-only{flex:0 0 46px;padding:0}

.drawer-overlay{position:fixed;inset:0;z-index:60;background:rgba(20,25,21,.42);backdrop-filter:blur(2px)}
.drawer{position:fixed;z-index:61;top:0;right:0;bottom:0;width:min(340px,88vw);background:var(--card);box-shadow:-20px 0 60px rgba(20,25,21,.2);padding:18px;overflow:auto;padding-bottom:calc(18px + env(safe-area-inset-bottom))}
.drawer-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}
.drawer-head h3{margin:0;font-size:16px}
.drawer .palette{grid-template-columns:repeat(6,1fr)}
.drawer .palette button{min-height:38px;font-size:12px}

/* Enhanced Exam Pause Overlay */
.pause-overlay{position:fixed;inset:0;z-index:75;background:rgba(20,25,21,.65);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);display:grid;place-items:center;padding:18px}
.pause-card{background:var(--card);border:1px solid var(--line);border-radius:24px;padding:34px 28px;width:min(450px,100%);text-align:center;box-shadow:var(--shadow-lg);animation:pop .2s ease}
.pause-badge{width:56px;height:56px;border-radius:50%;background:var(--amber-soft);color:var(--amber);display:grid;place-items:center;font-size:24px;margin:0 auto 16px}
.pause-card h2{font-size:22px;margin:0 0 8px;letter-spacing:-.03em}
.pause-card p{font-size:13.5px;color:var(--ink-2);margin:0 0 20px;line-height:1.55}
.pause-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:1px;background:var(--line);border:1px solid var(--line);border-radius:12px;overflow:hidden;margin-bottom:22px}
.pause-stats div{background:var(--card-2);padding:10px 6px}
.pause-stats b{display:block;font-size:16px;letter-spacing:-.02em}
.pause-stats span{font-size:10px;text-transform:uppercase;color:var(--ink-3);letter-spacing:.05em;font-weight:700}
.pause-actions{display:flex;flex-direction:column;gap:9px}
.pause-hint{display:block;font-size:11.5px;color:var(--ink-3);margin-top:14px}
.pause-hint kbd{background:var(--bg-deep);border:1px solid var(--line-2);border-radius:4px;padding:2px 6px;font-family:inherit;font-size:10.5px}

/* ---------- results ---------- */
.results{padding:26px 0 70px}
.res-head{display:flex;align-items:flex-end;justify-content:space-between;gap:20px;margin:20px 0 26px;flex-wrap:wrap}
.res-head h1{font-size:clamp(30px,4.6vw,48px);max-width:none;margin:0 0 6px}
.res-head p{margin:0;color:var(--ink-2);font-size:14px}
.result-grid{display:grid;grid-template-columns:360px minmax(0,1fr);gap:18px;align-items:start}
.score-card{background:var(--card);border:1px solid var(--line);border-radius:24px;padding:24px;box-shadow:var(--shadow);text-align:center}
.ring{width:212px;height:212px;border-radius:50%;margin:4px auto 18px;display:grid;place-items:center;position:relative;background:conic-gradient(var(--ring-color) calc(var(--pct)*1%),var(--bg-deep) 0)}
.ring:after{content:"";position:absolute;inset:13px;border-radius:50%;background:var(--card)}
.ring-in{position:relative;z-index:1;display:flex;flex-direction:column;align-items:center}
.ring-in strong{font-size:50px;letter-spacing:-.06em;line-height:1;font-variant-numeric:tabular-nums}
.ring-in span{font-size:11px;letter-spacing:.13em;text-transform:uppercase;color:var(--ink-3);font-weight:700;margin-top:6px}
.verdict{display:inline-flex;align-items:center;gap:7px;border-radius:99px;padding:6px 13px;font-size:12px;font-weight:760;margin-bottom:10px}
.verdict.pass{background:var(--green-soft);color:var(--green)}
.verdict.fail{background:var(--red-soft);color:var(--red)}
.verdict .v-dot{width:7px;height:7px;border-radius:50%;background:currentColor}
.score-card p{font-size:12.5px;color:var(--ink-3);margin:0}
.result-facts{display:grid;grid-template-columns:repeat(3,1fr);gap:1px;background:var(--line);border:1px solid var(--line);border-radius:12px;overflow:hidden;margin-top:20px}
.result-facts div{background:var(--card);padding:10px 6px}
.result-facts b{display:block;font-size:16px;letter-spacing:-.02em}
.result-facts span{font-size:9.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--ink-3);font-weight:700}
.breakdown{background:var(--card);border:1px solid var(--line);border-radius:24px;padding:24px;box-shadow:var(--shadow)}
.breakdown h2{font-size:19px;letter-spacing:-.025em;margin:0 0 4px}
.breakdown .sub{font-size:12px;color:var(--ink-3);margin:0 0 20px}
.domain-row{margin:0 0 15px}
.domain-label{display:flex;align-items:baseline;justify-content:space-between;gap:12px;font-size:12.5px;margin-bottom:6px}
.domain-label strong{font-weight:680}
.domain-label span{color:var(--ink-3);font-variant-numeric:tabular-nums;font-size:11.5px}
.bar{height:8px;background:var(--bg-deep);border-radius:99px;overflow:hidden}
.bar i{display:block;height:100%;border-radius:99px;transition:width .5s ease}
.bar i.d1{background:var(--d1)}.bar i.d2{background:var(--d2)}.bar i.d3{background:var(--d3)}.bar i.d4{background:var(--d4)}.bar i.d5{background:var(--d5)}
.domain-note{font-size:11px;color:var(--ink-3);margin-top:4px}
.callout{background:var(--card-2);border:1px solid var(--line);border-radius:12px;padding:13px 15px;font-size:12.5px;color:var(--ink-2);margin-top:18px}
.callout strong{color:var(--ink)}
.res-actions{display:flex;gap:9px;flex-wrap:wrap;margin-top:20px}
.res-actions .btn{flex:1;min-width:140px}

/* ---------- review ---------- */
.review{padding:24px 0 80px}
.review-head{display:flex;align-items:end;justify-content:space-between;gap:16px;flex-wrap:wrap;margin:18px 0 22px}
.review-head h1{font-size:clamp(26px,4vw,38px);margin:0 0 4px;max-width:none}
.review-head p{margin:0;color:var(--ink-2);font-size:13px}
.filters{display:inline-flex;gap:4px;background:var(--bg-deep);border:1px solid var(--line);border-radius:11px;padding:4px;flex-wrap:wrap}
.filters button{border:0;background:transparent;padding:7px 12px;border-radius:8px;font-size:12px;font-weight:680;color:var(--ink-2);cursor:pointer;min-height:36px}
.filters button.active{background:var(--card);color:var(--ink);box-shadow:0 1px 4px rgba(30,35,28,.1)}
.review-list{display:flex;flex-direction:column;gap:13px}
.r-card{background:var(--card);border:1px solid var(--line);border-radius:17px;padding:19px;box-shadow:var(--shadow)}
.r-card.wrong{border-left:4px solid var(--red)}
.r-card.right{border-left:4px solid var(--green)}
.r-top{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:9px}
.r-num{font-size:11px;font-weight:760;color:var(--ink-3)}
.r-q{font-size:14.5px;line-height:1.5;font-weight:620;margin:0 0 12px}
.r-opts{display:flex;flex-direction:column;gap:5px;margin-bottom:12px}
.r-opt{font-size:12.5px;color:var(--ink-2);padding:7px 10px;border-radius:8px;border:1px solid transparent;display:flex;gap:8px}
.r-opt b{font-weight:760;color:var(--ink-3);flex:none}
.r-opt.correct{background:var(--green-soft);border-color:#cfe5d8;color:#23533d}
.r-opt.correct b{color:var(--green)}
.r-opt.chosen-wrong{background:var(--red-soft);border-color:#edd0cd;color:#7f2b27}
.r-opt.chosen-wrong b{color:var(--red)}
.r-tags{display:flex;gap:6px;flex-wrap:wrap;margin-left:auto}
.r-exp{font-size:12.5px;color:var(--ink-2);border-top:1px dashed var(--line);padding-top:11px;line-height:1.6}
.r-exp strong{color:var(--ink)}
.empty{background:var(--card);border:1px dashed var(--line-2);border-radius:16px;padding:36px;text-align:center;color:var(--ink-3);font-size:13px}

/* ---------- modal / toast ---------- */
.modal-overlay{position:fixed;inset:0;z-index:80;background:rgba(20,25,21,.46);backdrop-filter:blur(3px);display:grid;place-items:center;padding:18px}
.modal{background:var(--card);border-radius:20px;padding:24px;width:min(430px,100%);box-shadow:var(--shadow-lg);animation:pop .18s ease}
@keyframes pop{from{opacity:0;transform:scale(.97)}to{opacity:1;transform:none}}
.modal h3{margin:0 0 7px;font-size:20px;letter-spacing:-.025em}
.modal p{margin:0 0 20px;font-size:13px;color:var(--ink-2)}
.modal-actions{display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap}
.toast{position:fixed;left:50%;bottom:calc(20px + env(safe-area-inset-bottom));transform:translateX(-50%);z-index:90;background:var(--ink);color:#fff;border-radius:10px;padding:10px 15px;font-size:12px;box-shadow:var(--shadow-lg);animation:toastin .2s ease}
@keyframes toastin{from{opacity:0;transform:translate(-50%,6px)}to{opacity:1;transform:translate(-50%,0)}}

@media(max-width:980px){
  .hero{grid-template-columns:1fr;align-items:start}
  .hero-aside{max-width:460px}
  .quiz-main{grid-template-columns:minmax(0,1fr)}
  .side-panel{display:none}
  .icon-btn{display:grid}
  .mobile-nav{display:flex}
  .result-grid{grid-template-columns:1fr}
  .score-card{max-width:none}
  .sets{grid-template-columns:1fr}
  .set-card p{min-height:0}
}
@media(max-width:640px){
  .topbar{padding-top:16px}
  .top-pill{display:none}
  .hero{padding-top:26px}
  .stats{grid-template-columns:1fr;gap:0}
  .stat{border-bottom:1px solid var(--line);padding:11px 15px}
  .stat:last-child{border-bottom:0}
  .stat strong{font-size:20px}
  .q-card{border-radius:18px}
  .option{padding:13px 12px;gap:10px}
  .option .opt-text{font-size:13.5px}
  .q-actions .check-note{width:100%;order:-1}
  .quiz-main{padding-top:18px;padding-bottom:96px}
  .res-actions .btn{min-width:0}
  .r-card{padding:16px}
  .review-head{align-items:flex-start}
  .timer{padding:5px 8px;font-size:12px;gap:5px}
  .mobile-nav .btn{padding:0 10px;font-size:13px}
  .hero-actions .btn{flex:1}
}
@media(prefers-reduced-motion:reduce){
  *{scroll-behavior:auto!important;transition:none!important;animation:none!important}
}
</style>
</head>
<body>

<!-- ============ HOME ============ -->
<section id="screen-home" class="screen home">
  <div class="wrap">
    <header class="topbar">
      <a class="brand" href="#" onclick="return false">
        <span class="logo">CA</span>
        <span class="brand-txt"><strong>CCA-F Prep Lab</strong><span>Official Blueprint v1.0</span></span>
      </a>
      <span class="top-pill"><i class="dot"></i> 180 scenario questions · 3 full sets</span>
    </header>

    <div class="hero">
      <div>
        <p class="eyebrow">Anthropic Certification Readiness</p>
        <h1>Master the <em>Claude Certified Architect</em> Exam.</h1>
        <p class="lede">Three 60-question mock exams mathematically aligned with Anthropic's official CCA-F blueprint. Built from real exam debriefs, candidate reviews, and production trap scenarios across agent orchestration, MCP, Claude Code, and context engineering.</p>
        <div class="hero-actions">
          <button class="btn accent" id="quick-start">Start diagnostic mock <span class="arrow">→</span></button>
          <a class="btn ghost" href="#sets">Browse 3 sets</a>
        </div>
      </div>
      <aside class="hero-aside">
        <h3>Exam standard</h3>
        <p class="big-score">720<small> / 1000</small></p>
        <p>Scaled score required to pass. 60 scenario questions in 120 minutes.</p>
        <div class="mini-rule"></div>
        <div class="mini-facts">
          <div><strong>120 min</strong><span>Time limit</span></div>
          <div><strong>60 items</strong><span>Per attempt</span></div>
          <div><strong>Fisher-Yates</strong><span>Shuffled order</span></div>
          <div><strong>Pause/Resume</strong><span>Simulated break</span></div>
        </div>
      </aside>
    </div>

    <div class="stats">
      <div class="stat"><strong>180</strong><span>Unique scenarios</span></div>
      <div class="stat"><strong>5</strong><span>Core domains</span></div>
      <div class="stat"><strong>0</strong><span>Duplicate questions</span></div>
    </div>

    <div class="blueprint">
      <div class="bp-head">
        <h3>Official Domain Weightage (60 Questions per Exam)</h3>
        <span>Anthropic CCA-F Blueprint</span>
      </div>
      <div class="bp-bar" aria-label="Domain weight distribution">
        <i style="width:27%;background:var(--d1)" title="D1: Agentic Architecture 27%"></i>
        <i style="width:18%;background:var(--d2)" title="D2: Tools & MCP 18%"></i>
        <i style="width:20%;background:var(--d3)" title="D3: Claude Code 20%"></i>
        <i style="width:20%;background:var(--d4)" title="D4: Prompt & Structured Output 20%"></i>
        <i style="width:15%;background:var(--d5)" title="D5: Context & Reliability 15%"></i>
      </div>
      <div class="bp-legend">
        <span><b style="background:var(--d1)"></b>D1 Agentic Architecture <em>27% (16 Qs)</em></span>
        <span><b style="background:var(--d2)"></b>D2 Tools & MCP <em>18% (11 Qs)</em></span>
        <span><b style="background:var(--d3)"></b>D3 Claude Code <em>20% (12 Qs)</em></span>
        <span><b style="background:var(--d4)"></b>D4 Prompt & Structured Output <em>20% (12 Qs)</em></span>
        <span><b style="background:var(--d5)"></b>D5 Context & Reliability <em>15% (9 Qs)</em></span>
      </div>
    </div>

    <div id="resume-slot"></div>

    <div class="section-head" id="sets">
      <div>
        <h2>Choose a mock exam set</h2>
        <p>All three sets are 100% unique. Choose Practice mode for instant explanations or Exam mode for timed proctored simulation.</p>
      </div>
      <div class="mode-switch" role="group" aria-label="Quiz mode">
        <button type="button" data-mode="practice" class="active">Practice Mode</button>
        <button type="button" data-mode="exam">Exam Simulation</button>
      </div>
    </div>
    <p class="mode-note" id="mode-note">Practice mode reveals answers and comprehensive rationales immediately upon selection. Multi-select items reveal after you press Check Answer.</p>

    <div class="sets" id="set-cards"></div>

    <div class="footnote">
      <span>Self-contained offline prep lab for Claude Certified Architect — Foundations (CCA-F / CCAR-F).</span>
      <span>Official Blueprint: 27% / 18% / 20% / 20% / 15% · Passing Scale: 720 / 1000</span>
    </div>
  </div>
</section>

<!-- ============ QUIZ ============ -->
<section id="screen-quiz" class="screen hidden">
  <div class="quiz-top">
    <div class="wrap">
      <div class="quiz-top-in">
        <button class="back-btn" id="quit-quiz" aria-label="Leave quiz" title="Exit to Menu">←</button>
        <div class="quiz-title">
          <strong id="quiz-title">Set 1 · Practice</strong>
          <span id="quiz-subtitle">Question 1 of 60 · Shuffled</span>
        </div>
        
        <!-- Timer with Live Pause / Start Button -->
        <div class="timer hidden" id="timer" title="Exam Timer — Click pause to pause">
          <i class="t-dot" id="t-dot"></i>
          <span id="timer-text">120:00</span>
          <button type="button" class="timer-btn" id="timer-pause-btn" title="Pause or start exam timer (Shortcut: P or Space)" aria-label="Pause or start timer">
            <svg id="timer-icon-pause" width="13" height="13" viewBox="0 0 16 16" fill="currentColor"><path d="M4.5 2.5a1.5 1.5 0 0 0-1.5 1.5v8a1.5 1.5 0 0 0 3 0V4a1.5 1.5 0 0 0-1.5-1.5zm7 0a1.5 1.5 0 0 0-1.5 1.5v8a1.5 1.5 0 0 0 3 0V4a1.5 1.5 0 0 0-1.5-1.5z"/></svg>
            <svg id="timer-icon-play" class="hidden" width="13" height="13" viewBox="0 0 16 16" fill="currentColor"><path d="m5.5 3.5 7 4.5-7 4.5z"/></svg>
          </button>
        </div>

        <button class="icon-btn" id="open-drawer" aria-label="Open question palette">
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true"><rect x="2" y="2" width="4" height="4" rx="1" fill="currentColor"/><rect x="7" y="2" width="4" height="4" rx="1" fill="currentColor"/><rect x="12" y="2" width="4" height="4" rx="1" fill="currentColor"/><rect x="2" y="7" width="4" height="4" rx="1" fill="currentColor"/><rect x="7" y="7" width="4" height="4" rx="1" fill="currentColor"/><rect x="12" y="7" width="4" height="4" rx="1" fill="currentColor"/><rect x="2" y="12" width="4" height="4" rx="1" fill="currentColor"/><rect x="7" y="12" width="4" height="4" rx="1" fill="currentColor"/><rect x="12" y="12" width="4" height="4" rx="1" fill="currentColor"/></svg>
        </button>
      </div>
    </div>
    <div class="quiz-progress"><i id="quiz-progress-bar" style="width:0%"></i></div>
  </div>

  <div class="wrap quiz-main">
    <article class="q-card" id="question-card"></article>
    <aside class="side-panel">
      <div class="panel">
        <div class="panel-head">
          <h3>Question Palette</h3>
          <span id="answered-count">0 / 60</span>
        </div>
        <div class="palette-toolbar">
          <button type="button" class="mini-btn" id="reshuffle-btn" title="Shuffle questions in this set">🔀 Reshuffle</button>
          <span style="font-size:11px;color:var(--ink-3)" id="side-flags-count">0 flagged</span>
        </div>
        <div class="palette" id="palette-desktop"></div>
        <div class="legend">
          <span><i class="ans"></i>Answered</span>
          <span><i class="flag"></i>Flagged</span>
          <span><i class="cur"></i>Current</span>
        </div>
      </div>
      <div class="panel">
        <button class="btn accent" id="submit-side">Submit Exam</button>
        <p class="panel-note" id="side-mode-note">Answers reveal instantly.</p>
      </div>
    </aside>
  </div>

  <!-- Mobile Bottom Sticky Navigation -->
  <div class="mobile-nav">
    <button class="btn ghost icon-only" id="mobile-prev" aria-label="Previous question">←</button>
    <button class="btn ghost" id="mobile-map">Map (0/60)</button>
    <button class="btn accent" id="mobile-next">Next →</button>
  </div>
</section>

<!-- ============ EXAM PAUSE OVERLAY ============ -->
<div id="pause-overlay" class="pause-overlay hidden" role="dialog" aria-modal="true" aria-labelledby="pause-title">
  <div class="pause-card">
    <div class="pause-badge">⏸</div>
    <h2 id="pause-title">Exam Attempt Paused</h2>
    <p>The 120-minute countdown is frozen at <strong id="pause-time-display">120:00</strong>.<br>Question content is concealed while paused to mirror actual testing center conditions.</p>
    <div class="pause-stats">
      <div><b id="pause-answered">0/60</b><span>Answered</span></div>
      <div><b id="pause-remaining">60</b><span>Remaining</span></div>
      <div><b id="pause-flagged">0</b><span>Flagged</span></div>
    </div>
    <div class="pause-actions">
      <button type="button" class="btn accent large" id="resume-exam-btn">▶ Resume Exam</button>
      <button type="button" class="btn ghost" id="pause-quit-btn">Save Progress & Exit</button>
    </div>
    <span class="pause-hint">Press <kbd>Space</kbd> or <kbd>P</kbd> to resume</span>
  </div>
</div>

<!-- ============ RESULTS ============ -->
<section id="screen-results" class="screen results hidden">
  <div class="wrap">
    <header class="topbar">
      <a class="brand" href="#" onclick="return false">
        <span class="logo">CA</span>
        <span class="brand-txt"><strong>CCA-F Prep Lab</strong><span>Official Score Report</span></span>
      </a>
      <span class="top-pill" id="result-pill"><i class="dot"></i> Attempt Completed</span>
    </header>
    <div class="res-head">
      <div>
        <p class="eyebrow">Diagnostic Score Report</p>
        <h1 id="result-title">Set 1 Result</h1>
        <p id="result-sub">Exam Simulation · 60 Questions</p>
      </div>
      <button class="btn ghost small" id="home-from-results">Back to Sets</button>
    </div>
    <div class="result-grid">
      <div class="score-card">
        <div class="ring" id="score-ring" style="--pct:0;--ring-color:var(--green)">
          <div class="ring-in"><strong id="scaled-score">0</strong><span>Scaled Score</span></div>
        </div>
        <div class="verdict" id="verdict"><i class="v-dot"></i> Calculating...</div>
        <p id="score-note">Passing threshold is 720. Aim for 80%+ consistency before taking the real exam.</p>
        <div class="result-facts">
          <div><b id="fact-correct">0</b><span>Correct</span></div>
          <div><b id="fact-pct">0%</b><span>Accuracy</span></div>
          <div><b id="fact-time">0m</b><span>Active Time</span></div>
        </div>
      </div>
      <div class="breakdown">
        <h2>Domain Breakdown</h2>
        <p class="sub">Performance across the 5 Anthropic Blueprint Domains</p>
        <div id="domain-rows"></div>
        <div class="callout" id="result-callout"></div>
        <div class="res-actions">
          <button class="btn accent" id="review-answers">Review All Answers & Traps</button>
          <button class="btn ghost" id="retry-set">Retry Set (Fresh Shuffle)</button>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ============ REVIEW ============ -->
<section id="screen-review" class="screen review hidden">
  <div class="wrap">
    <header class="topbar">
      <a class="brand" href="#" onclick="return false">
        <span class="logo">CA</span>
        <span class="brand-txt"><strong>CCA-F Prep Lab</strong><span>Comprehensive Item Review</span></span>
      </a>
      <button class="btn ghost small" id="back-to-results">← Back to Score Report</button>
    </header>
    <div class="review-head">
      <div>
        <p class="eyebrow">Item-by-Item Analysis</p>
        <h1 id="review-title">Set 1 Review</h1>
        <p id="review-sub">Review correct keys, distractors, and production trap explanations.</p>
      </div>
      <div class="filters" id="review-filters">
        <button type="button" data-filter="all" class="active">All Items (60)</button>
        <button type="button" data-filter="wrong">Incorrect Only</button>
        <button type="button" data-filter="flagged">Flagged Only</button>
      </div>
    </div>
    <div class="review-list" id="review-list"></div>
  </div>
</section>

<!-- ============ DRAWER (MOBILE PALETTE) ============ -->
<div class="drawer-overlay hidden" id="drawer-overlay" onclick="closeDrawer()"></div>
<div class="drawer hidden" id="drawer">
  <div class="drawer-head">
    <div>
      <h3>Question Palette</h3>
      <span style="font-size:12px;color:var(--ink-3)" id="answered-count-drawer">0 / 60</span>
    </div>
    <button class="btn ghost small" onclick="closeDrawer()">✕</button>
  </div>
  <div style="display:flex;justify-content:space-between;margin-bottom:12px;gap:8px">
    <button type="button" class="mini-btn" id="drawer-reshuffle-btn">🔀 Reshuffle</button>
    <button type="button" class="btn accent small" id="submit-drawer">Submit Exam</button>
  </div>
  <div class="palette" id="palette-drawer"></div>
  <div class="legend" style="margin-top:16px">
    <span><i class="ans"></i>Answered</span>
    <span><i class="flag"></i>Flagged</span>
    <span><i class="cur"></i>Current</span>
  </div>
</div>

<div id="modal-root"></div>
<div id="toast-root"></div>

<!-- Embedded Question Data Sets (100% Standalone Offline) -->
<script>
${set1Raw}
</script>
<script>
${set2Raw}
</script>
<script>
${set3Raw}
</script>
<script>
window.QUIZ_DATA = {
  meta: {
    exam: "Claude Certified Architect — Foundations (CCAR-F)",
    blueprintVersion: "1.0",
    sets: 3,
    questionsPerSet: 60,
    passScaled: 720
  },
  sets: [
    {
      id: 1,
      title: "Core Architectural Judgment",
      blurb: "60 scenario-based questions evaluating agentic loops, subagent context boundaries, MCP tool schemas, and prompt caching.",
      questions: window.SET1_QUESTIONS
    },
    {
      id: 2,
      title: "Production Patterns & Failure Modes",
      blurb: "60 scenario questions focusing on orchestration error recovery, CLAUDE.md hierarchy, schema compliance, and testing workflows.",
      questions: window.SET2_QUESTIONS
    },
    {
      id: 3,
      title: "Enterprise Scale & Trap Scenarios",
      blurb: "60 advanced scenario & trap questions on MCP transports, reasoning budgets, prefix caching, and CI/CD automation.",
      questions: window.SET3_QUESTIONS
    }
  ]
};
</script>

<!-- Main Quiz Application Logic -->
<script>
(function(){
  'use strict';

  const DOMAINS = {
    D1:{name:'Agentic Architecture & Orchestration', short:'Agentic', weight:27, cls:'d1'},
    D2:{name:'Tool Design & MCP Integration', short:'Tools & MCP', weight:18, cls:'d2'},
    D3:{name:'Claude Code Configuration & Workflows', short:'Claude Code', weight:20, cls:'d3'},
    D4:{name:'Prompt Engineering & Structured Output', short:'Prompting', weight:20, cls:'d4'},
    D5:{name:'Context Management & Reliability', short:'Context', weight:15, cls:'d5'}
  };
  const EXAM_SECONDS = 120 * 60; // 120 minutes
  const SAVE_KEY = 'ccaf-prep-attempt-v2';
  
  const state = {
    mode: 'practice', // 'practice' or 'exam'
    setId: 1,
    idx: 0,
    answers: {},
    revealed: new Set(),
    flags: new Set(),
    finished: false,
    startedAt: 0,
    endAt: 0,
    timeLeft: EXAM_SECONDS,
    activeElapsed: 0,
    isPaused: false,
    timerId: null,
    result: null,
    filter: 'all',
    questions: null
  };

  const $ = (sel, root=document) => root.querySelector(sel);
  const $$ = (sel, root=document) => Array.from(root.querySelectorAll(sel));
  const esc = (s) => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const currentSet = () => QUIZ_DATA.sets.find(s => s.id === state.setId) || QUIZ_DATA.sets[0];
  const currentQuestions = () => (state.questions && state.questions.length) ? state.questions : currentSet().questions;
  const currentQuestion = () => currentQuestions()[state.idx];
  const totalQuestions = () => currentQuestions().length;
  const letters = ['A','B','C','D','E','F'];

  function shuffle(arr){
    const a = arr.slice();
    for(let i = a.length - 1; i > 0; i--){
      const j = Math.floor(Math.random() * (i + 1));
      const temp = a[i];
      a[i] = a[j];
      a[j] = temp;
    }
    return a;
  }

  function show(screen){
    ['home','quiz','results','review'].forEach(name => {
      $('#screen-'+name).classList.toggle('hidden', name !== screen);
    });
    window.scrollTo({top:0,behavior:'instant'});
  }

  function toast(msg){
    const root = $('#toast-root');
    root.innerHTML = '<div class="toast">'+esc(msg)+'</div>';
    clearTimeout(toast._t);
    toast._t = setTimeout(() => { root.innerHTML = ''; }, 2200);
  }

  function modal(title, body, actions){
    const root = $('#modal-root');
    root.innerHTML = '<div class="modal-overlay" role="presentation"><div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">'+
      '<h3 id="modal-title">'+esc(title)+'</h3><p>'+body+'</p><div class="modal-actions">'+
      actions.map((a,i)=>'<button type="button" class="btn '+(a.cls||'ghost')+'" data-modal-action="'+i+'">'+esc(a.label)+'</button>').join('')+
      '</div></div></div>';
    $$('[data-modal-action]', root).forEach(btn => {
      btn.addEventListener('click', () => {
        const a = actions[Number(btn.dataset.modalAction)];
        root.innerHTML = '';
        if (a && typeof a.onClick === 'function') a.onClick();
      });
    });
  }

  function closeModal(){ $('#modal-root').innerHTML = ''; }

  function answeredCount(){
    return Object.keys(state.answers).filter(k => Array.isArray(state.answers[k]) && state.answers[k].length).length;
  }

  function isAnswered(q){ return Array.isArray(state.answers[q.id]) && state.answers[q.id].length > 0; }

  function sameSet(a,b){
    if(!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) return false;
    const x = a.slice().sort((m,n)=>m-n), y = b.slice().sort((m,n)=>m-n);
    return x.every((v,i)=>v===y[i]);
  }

  /* ---------------- HOME / SETS ---------------- */
  function setProgress(id){
    try{
      const raw = localStorage.getItem(SAVE_KEY);
      if(!raw) return null;
      const s = JSON.parse(raw);
      if(s.setId !== id || s.finished) return null;
      return s;
    }catch(e){ return null; }
  }

  function renderHome(){
    const cards = QUIZ_DATA.sets.map((set) => {
      const p = setProgress(set.id);
      const answered = p ? Object.keys(p.answers||{}).filter(k => (p.answers[k]||[]).length).length : 0;
      const modeLabel = p ? (p.mode === 'exam' ? 'Exam' : 'Practice') : '';
      return '<article class="set-card">'+
        '<div class="set-num"><b>Mock Set '+set.id+'</b><span>'+set.questions.length+' Questions</span></div>'+
        '<h3>'+esc(set.title)+'</h3>'+
        '<p>'+esc(set.blurb)+'</p>'+
        '<div class="chips">'+
          '<span class="chip d1">16 Agentic (27%)</span>'+
          '<span class="chip d3">12 Code (20%)</span>'+
          '<span class="chip d4">12 Prompt (20%)</span>'+
          '<span class="chip d2">11 MCP (18%)</span>'+
          '<span class="chip d5">9 Context (15%)</span>'+
        '</div>'+
        '<div class="set-foot">'+
          '<span class="progress-text">'+(p ? esc(modeLabel)+' · '+answered+' answered' : 'Not started')+'</span>'+
          '<div style="display:flex;gap:6px;align-items:center">'+
            (p ? '<button class="btn small ghost" data-restart="'+set.id+'" title="Start fresh shuffled attempt">Restart</button>' : '')+
            '<button class="btn small '+(p?'accent':'')+'" data-start="'+set.id+'">'+(p?'Resume':'Start Exam')+' <span class="arrow">→</span></button>'+
          '</div>'+
        '</div>'+
      '</article>';
    }).join('');
    $('#set-cards').innerHTML = cards;
    
    $$('[data-start]').forEach(btn => btn.addEventListener('click', () => {
      const id = Number(btn.dataset.start);
      const saved = setProgress(id);
      if(saved){ resumeSaved(saved); }
      else { startSet(id); }
    }));

    $$('[data-restart]').forEach(btn => btn.addEventListener('click', () => {
      const id = Number(btn.dataset.restart);
      modal('Start New Shuffled Attempt?', 'This will discard your previous progress and begin Set '+id+' with a brand-new randomized question order.', [
        {label:'Cancel', cls:'ghost'},
        {label:'Restart & Shuffle', cls:'accent', onClick:()=>startSet(id)}
      ]);
    }));

    const saved = readSaved();
    const slot = $('#resume-slot');
    if(saved && !saved.finished){
      const set = QUIZ_DATA.sets.find(s => s.id === saved.setId);
      slot.innerHTML = '<div class="resume-banner"><span><strong>Unfinished '+esc(saved.mode)+' attempt:</strong> '+esc(set?set.title:'Set')+' — question '+((saved.idx||0)+1)+' of '+totalFor(saved.setId)+'.</span>'+
        '<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">'+
          '<button class="btn small" id="resume-btn">Resume Attempt</button>'+
          '<button class="btn small ghost" id="discard-resume-btn">Start Fresh</button>'+
        '</div></div>';
      $('#resume-btn').addEventListener('click', () => resumeSaved(saved));
      $('#discard-resume-btn').addEventListener('click', () => {
        modal('Discard Attempt?', 'Start a brand-new attempt with newly shuffled questions?', [
          {label:'Cancel', cls:'ghost'},
          {label:'Start Fresh', cls:'accent', onClick:()=>startSet(saved.setId)}
        ]);
      });
    } else slot.innerHTML = '';
  }

  function totalFor(id){ const s = QUIZ_DATA.sets.find(x=>x.id===id); return s ? s.questions.length : 60; }

  function readSaved(){
    try{ return JSON.parse(localStorage.getItem(SAVE_KEY) || 'null'); }catch(e){ return null; }
  }

  function save(){
    if(state.finished) return;
    try{
      localStorage.setItem(SAVE_KEY, JSON.stringify({
        setId: state.setId,
        mode: state.mode,
        idx: state.idx,
        answers: state.answers,
        revealed: Array.from(state.revealed),
        flags: Array.from(state.flags),
        questionIds: (state.questions || []).map(q => q.id),
        startedAt: state.startedAt,
        endAt: state.endAt,
        timeLeft: state.timeLeft,
        activeElapsed: state.activeElapsed,
        isPaused: state.isPaused,
        finished: false
      }));
    }catch(e){ /* storage full or disabled */ }
  }

  function clearSave(){
    try{ localStorage.removeItem(SAVE_KEY); }catch(e){}
  }

  function resumeSaved(saved){
    state.setId = saved.setId;
    state.mode = saved.mode || 'practice';
    const baseSet = QUIZ_DATA.sets.find(s => s.id === saved.setId) || QUIZ_DATA.sets[0];
    if(Array.isArray(saved.questionIds) && saved.questionIds.length){
      const qMap = new Map(baseSet.questions.map(q => [q.id, q]));
      const restored = saved.questionIds.map(id => qMap.get(id)).filter(Boolean);
      state.questions = restored.length === baseSet.questions.length ? restored : shuffle(baseSet.questions);
    } else {
      state.questions = shuffle(baseSet.questions);
    }
    state.idx = Math.min(saved.idx||0, totalQuestions()-1);
    state.answers = saved.answers || {};
    state.revealed = new Set(saved.revealed || []);
    state.flags = new Set(saved.flags || []);
    state.finished = false;
    state.startedAt = saved.startedAt || Date.now();
    state.timeLeft = typeof saved.timeLeft === 'number' ? saved.timeLeft : EXAM_SECONDS;
    state.activeElapsed = saved.activeElapsed || (EXAM_SECONDS - state.timeLeft);
    state.isPaused = Boolean(saved.isPaused);
    state.endAt = Date.now() + state.timeLeft * 1000;
    beginQuiz(true);
  }

  function startSet(id){
    state.setId = id;
    const baseSet = QUIZ_DATA.sets.find(s => s.id === id) || QUIZ_DATA.sets[0];
    // Always Fisher-Yates shuffle questions on every new attempt!
    state.questions = shuffle(baseSet.questions);
    state.idx = 0;
    state.answers = {};
    state.revealed = new Set();
    state.flags = new Set();
    state.finished = false;
    state.startedAt = Date.now();
    state.timeLeft = EXAM_SECONDS;
    state.activeElapsed = 0;
    state.isPaused = false;
    state.endAt = Date.now() + EXAM_SECONDS * 1000;
    clearSave();
    beginQuiz(false);
  }

  function beginQuiz(resumed){
    show('quiz');
    $('#quiz-title').textContent = 'Set '+state.setId+' · '+(state.mode === 'exam' ? 'Exam Simulation' : 'Practice Mode');
    $('#side-mode-note').textContent = state.mode === 'exam' ? 'Feedback is hidden until you submit.' : 'Answers & rationales reveal instantly.';
    $('#submit-side').textContent = state.mode === 'exam' ? 'Submit Exam' : 'Submit Set';
    $('#submit-drawer').textContent = state.mode === 'exam' ? 'Submit Exam' : 'Submit Set';
    
    const timerEl = $('#timer');
    if(state.mode === 'exam'){
      timerEl.classList.remove('hidden');
      if(state.isPaused){
        showPauseOverlay();
        updateTimerDisplay();
      } else {
        hidePauseOverlay();
        startTimer();
      }
    } else {
      timerEl.classList.add('hidden');
      hidePauseOverlay();
      stopTimerInterval();
    }
    renderQuestion();
    save();
    if(resumed) toast('Attempt resumed');
  }

  /* ---------------- TIMER WITH PAUSE & START ---------------- */
  function startTimer(){
    stopTimerInterval();
    if(state.mode !== 'exam' || state.finished) return;
    
    state.endAt = Date.now() + state.timeLeft * 1000;
    updateTimerDisplay();
    
    state.timerId = setInterval(() => {
      if(state.isPaused || state.finished) return;
      const left = Math.max(0, Math.ceil((state.endAt - Date.now()) / 1000));
      state.timeLeft = left;
      state.activeElapsed = EXAM_SECONDS - left;
      updateTimerDisplay();
      if(left <= 0){
        stopTimerInterval();
        submitQuiz(true); // auto submit when time expires
      }
    }, 1000);
  }

  function stopTimerInterval(){
    if(state.timerId){
      clearInterval(state.timerId);
      state.timerId = null;
    }
  }

  function pauseTimer(){
    if(state.mode !== 'exam' || state.finished || state.isPaused) return;
    stopTimerInterval();
    state.isPaused = true;
    updateTimerDisplay();
    showPauseOverlay();
    save();
    toast('Exam timer paused');
  }

  function resumeTimer(){
    if(state.mode !== 'exam' || state.finished || !state.isPaused) return;
    state.isPaused = false;
    hidePauseOverlay();
    startTimer();
    save();
    toast('Exam resumed');
  }

  function toggleTimerPause(){
    if(state.isPaused){
      resumeTimer();
    } else {
      pauseTimer();
    }
  }

  function updateTimerDisplay(){
    const el = $('#timer');
    const textEl = $('#timer-text');
    const pauseIcon = $('#timer-icon-pause');
    const playIcon = $('#timer-icon-play');
    if(!el || !textEl) return;

    const left = state.timeLeft;
    const m = Math.floor(left / 60);
    const s = left % 60;
    textEl.textContent = String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');

    if(state.isPaused){
      el.classList.add('paused');
      el.classList.remove('warn', 'danger');
      if(pauseIcon) pauseIcon.classList.add('hidden');
      if(playIcon) playIcon.classList.remove('hidden');
      $('#timer-pause-btn').title = "Start/Resume Timer (Space or P)";
    } else {
      el.classList.remove('paused');
      el.classList.toggle('warn', left <= 600 && left > 300);
      el.classList.toggle('danger', left <= 300);
      if(pauseIcon) pauseIcon.classList.remove('hidden');
      if(playIcon) playIcon.classList.add('hidden');
      $('#timer-pause-btn').title = "Pause Timer (Space or P)";
    }
  }

  function showPauseOverlay(){
    const overlay = $('#pause-overlay');
    if(!overlay) return;
    overlay.classList.remove('hidden');
    $('#question-card').classList.add('content-blurred');
    
    const m = Math.floor(state.timeLeft / 60);
    const s = state.timeLeft % 60;
    $('#pause-time-display').textContent = String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
    const answered = answeredCount();
    const total = totalQuestions();
    $('#pause-answered').textContent = answered + '/' + total;
    $('#pause-remaining').textContent = (total - answered);
    $('#pause-flagged').textContent = state.flags.size;
  }

  function hidePauseOverlay(){
    const overlay = $('#pause-overlay');
    if(!overlay) return;
    overlay.classList.add('hidden');
    $('#question-card').classList.remove('content-blurred');
  }

  /* ---------------- RENDERING QUESTION ---------------- */
  function renderQuestion(){
    const q = currentQuestion();
    if(!q) return;
    const answered = isAnswered(q);
    const revealed = state.mode === 'practice' && state.revealed.has(q.id);
    const locked = revealed || state.finished;
    const selected = state.answers[q.id] || [];
    const n = q.type === 'multi' ? (q.n || 2) : 1;

    const meta = '<div class="q-meta">'+
      '<span class="badge domain" data-d="'+q.d+'">'+esc(DOMAINS[q.d].name)+'</span>'+
      '<span class="badge plain">Task '+esc(q.t)+'</span>'+
      '<span class="badge plain">'+(q.type === 'multi' ? 'Select '+n : 'Select One')+'</span>'+
      '<button class="flag-btn '+(state.flags.has(q.id)?'on':'')+'" id="flag-q" aria-pressed="'+(state.flags.has(q.id)?'true':'false')+'">'+
        (state.flags.has(q.id)?'⚐ Flagged':'⚑ Flag for Review')+
      '</button>'+
    '</div>';

    const options = q.o.map((opt, i) => {
      let cls = 'option';
      let mark = '';
      if(selected.includes(i)) cls += ' selected';
      if(revealed){
        cls += ' locked';
        if(q.a.includes(i)){ cls += ' correct'; mark = '<span class="mark">✓</span>'; }
        else if(selected.includes(i)){ cls += ' incorrect'; mark = '<span class="mark">✕</span>'; }
      }
      return '<button type="button" class="'+cls+'" data-opt="'+i+'" '+(locked?'disabled aria-disabled="true"':'')+'>'+
        '<span class="letter">'+letters[i]+'</span><span class="opt-text">'+esc(opt)+'</span>'+mark+'</button>';
    }).join('');

    let feedback = '';
    if(revealed){
      const ok = sameSet(selected, q.a);
      feedback = '<div class="feedback">'+
        '<div class="fb-head '+(ok?'ok':'bad')+'"><span class="fb-icon">'+(ok?'✓':'✕')+'</span>'+(ok?'Correct':'Architectural Trap / Incorrect')+'</div>'+
        '<div class="fb-body"><p><strong>Key: '+q.a.map(i=>letters[i]).join(', ')+'.</strong> '+esc(q.e)+'</p>'+
        '<div class="fb-task">Domain '+q.d+' · Task '+esc(q.t)+' — '+esc(DOMAINS[q.d].name)+'</div></div>'+
      '</div>';
    }

    const isLast = state.idx === totalQuestions() - 1;
    let actions = '';
    if(state.mode === 'practice'){
      if(q.type === 'multi' && !revealed){
        actions = '<div class="q-actions"><span class="check-note">Select exactly '+n+' options.</span><div class="q-actions-right">'+
          '<button class="btn ghost" data-nav="prev" '+(state.idx===0?'disabled':'')+'>← Prev</button>'+
          '<button class="btn accent" id="check-answer" '+(selected.length===n?'':'disabled')+'>Check Answer</button>'+
        '</div></div>';
      } else {
        actions = '<div class="q-actions"><div class="q-actions-right">'+
          '<button class="btn ghost" data-nav="prev" '+(state.idx===0?'disabled':'')+'>← Prev</button>'+
          '<button class="btn '+(isLast?'accent':'ghost')+'" data-nav="next">'+(isLast?'Finish & Score':'Next →')+'</button>'+
        '</div></div>';
      }
    } else {
      actions = '<div class="q-actions"><span class="check-note">'+(answered?'✓ Answer saved.':'Select an option.')+'</span><div class="q-actions-right">'+
        '<button class="btn ghost" data-nav="prev" '+(state.idx===0?'disabled':'')+'>← Prev</button>'+
        '<button class="btn '+(isLast?'accent':'ghost')+'" data-nav="next">'+(isLast?'Finish Exam':'Next →')+'</button>'+
      '</div></div>';
    }

    $('#question-card').innerHTML = meta+
      '<h2 class="q-text">'+esc(q.q)+'</h2>'+
      '<p class="q-hint">'+(q.type === 'multi' ? 'Multiple response — select '+n+' options.' : 'Choose the single best architectural answer.')+'</p>'+
      '<div class="options" id="options">'+options+'</div>'+feedback+actions;

    if(state.isPaused) $('#question-card').classList.add('content-blurred');
    else $('#question-card').classList.remove('content-blurred');

    $$('#options .option').forEach(btn => btn.addEventListener('click', () => chooseOption(Number(btn.dataset.opt))));
    const flagBtn = $('#flag-q');
    if(flagBtn) flagBtn.addEventListener('click', toggleFlag);
    $$('[data-nav]').forEach(btn => btn.addEventListener('click', () => nav(btn.dataset.nav)));
    const check = $('#check-answer');
    if(check) check.addEventListener('click', () => checkMulti());

    updateChrome();
  }

  function updateChrome(){
    const total = totalQuestions();
    const pct = ((state.idx + 1) / total) * 100;
    $('#quiz-progress-bar').style.width = pct + '%';
    $('#quiz-subtitle').textContent = 'Question ' + (state.idx + 1) + ' of ' + total + ' · Shuffled';
    const count = answeredCount();
    $('#answered-count').textContent = count + ' / ' + total;
    $('#answered-count-drawer').textContent = count + ' / ' + total;
    $('#mobile-map').textContent = 'Map (' + count + '/' + total + ')';
    $('#side-flags-count').textContent = state.flags.size + ' flagged';
    $('#mobile-prev').disabled = state.idx === 0;
    const isLast = state.idx === total - 1;
    $('#mobile-next').textContent = isLast ? 'Finish' : 'Next →';
    renderPalettes();
  }

  function renderPalettes(){
    const qs = currentQuestions();
    const build = () => qs.map((q, i) => {
      const classes = ['palette-btn'];
      if(isAnswered(q)) classes.push('answered');
      if(state.flags.has(q.id)) classes.push('flagged');
      if(i === state.idx) classes.push('current');
      if(state.mode === 'practice' && state.revealed.has(q.id)){
        classes.push(sameSet(state.answers[q.id]||[], q.a) ? 'correct' : 'wrong');
      }
      return '<button type="button" class="palette-button '+classes.join(' ')+'" data-jump="'+i+'" aria-label="Question '+(i+1)+(isAnswered(q)?', answered':'')+(state.flags.has(q.id)?', flagged':'')+'">'+(i+1)+'</button>';
    }).join('');
    
    $('#palette-desktop').innerHTML = build();
    $('#palette-drawer').innerHTML = build();
    
    $$('[data-jump]').forEach(btn => btn.addEventListener('click', () => {
      state.idx = Number(btn.dataset.jump);
      renderQuestion();
      closeDrawer();
      save();
    }));
  }

  function chooseOption(i){
    const q = currentQuestion();
    if(state.mode === 'practice' && state.revealed.has(q.id)) return;
    if(state.finished || state.isPaused) return;
    const n = q.type === 'multi' ? (q.n || 2) : 1;
    let sel = (state.answers[q.id] || []).slice();
    if(n === 1){
      sel = [i];
    } else {
      if(sel.includes(i)) sel = sel.filter(x => x !== i);
      else if(sel.length < n) sel.push(i);
      else { toast('Select exactly '+n+' options. Deselect one first.'); return; }
    }
    state.answers[q.id] = sel;
    if(n === 1 && state.mode === 'practice'){
      state.revealed.add(q.id);
    }
    renderQuestion();
    save();
  }

  function checkMulti(){
    const q = currentQuestion();
    const n = q.n || 2;
    const sel = state.answers[q.id] || [];
    if(sel.length !== n){ toast('Select exactly '+n+' options.'); return; }
    state.revealed.add(q.id);
    renderQuestion();
    save();
  }

  function toggleFlag(){
    const q = currentQuestion();
    if(state.flags.has(q.id)) state.flags.delete(q.id);
    else state.flags.add(q.id);
    renderQuestion();
    save();
  }

  function nav(dir){
    if(dir === 'prev'){
      if(state.idx > 0){ state.idx--; renderQuestion(); save(); }
      return;
    }
    if(state.idx < totalQuestions() - 1){
      state.idx++; renderQuestion(); save();
    } else {
      confirmSubmit();
    }
  }

  function reshuffleCurrentSet(){
    modal('Reshuffle Questions?', 'This will randomize the question presentation order for this attempt. Your chosen answers will be kept.', [
      {label:'Cancel', cls:'ghost'},
      {
        label:'Reshuffle Now',
        cls:'accent',
        onClick:()=>{
          state.questions = shuffle(state.questions || currentSet().questions);
          state.idx = 0;
          renderQuestion();
          save();
          toast('Questions reshuffled');
        }
      }
    ]);
  }

  /* ---------------- SUBMIT & SCORE ---------------- */
  function confirmSubmit(){
    const unanswered = totalQuestions() - answeredCount();
    const body = unanswered > 0
      ? 'You have <strong>'+unanswered+' unanswered</strong> question'+(unanswered===1?'':'s')+'. Unanswered items score zero. Submit and finalize your attempt?'
      : 'All '+totalQuestions()+' questions are answered. Submit and view your official score report?';
    modal('Submit Exam Attempt?', body, [
      {label:'Keep Working', cls:'ghost'},
      {label:'Submit & Score', cls:'accent', onClick:()=>submitQuiz(false)}
    ]);
  }

  function submitQuiz(auto){
    if(state.finished) return;
    state.finished = true;
    stopTimerInterval();
    hidePauseOverlay();
    state.result = calculateResult();
    clearSave();
    renderResults(auto);
    show('results');
  }

  function calculateResult(){
    const qs = currentQuestions();
    let correct = 0;
    const byDomain = {};
    Object.keys(DOMAINS).forEach(d => byDomain[d] = {correct:0, total:0});
    qs.forEach(q => {
      byDomain[q.d].total++;
      if(sameSet(state.answers[q.id]||[], q.a)){
        correct++;
        byDomain[q.d].correct++;
      }
    });
    const total = qs.length;
    const pct = correct / total;
    const scaled = Math.round(100 + pct * 900);
    const elapsed = state.activeElapsed || (state.mode === 'exam' ? Math.min(EXAM_SECONDS, Math.round((Date.now() - state.startedAt)/1000)) : Math.round((Date.now() - state.startedAt)/1000));
    return {correct, total, pct, scaled, byDomain, elapsed, passed: scaled >= 720};
  }

  function renderResults(auto){
    const r = state.result;
    $('#result-title').textContent = 'Set '+state.setId+' Score Report';
    $('#result-sub').textContent = (state.mode === 'exam' ? 'Timed Exam Simulation (120 min)' : 'Practice Mode') + ' · ' + r.total + ' Questions' + (auto ? ' · Auto-submitted at 0:00' : '');
    $('#scaled-score').textContent = r.scaled;
    $('#score-ring').style.setProperty('--pct', Math.max(0, Math.min(100, (r.scaled - 100) / 9)));
    $('#score-ring').style.setProperty('--ring-color', r.passed ? 'var(--green)' : (r.scaled >= 640 ? 'var(--amber)' : 'var(--red)'));
    const verdict = $('#verdict');
    verdict.className = 'verdict ' + (r.passed ? 'pass' : 'fail');
    verdict.innerHTML = '<i class="v-dot"></i> ' + (r.passed ? 'Above Passing Standard (720)' : (r.scaled >= 640 ? 'Near Passing — Review Weak Areas' : 'Below Passing Standard'));
    $('#score-note').textContent = r.passed
      ? 'Congratulations! You scored in the certification passing range (720+). Review the questions below to lock in the nuances.'
      : 'Passing scaled benchmark is 720 / 1000 (~72%). Focus on your weakest domains below and attempt another set.';
    $('#fact-correct').textContent = r.correct + ' / ' + r.total;
    $('#fact-pct').textContent = Math.round(r.pct * 100) + '%';
    const mins = Math.floor(r.elapsed / 60), secs = r.elapsed % 60;
    $('#fact-time').textContent = mins + 'm ' + (secs ? secs + 's' : '');
    $('#result-pill').innerHTML = '<i class="dot"></i> ' + (r.passed ? 'Passed (720+)' : 'Needs Review');

    $('#domain-rows').innerHTML = Object.keys(DOMAINS).map(d => {
      const s = r.byDomain[d];
      const p = s.total ? s.correct / s.total : 0;
      return '<div class="domain-row">'+
        '<div class="domain-label"><strong>'+esc(DOMAINS[d].name)+' <span style="color:var(--ink-3)">'+DOMAINS[d].weight+'% Weight</span></strong><span>'+s.correct+'/'+s.total+' · '+Math.round(p*100)+'%</span></div>'+
        '<div class="bar"><i class="'+DOMAINS[d].cls+'" style="width:'+(p*100)+'%"></i></div>'+
      '</div>';
    }).join('');

    const weakest = Object.keys(DOMAINS).map(d => ({d, p: r.byDomain[d].total ? r.byDomain[d].correct/r.byDomain[d].total : 0})).sort((a,b)=>a.p-b.p)[0];
    const strong = Object.keys(DOMAINS).map(d => ({d, p: r.byDomain[d].total ? r.byDomain[d].correct/r.byDomain[d].total : 0})).sort((a,b)=>b.p-a.p)[0];
    $('#result-callout').innerHTML = '<strong>Diagnostic Recommendation:</strong> Your strongest domain is <strong>'+esc(DOMAINS[strong.d].name)+'</strong> at '+Math.round(strong.p*100)+'%. Your most critical growth area is <strong>'+esc(DOMAINS[weakest.d].name)+'</strong> at '+Math.round(weakest.p*100)+'%. Review every incorrect scenario below, then take the next mock set.';
  }

  function startReview(){
    state.filter = 'all';
    renderReview();
    show('review');
  }

  function renderReview(){
    const qs = currentQuestions();
    $('#review-title').textContent = 'Set '+state.setId+' Item Review';
    const wrongCount = qs.filter(q => !sameSet(state.answers[q.id]||[], q.a)).length;
    $('#review-sub').textContent = (qs.length - wrongCount) + ' correct · ' + wrongCount + ' incorrect · detailed production rationale for every choice.';
    $$('#review-filters button').forEach(b => b.classList.toggle('active', b.dataset.filter === state.filter));

    const filtered = qs.filter(q => {
      if(state.filter === 'wrong') return !sameSet(state.answers[q.id]||[], q.a);
      if(state.filter === 'flagged') return state.flags.has(q.id);
      return true;
    });

    if(!filtered.length){
      $('#review-list').innerHTML = '<div class="empty">No questions match this filter criteria. Try clicking "All Items".</div>';
      return;
    }

    $('#review-list').innerHTML = filtered.map(q => {
      const num = qs.indexOf(q) + 1;
      const chosen = state.answers[q.id] || [];
      const ok = sameSet(chosen, q.a);
      const opts = q.o.map((opt, i) => {
        let cls = 'r-opt';
        if(q.a.includes(i)) cls += ' correct';
        else if(chosen.includes(i)) cls += ' chosen-wrong';
        const label = q.a.includes(i) ? 'Official Key' : (chosen.includes(i) ? 'Your Choice' : '');
        return '<div class="'+cls+'"><b>'+letters[i]+'</b><span>'+esc(opt)+'</span>'+(label?'<em style="margin-left:auto;font-size:10px;font-style:normal;font-weight:760;letter-spacing:.05em;text-transform:uppercase;opacity:.8">'+label+'</em>':'')+'</div>';
      }).join('');

      return '<article class="r-card '+(ok?'right':'wrong')+'">'+
        '<div class="r-top"><span class="r-num">Question '+num+'</span>'+
          '<span class="badge domain" data-d="'+q.d+'">'+esc(DOMAINS[q.d].short)+'</span>'+
          '<span class="badge plain">Task '+esc(q.t)+'</span>'+
          '<span class="r-tags"><span class="badge plain">'+(q.type==='multi'?'Multiple Select ('+(q.n||2)+')':'Single Choice')+'</span>'+(state.flags.has(q.id)?'<span class="badge" style="color:var(--accent-deep);background:var(--accent-soft);border-color:#eed3c5">Flagged</span>':'')+'</span>'+
        '</div>'+
        '<p class="r-q">'+esc(q.q)+'</p>'+
        '<div class="r-opts">'+opts+'</div>'+
        '<div class="r-exp"><strong>'+(ok?'Correct.':'Incorrect.')+'</strong> '+esc(q.e)+'</div>'+
      '</article>';
    }).join('');
  }

  /* ---------------- DRAWER & MODAL HELPERS ---------------- */
  function openDrawer(){
    $('#drawer').classList.remove('hidden');
    $('#drawer-overlay').classList.remove('hidden');
    renderPalettes();
    document.body.style.overflow = 'hidden';
  }

  function closeDrawer(){
    $('#drawer').classList.add('hidden');
    $('#drawer-overlay').classList.add('hidden');
    document.body.style.overflow = '';
  }
  window.closeDrawer = closeDrawer;

  /* ---------------- EVENT WIRING ---------------- */
  $$('[data-mode]').forEach(btn => btn.addEventListener('click', () => {
    state.mode = btn.dataset.mode;
    $$('[data-mode]').forEach(b => b.classList.toggle('active', b === btn));
    $('#mode-note').textContent = state.mode === 'exam'
      ? 'Exam Simulation hides all feedback until you submit. A 120-minute timer begins immediately with pause/resume support and auto-submits at zero.'
      : 'Practice Mode reveals answers and explanations as soon as you select an option. Multi-select items reveal after you press Check Answer.';
  }));

  $('#quick-start').addEventListener('click', () => {
    const saved = readSaved();
    if(saved && !saved.finished) resumeSaved(saved);
    else startSet(1);
  });

  $('#quit-quiz').addEventListener('click', () => {
    modal('Leave This Attempt?', 'Your answers and remaining time are saved on this device. You can resume anytime from the home screen.', [
      {label:'Stay', cls:'ghost'},
      {label:'Discard & Reset', cls:'ghost', onClick:()=>{ clearSave(); stopTimerInterval(); state.questions = null; renderHome(); show('home'); }},
      {label:'Save & Exit', cls:'accent', onClick:()=>{ save(); stopTimerInterval(); renderHome(); show('home'); }}
    ]);
  });

  // Timer Pause / Resume Wires
  $('#timer-pause-btn').addEventListener('click', toggleTimerPause);
  $('#resume-exam-btn').addEventListener('click', resumeTimer);
  $('#pause-quit-btn').addEventListener('click', () => {
    save();
    stopTimerInterval();
    hidePauseOverlay();
    renderHome();
    show('home');
  });

  $('#reshuffle-btn').addEventListener('click', reshuffleCurrentSet);
  $('#drawer-reshuffle-btn').addEventListener('click', () => { closeDrawer(); reshuffleCurrentSet(); });

  $('#submit-side').addEventListener('click', confirmSubmit);
  $('#submit-drawer').addEventListener('click', () => { closeDrawer(); confirmSubmit(); });
  $('#mobile-prev').addEventListener('click', () => nav('prev'));
  $('#mobile-next').addEventListener('click', () => nav('next'));
  $('#mobile-map').addEventListener('click', openDrawer);
  $('#open-drawer').addEventListener('click', openDrawer);
  $('#home-from-results').addEventListener('click', () => { renderHome(); show('home'); });
  $('#review-answers').addEventListener('click', startReview);
  $('#retry-set').addEventListener('click', () => startSet(state.setId));
  $('#back-to-results').addEventListener('click', () => { renderResults(false); show('results'); });
  
  $$('#review-filters button').forEach(btn => btn.addEventListener('click', () => {
    state.filter = btn.dataset.filter;
    renderReview();
  }));

  // Keyboard Navigation & Shortcuts
  document.addEventListener('keydown', (e) => {
    if($('#screen-quiz').classList.contains('hidden')) return;
    if(e.target && /INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) return;
    
    // Space or P to pause/resume in exam mode
    if((e.key === 'p' || e.key === 'P' || (e.code === 'Space' && state.isPaused)) && state.mode === 'exam'){
      e.preventDefault();
      toggleTimerPause();
      return;
    }
    
    // If paused, ignore navigation keys
    if(state.isPaused) return;

    if(e.key === 'ArrowRight'){ e.preventDefault(); nav('next'); }
    if(e.key === 'ArrowLeft'){ e.preventDefault(); nav('prev'); }
    if(e.key === 'f' || e.key === 'F'){ e.preventDefault(); toggleFlag(); }
    if(['1','2','3','4'].includes(e.key)){
      const i = Number(e.key) - 1;
      if(i < currentQuestion().o.length) chooseOption(i);
    }
  });

  window.addEventListener('beforeunload', (e) => {
    if(!$('#screen-quiz').classList.contains('hidden') && !state.finished){
      save();
      e.preventDefault();
      e.returnValue = '';
    }
  });

  renderHome();
  show('home');
})();
</script>
</body>
</html>
`;

fs.writeFileSync(path.join(__dirname, 'index.html'), htmlContent, 'utf8');
console.log('Successfully generated complete standalone index.html (' + htmlContent.length + ' bytes).');
