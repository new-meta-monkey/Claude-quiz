# Claude Certified Architect — Foundations (CCA-F / CCAR-F) Quiz Lab

An interactive, responsive mock exam lab and study suite designed to thoroughly prepare candidates for the **Anthropic Claude Certified Architect — Foundations** certification.

---

## 🎯 Exam Blueprint & Topic Weightage

The official CCA-F certification exam tests architectural judgment across **60 scenario-based questions**, has a **120-minute** time limit, and requires a scaled passing score of **720 / 1000** (~72%).

Every 60-question set in this lab mathematically adheres to the official domain distribution:

| Domain | Focus Area | Exam Weight | Questions / 60 | Total in Lab (3 Sets) |
| :--- | :--- | :---: | :---: | :---: |
| **Domain 1** | **Agentic Architecture & Orchestration** | **27%** | **16** | **48** |
| **Domain 2** | **Tool Design & MCP Integration** | **18%** | **11** | **33** |
| **Domain 3** | **Claude Code Configuration & Workflows** | **20%** | **12** | **36** |
| **Domain 4** | **Prompt Engineering & Structured Output** | **20%** | **12** | **36** |
| **Domain 5** | **Context Management & Reliability** | **15%** | **9** | **27** |
| **Total** | | **100%** | **60 Items** | **180 Items** |

---

## 📦 What's Inside `claude-quest/`

This suite contains **180 unique, non-repeating scenario questions** divided across three complete mock exam sets:

1. **Set 1: Core Architectural Judgment (60 questions)**  
   Core real-world scenarios evaluating agentic loops, subagent context isolation, MCP tool schemas, tool descriptions, and prompt caching.
2. **Set 2: Production Patterns & Failure Modes (60 questions)**  
   Focuses on orchestration error recovery, multi-agent degradation, CLAUDE.md hierarchy, headless CI/CD execution, and context budget management.
3. **Set 3: Enterprise Scale & Trap Scenarios (60 questions)**  
   Advanced enterprise scenarios and trap-heavy questions modeling attended candidate reviews: transient 5xx error handling, circular ping-pong tool loops, Map-Reduce fan-out, Four-Eyes approval gates, prefix cache invalidation, and extended thinking budgets.

### File Structure
* [`index.html`](file:///data/data/com.termux/files/home/claude-quest/index.html) — **Complete standalone single-file Web App** (~250 KB). Fully responsive, zero dependencies, works 100% offline in any modern browser on mobile, tablet, or desktop.
* [`questions.js`](file:///data/data/com.termux/files/home/claude-quest/questions.js) — Unified JSON dataset with all 180 questions, answer keys, domains, tasks, and explanations.
* [`data-set1.js`](file:///data/data/com.termux/files/home/claude-quest/data-set1.js) — Modular dataset for Set 1 (60 questions).
* [`data-set2.js`](file:///data/data/com.termux/files/home/claude-quest/data-set2.js) — Modular dataset for Set 2 (60 questions).
* [`data-set3.js`](file:///data/data/com.termux/files/home/claude-quest/data-set3.js) — Modular dataset for Set 3 (60 questions).

---

## ⚡ Quiz Application Features

### 1. Dual Practice & Exam Modes
* **Practice Mode (Instant Feedback)**:
  * Selecting an option immediately reveals whether it is correct or incorrect.
  * Displays the official key and an in-depth architectural rationale explaining both why the key is correct and why plausible distractors fail in production.
  * Multi-select questions feature a "Check Answer" button so you can pick the required number of options before checking.
* **Exam Simulation Mode (Reveal on Submit)**:
  * Feedback is hidden while testing to simulate real proctored conditions.
  * Real **120-minute countdown timer** with auto-submission at 0:00.
  * Unanswered questions warning before submission.
  * Post-exam score report with scaled score (100–1000), 720 pass standard, raw percentage, active time elapsed, and domain diagnostic bar charts.

### 2. Live Timer with Pause & Resume (START / PAUSE)
* Official 120-minute countdown in Exam Mode.
* **Interactive Pause Button (`⏸` / `▶`)**:
  * Clicking pause freezes the countdown immediately.
  * Conceals and blurs question content via a proctored break modal so candidates cannot study the question while paused.
  * Shows remaining time, answered count, and flagged count.
  * Resume restarts the timer from the exact second without penalizing elapsed exam time.
  * Keyboard shortcut: press **`P`** or **`Space`** to pause/resume!
  * Pause state persists across page refreshes.

### 3. Dynamic Question Shuffling on Every Attempt
* Questions are randomized using the **Fisher-Yates shuffle algorithm** on every new attempt or restart.
* Dedicated **`🔀 Reshuffle`** button available directly in the question palette to reshuffle on the fly during practice.
* Active attempt order and answers are saved to `localStorage` so refreshing never destroys your current progress.

### 4. Full Mobile & Touch Responsiveness
* Mobile-first responsive layout tested for phone screens (`<= 640px` and `<= 980px`).
* Comfortable touch targets (`>= 44px`) for easy mobile tapping.
* Sticky mobile bottom navigation toolbar with **Prev**, **Map (X/60)**, and **Next** controls.
* Slide-out **Question Palette Drawer** for jumping directly to any question.
* Visual indicators for Answered, Flagged, and Current questions.
* Safe-area insets supported for Android gesture navigation and iOS home indicators.

### 5. Detailed Review & Trap Analysis
* Post-exam review filterable by:
  * **All Items (60)**
  * **Incorrect Only**
  * **Flagged Only**
* Every question details the real production reason why candidate traps fail:
  * Stop Reason check vs string parsing (`stop_reason === "end_turn"`).
  * Subagent context isolation (subagents do NOT inherit caller's context).
  * Self-review bias (an agent reviewing its own output in the same context fails).
  * Tool calling schema validation (`tool_choice`, JSON Schema, parameter descriptions).
  * Prompt caching invalidation rules (minimum tokens, prefix matching, timestamp placement).
  * Extended thinking budgets (`budget_tokens` and `temperature: 1.0`).

---

## 🚀 How to Run the Quiz App

### Option 1: Direct File in Browser (No Server Needed)
Double-click or open [`index.html`](file:///data/data/com.termux/files/home/claude-quest/index.html) directly in any web browser (Chrome, Edge, Safari, Firefox). Because the file is completely self-contained with embedded data, it works 100% offline.

### Option 2: Local HTTP Server
Run Python's built-in web server from the `claude-quest` directory:
```bash
cd /data/data/com.termux/files/home/claude-quest
python3 -m http.server 8080
```
Then open `http://localhost:8080` in your browser.

---

## ⌨️ Keyboard Shortcuts
* **`→` (Right Arrow)**: Next question
* **`←` (Left Arrow)**: Previous question
* **`1` / `2` / `3` / `4`**: Select option A, B, C, or D
* **`F`**: Toggle flag for review
* **`P`** or **`Space`**: Pause / Resume exam timer (in Exam Mode)
