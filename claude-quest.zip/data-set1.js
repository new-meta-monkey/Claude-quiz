window.SET1_QUESTIONS = [
  {
    "id": "s1q01",
    "d": "D1",
    "t": "1.1",
    "type": "single",
    "q": "A support agent is built with a manual agentic loop. In production it sometimes performs one tool call, writes “I found your order” in the same assistant turn, and exits before processing the refund. The tool result is never sent back to the model. What is the most likely defect?",
    "o": [
      "The loop retries each tool call too many times and reaches its cap.",
      "The loop terminates when the assistant returns any text instead of inspecting stop_reason.",
      "The lookup_order tool description is too short for reliable selection.",
      "The model's max_tokens setting is too low to finish the response."
    ],
    "a": [
      1
    ],
    "e": "The loop must continue while stop_reason is “tool_use” and stop only on “end_turn”. Assistant text can appear alongside a tool_use block, so treating text as completion prematurely ends the workflow. Max tokens, tool descriptions and retry caps do not explain why the tool result was never appended."
  },
  {
    "id": "s1q02",
    "d": "D1",
    "t": "1.1",
    "type": "single",
    "q": "You are reviewing an agent loop that must support multi-step tool use. Which control flow correctly implements the lifecycle described by the exam blueprint?",
    "o": [
      "Call the model up to a fixed maximum of ten times; terminate on the tenth iteration regardless of stop_reason.",
      "Call the model; stop when the assistant text no longer contains the word “tool” or an exclamation mark.",
      "Call the model; if the reply contains a tool call, execute it and append the result, then treat the next assistant message as final.",
      "Call the model; if stop_reason is “tool_use”, execute every requested tool, append tool_result blocks to history, and continue. Stop when stop_reason is “end_turn”."
    ],
    "a": [
      3
    ],
    "e": "The reliable signal is the API's stop_reason. A “tool_use” stop means execute and return results for another model turn; “end_turn” means the model is finished. Fixed caps, keyword parsing and text heuristics are named anti-patterns because they can end work early or loop without a semantic stop."
  },
  {
    "id": "s1q03",
    "d": "D1",
    "t": "1.2",
    "type": "single",
    "q": "A research coordinator delegates the topic “AI's impact on creative industries”. Each subagent succeeds, but the final report covers only digital art, graphic design and photography. The coordinator log shows those three subtasks. Where should the fix be made?",
    "o": [
      "In the document analysis agent: relax relevance filtering so non-visual sources are not discarded.",
      "In the coordinator: improve task decomposition so the assigned scope covers all relevant creative sectors.",
      "In the web search agent: broaden its queries so it discovers music, writing and film itself.",
      "In the synthesis agent: add instructions to detect coverage gaps in the findings it receives."
    ],
    "a": [
      1
    ],
    "e": "Every downstream agent executed its assignment correctly; the assignment itself was too narrow. The coordinator owns decomposition and coverage, so it must split a broad topic into subtopics or source types that span the whole question. Blaming working subagents leaves the root cause untouched."
  },
  {
    "id": "s1q04",
    "d": "D1",
    "t": "1.2",
    "type": "multi",
    "n": 2,
    "q": "A team wants subagents to call one another directly to reduce latency, bypassing the coordinator. Which two properties of the hub-and-spoke design would this most directly weaken? (Select two.)",
    "o": [
      "The requirement that each subagent use a different model tier.",
      "Consistent error handling and controlled information flow across the system.",
      "The ability of subagents to run in parallel on independent subtasks.",
      "Central observability of inter-agent communication and routing decisions."
    ],
    "a": [
      1,
      3
    ],
    "e": "Routing all communication through the coordinator preserves an inspectable hub for routing, aggregation, error policy and controlled data movement. Parallelism can still occur through multiple Task calls from the coordinator; different model tiers are not a requirement of the pattern."
  },
  {
    "id": "s1q05",
    "d": "D1",
    "t": "1.2",
    "type": "single",
    "q": "A coordinator always invokes all four research subagents for every question, including simple factual lookups. This adds latency and produces irrelevant analysis. What is the best architectural change?",
    "o": [
      "Add a fixed rule that skips the report agent when the query has fewer than ten words.",
      "Have the coordinator analyze query requirements and dynamically invoke only the subagents needed.",
      "Merge the four subagents into one general-purpose agent with every tool.",
      "Run all four subagents in parallel so the unnecessary work finishes sooner."
    ],
    "a": [
      1
    ],
    "e": "The coordinator's role is to decide which specialists a query actually needs. Dynamic selection reduces cost while preserving specialization. Parallelizing unnecessary work hides the design problem, merging specialists increases tool confusion, and a word-count heuristic is unrelated to information need."
  },
  {
    "id": "s1q06",
    "d": "D1",
    "t": "1.3",
    "type": "single",
    "q": "A coordinator must launch a web-search subagent and a document-analysis subagent at the same time. Both need the same research brief. What is the correct Agent SDK mechanism?",
    "o": [
      "Emit two Task tool calls in a single coordinator response, with the brief included in each subagent prompt.",
      "Call the first subagent, wait for completion, then call the second in the next coordinator turn.",
      "Place both subagents in shared memory so they inherit the coordinator's conversation automatically.",
      "Expose each subagent as an MCP tool and let the model choose whichever server responds first."
    ],
    "a": [
      0
    ],
    "e": "Parallel subagent execution comes from multiple Task tool calls in one coordinator response. Subagents have isolated context, so the brief must be passed explicitly in each prompt. Sequential calls are not parallel, shared memory is not automatic inheritance, and subagents are not MCP servers."
  },
  {
    "id": "s1q07",
    "d": "D1",
    "t": "1.3",
    "type": "single",
    "q": "A synthesis subagent receives prose summaries from prior agents but no URLs. The final report cannot cite sources. Which change best preserves attribution without over-provisioning the synthesizer?",
    "o": [
      "Store all prior conversations in shared memory so the synthesis agent can inspect them later.",
      "Increase the synthesis agent's context window and ask it to “remember where each fact came from”.",
      "Require each upstream agent to return structured findings with claim, evidence excerpt, source URL, document name and date; pass those structures into the synthesis prompt.",
      "Give the synthesis agent every web-search tool so it can rediscover sources for each claim."
    ],
    "a": [
      2
    ],
    "e": "Attribution must travel with the finding as structured metadata. Subagents do not inherit the coordinator's history, so prose plus an instruction to remember is not a provenance mechanism. Giving synthesis broad search tools violates specialization; a larger window does not reconstruct lost mappings."
  },
  {
    "id": "s1q08",
    "d": "D1",
    "t": "1.4",
    "type": "single",
    "q": "An agent applies account credits before verifying the customer's identity. Logs show this happens in 8% of cases and has caused credits on the wrong account. The policy requires deterministic compliance. Which fix is appropriate?",
    "o": [
      "Add few-shot examples showing the agent verifying identity first in similar cases.",
      "Restrict the credit tool to the coordinator and leave verification to the agent's judgment.",
      "Strengthen the system prompt to say identity verification is mandatory before credits.",
      "Add a programmatic prerequisite gate that blocks credit operations until a verified customer ID is present."
    ],
    "a": [
      3
    ],
    "e": "When a prerequisite protects money or private data, prompt-based guidance remains probabilistic. A gate that checks for a verified ID before allowing the downstream call gives a deterministic guarantee. Prompting and examples reduce but do not eliminate violations; restricting tool ownership does not enforce ordering."
  },
  {
    "id": "s1q09",
    "d": "D1",
    "t": "1.4",
    "type": "single",
    "q": "A customer writes one message covering a duplicate charge, a delayed replacement, and a change of address. The agent resolves the charge and closes the case. What workflow best handles this multi-concern request?",
    "o": [
      "Handle the concerns strictly in the order they appear and stop after the first successful tool call.",
      "Decompose the message into distinct concerns, investigate each using shared case context, then synthesize one unified resolution.",
      "Escalate the entire message because multi-concern requests exceed the agent's authority.",
      "Ask the customer to send three separate tickets so each concern can be handled independently."
    ],
    "a": [
      1
    ],
    "e": "The blueprint calls for decomposing multi-concern requests, investigating each with shared context, and synthesizing a unified answer. Forcing the customer to re-submit is poor service, sequential handling can drop later concerns, and complexity alone is not an escalation trigger."
  },
  {
    "id": "s1q10",
    "d": "D1",
    "t": "1.4",
    "type": "multi",
    "n": 2,
    "q": "A mid-process escalation must hand a case to a human who cannot see the chat transcript. Which two components are most important in the structured handoff? (Select two.)",
    "o": [
      "The model's self-reported confidence score and sentiment classification.",
      "The full raw transcript with every tool payload attached.",
      "Verified customer details and the specific facts of the case, such as amount, dates and order ID.",
      "Root-cause analysis plus a recommended next action for the human agent."
    ],
    "a": [
      2,
      3
    ],
    "e": "A useful handoff is self-contained: verified identity, transactional facts, what was found, and what should happen next. Raw transcripts are large and not a summary; self-reported confidence and sentiment are explicitly unreliable proxies for case complexity."
  },
  {
    "id": "s1q11",
    "d": "D1",
    "t": "1.5",
    "type": "single",
    "q": "Three order MCP tools return timestamps as Unix seconds, ISO 8601 and a numeric status code. The agent misreads dates and compares statuses incorrectly. Where should normalization occur?",
    "o": [
      "In a retry loop that re-calls the tool until the model interprets the value correctly.",
      "By replacing the three tools with one generic tool that returns whatever format is available.",
      "In a PostToolUse hook that converts each tool result to one canonical schema before the model processes it.",
      "In the system prompt, instructing the model to infer the format from context on every call."
    ],
    "a": [
      2
    ],
    "e": "A PostToolUse hook is the deterministic place to normalize heterogeneous tool output before it enters model context. Prompt inference is probabilistic and repeated on every turn; a generic tool does not create consistency; retries cannot fix an interpretation problem."
  },
  {
    "id": "s1q12",
    "d": "D1",
    "t": "1.5",
    "type": "single",
    "q": "Company policy forbids refunds over $500 without manager approval. The agent has exceeded that limit in 3% of transactions despite a clear prompt. What control best guarantees compliance?",
    "o": [
      "Few-shot examples that show the agent escalating high-value refunds.",
      "A tool-call interception hook that blocks the refund above the threshold and routes it to human approval.",
      "A stronger system-prompt sentence in bold stating that refunds above $500 are prohibited.",
      "Lowering the model temperature so the agent follows instructions more consistently."
    ],
    "a": [
      1
    ],
    "e": "Hooks enforce business rules regardless of model sampling. Instructions and examples remain probabilistic, and temperature does not create a guarantee. The hook also provides a deterministic redirect path to human approval."
  },
  {
    "id": "s1q13",
    "d": "D1",
    "t": "1.6",
    "type": "single",
    "q": "A 14-file pull request receives inconsistent review depth: some files get detailed comments, obvious bugs are missed, and identical code is approved in one file but flagged in another. What review decomposition is most appropriate?",
    "o": [
      "Run a per-file local analysis pass for each file, then a separate cross-file integration pass for data-flow issues.",
      "Switch to a larger-context model so all 14 files fit comfortably in one prompt.",
      "Run three full-PR reviews and report only findings that appear in at least two runs.",
      "Require developers to split the PR into groups of three files before any automated review."
    ],
    "a": [
      0
    ],
    "e": "Attention dilution and contradictory local judgments are fixed by narrowing each pass. Per-file passes give consistent local depth; an integration pass handles cross-file dependencies. Larger context does not guarantee attention quality, and consensus voting can suppress intermittently detected real bugs."
  },
  {
    "id": "s1q14",
    "d": "D1",
    "t": "1.6",
    "type": "single",
    "q": "You are asked to “add comprehensive tests to this legacy codebase”. No test inventory exists and the dependency structure is unknown. Which decomposition strategy fits the work?",
    "o": [
      "Generate tests for every file in a single pass so no module is missed.",
      "Map the repository structure and entry points, identify high-impact areas, then build a prioritized plan that adapts as dependencies are discovered.",
      "Start with the alphabetically first twenty files and work through the list in order.",
      "Ask the model to produce a fixed 100-test plan before opening any source file."
    ],
    "a": [
      1
    ],
    "e": "Open-ended investigation needs adaptive decomposition: learn the structure, prioritize by impact, and revise as dependencies emerge. A fixed list or one giant pass ignores what is discovered and spreads effort evenly rather than where risk is highest."
  },
  {
    "id": "s1q15",
    "d": "D1",
    "t": "1.7",
    "type": "single",
    "q": "You return to a named investigation session two days later, but several files the agent analyzed have since changed. Prior tool results are partly stale. What is the most reliable approach?",
    "o": [
      "Start a new session with a structured summary of the prior findings and explicitly flag the changed files for targeted re-analysis.",
      "Resume the old session exactly as it was and ask the agent to “be careful” about outdated information.",
      "Fork the session and replay every original tool call against every file.",
      "Resume the old session and delete its tool-result messages without adding a summary."
    ],
    "a": [
      0
    ],
    "e": "Resuming is appropriate when context is mostly valid; when tool results are stale, a fresh session with an injected structured summary is more reliable. The summary preserves useful findings and the changed-file list focuses re-analysis. Blind resumption or deletion without replacement loses or trusts stale evidence."
  },
  {
    "id": "s1q16",
    "d": "D1",
    "t": "1.7",
    "type": "single",
    "q": "After a shared codebase analysis, you want to compare two refactoring strategies without one experiment contaminating the other. Which session mechanism fits?",
    "o": [
      "Spawn two subagents with identical prompts but no shared findings and compare their outputs.",
      "Use --resume twice in the same session, applying strategy A and then strategy B sequentially.",
      "Start two unrelated sessions with no baseline and ask each to rediscover the codebase.",
      "Use fork_session to create independent branches from the shared analysis baseline."
    ],
    "a": [
      3
    ],
    "e": "Forking preserves a common analysis baseline while isolating divergent exploration. Sequential work in one session lets the first strategy contaminate the second; unrelated sessions waste effort and lose the shared baseline; subagents do not inherit context automatically."
  },
  {
    "id": "s1q17",
    "d": "D2",
    "t": "2.1",
    "type": "single",
    "q": "Users say “check my order #12345”, but the agent often calls get_customer instead of lookup_order. Both tools have one-line descriptions and accept similar identifiers. What is the highest-leverage first fix?",
    "o": [
      "Build a keyword router that selects the tool before the model sees the request.",
      "Add eight few-shot examples that route order questions to lookup_order.",
      "Expand each description to state purpose, accepted inputs, example queries, edge cases and when to use it instead of the similar tool.",
      "Merge both tools into one lookup_entity tool that decides which backend to query."
    ],
    "a": [
      2
    ],
    "e": "Tool descriptions are the model's primary selection signal. Minimal descriptions cannot distinguish similar tools, so detailed boundaries fix the root cause cheaply. Examples add tokens without repairing descriptions; a router bypasses model understanding; consolidation is a larger design change, not the first step."
  },
  {
    "id": "s1q18",
    "d": "D2",
    "t": "2.1",
    "type": "single",
    "q": "One generic analyze_document tool is used for data extraction, summarization and claim verification. The agent routinely chooses it for tasks where its behavior is wrong. What change best improves selection and output contracts?",
    "o": [
      "Rename the tool to analyze_document_v2 and keep the existing description.",
      "Increase the number of few-shot examples that call analyze_document.",
      "Split it into extract_data_points, summarize_content and verify_claim_against_source, each with a defined contract.",
      "Add a system-prompt line telling the model to “pick the right mode” inside the generic tool."
    ],
    "a": [
      2
    ],
    "e": "Purpose-specific tools with explicit input/output contracts remove ambiguous mode selection. Renaming without changing semantics does not help; a single tool with internal modes hides intent; more examples for the same generic tool reinforce the ambiguity."
  },
  {
    "id": "s1q19",
    "d": "D2",
    "t": "2.2",
    "type": "single",
    "q": "A tool returns “Operation failed” for every problem. The agent retries a validation error repeatedly and eventually gives up. What error-response design best supports recovery?",
    "o": [
      "Escalate every tool error directly to a human without attempting recovery.",
      "Return a generic failure string but lower the agent's retry limit to one attempt.",
      "Return structured metadata: errorCategory (transient/validation/permission), isRetryable, and a human-readable description.",
      "Return an empty successful result so the agent can continue with other work."
    ],
    "a": [
      2
    ],
    "e": "The agent needs category and retryability to choose between retrying, correcting input, or escalating. Generic errors hide that decision. A lower limit avoids wasted retries but still cannot distinguish causes; empty success suppresses the failure; escalating everything removes useful autonomy."
  },
  {
    "id": "s1q20",
    "d": "D2",
    "t": "2.2",
    "type": "single",
    "q": "A search tool finds no matching documents and returns zero results. The agent treats this as an infrastructure failure and retries with the same query several times. What should the tool return?",
    "o": [
      "A transient error with isRetryable set to true so the agent keeps trying.",
      "A valid empty result explicitly labeled as a successful query with no matches.",
      "A fabricated best-match document so the workflow can continue.",
      "A generic “search unavailable” status to avoid exposing internal details."
    ],
    "a": [
      1
    ],
    "e": "Access failures and valid empty results are different outcomes. A successful no-match result tells the agent to change the query or report that nothing was found. Marking it transient invites pointless retries; generic errors hide the distinction; fabricating data is unsafe."
  },
  {
    "id": "s1q21",
    "d": "D2",
    "t": "2.2",
    "type": "single",
    "q": "A search subagent hits a timeout while researching one of five sources. The coordinator can still produce a useful report if it knows what happened. What should the subagent do?",
    "o": [
      "Raise an exception that terminates the entire research workflow.",
      "Return an empty result marked successful so the coordinator never sees a failure.",
      "Retry the same request indefinitely until the source responds.",
      "Attempt bounded local recovery for the transient failure, then propagate structured error context with partial results if recovery fails."
    ],
    "a": [
      3
    ],
    "e": "Local recovery keeps transient failures from burdening the coordinator, but unresolved errors should travel with failure type, attempted query, partial results and alternatives. Empty success hides a gap, infinite retries stall the workflow, and terminating everything discards recoverable work."
  },
  {
    "id": "s1q22",
    "d": "D2",
    "t": "2.3",
    "type": "single",
    "q": "Every subagent in a research system has access to all 18 tools, and tool misuse is rising: the synthesis agent runs web searches, while the report agent edits source documents. What change best addresses this?",
    "o": [
      "Restrict each subagent's tool set to its role, with narrow scoped tools for high-frequency cross-role needs.",
      "Add a classifier that predicts which of the 18 tools the agent should use before each turn.",
      "Keep the same tool set but rewrite every description in more detail.",
      "Set tool_choice to “any” so each agent must call some tool on every turn."
    ],
    "a": [
      0
    ],
    "e": "More tools increase decision complexity and invite out-of-role behavior. Least privilege gives each specialist only what it needs, optionally plus a constrained cross-role tool. Better descriptions help but do not remove irrelevant options; forcing any tool worsens misuse; a classifier adds complexity around the same over-provisioned set."
  },
  {
    "id": "s1q23",
    "d": "D2",
    "t": "2.3",
    "type": "single",
    "q": "An analysis agent round-trips through the coordinator for 80% of its needs, which are simple unit conversions; the other 20% require complex statistical validation. Round trips add latency. What is the most appropriate design?",
    "o": [
      "Precompute every possible conversion during the initial research phase.",
      "Have the agent batch all conversion and validation requests until the end of its pass.",
      "Give the analysis agent a scoped convert_units tool for the common case while complex validation still routes through the coordinator.",
      "Give the analysis agent every data tool so it never needs to ask the coordinator."
    ],
    "a": [
      2
    ],
    "e": "A constrained cross-role tool for a high-frequency, low-risk need preserves specialization while removing round trips. Granting all tools violates least privilege; batching creates blocking dependencies; speculative precomputation cannot predict every needed conversion."
  },
  {
    "id": "s1q24",
    "d": "D2",
    "t": "2.4",
    "type": "single",
    "q": "Your team wants a shared Jira MCP server available to everyone who clones the repository, authenticated with a personal token that must not enter version control. How should it be configured?",
    "o": [
      "In the project's .mcp.json using environment variable expansion such as ${JIRA_TOKEN}.",
      "In each developer's ~/.claude.json with the token hardcoded for convenience.",
      "In the root CLAUDE.md as a documented command that developers run manually.",
      "In a .env file committed beside .mcp.json so the expansion resolves for all users."
    ],
    "a": [
      0
    ],
    "e": "Project-scoped .mcp.json shares the server configuration through version control while ${JIRA_TOKEN} keeps the secret in each developer's environment. User scope is for personal servers; CLAUDE.md is instructions, not server configuration; committing a .env file leaks credentials."
  },
  {
    "id": "s1q25",
    "d": "D2",
    "t": "2.4",
    "type": "single",
    "q": "A documentation MCP server offers a capable search_docs tool, but the agent keeps using Grep over a vendored docs folder and misses semantic matches. What is the most direct improvement?",
    "o": [
      "Force search_docs with tool_choice on every turn.",
      "Add a system-prompt instruction that says “always prefer MCP tools”.",
      "Enhance the MCP tool description to explain its coverage, outputs and when it outperforms raw content search, and expose the documentation catalog as a resource.",
      "Remove Grep from the agent so the MCP tool is the only option."
    ],
    "a": [
      2
    ],
    "e": "The model needs to understand what the MCP tool knows and returns, and a resource catalog makes available content visible without exploratory calls. Removing built-ins is unnecessarily restrictive; forcing the tool ignores whether it fits each turn; a blanket preference does not explain the tool's value."
  },
  {
    "id": "s1q26",
    "d": "D2",
    "t": "2.5",
    "type": "single",
    "q": "You need to find every place in a large repository where the function refund_order is called, including calls through wrapper modules. Which built-in tool is the right starting point?",
    "o": [
      "Grep for the exported name and for each wrapper alias across file contents.",
      "Bash with a directory listing of each package.",
      "Glob with the pattern **/refund_order*",
      "Read every Python file from the repository root."
    ],
    "a": [
      0
    ],
    "e": "Grep searches file contents for symbols, call sites and error strings. Glob finds paths by name, which misses callers in arbitrary files; reading everything is wasteful; directory listings reveal nothing about usage. Wrapper tracing requires searching exported names and aliases."
  },
  {
    "id": "s1q27",
    "d": "D2",
    "t": "2.5",
    "type": "single",
    "q": "The Edit tool refuses a targeted change because the anchor text appears in three places in the file. You have already inspected the file and know the exact intended change. What is the reliable fallback?",
    "o": [
      "Re-run Edit with the same anchor and hope the correct occurrence is chosen.",
      "Use a shell search-and-replace without checking which occurrences changed.",
      "Delete the file and recreate it from memory.",
      "Read the full file, apply the change to the complete content, and Write the file back."
    ],
    "a": [
      3
    ],
    "e": "Edit relies on a unique match. When the anchor is non-unique, Read plus Write gives full control over the final content. Re-running cannot disambiguate; deleting risks data loss; an unchecked global replace can modify the wrong occurrences."
  },
  {
    "id": "s1q28",
    "d": "D3",
    "t": "3.1",
    "type": "single",
    "q": "A new teammate clones the repository but does not receive the team's coding instructions. The instructions currently live in your ~/.claude/CLAUDE.md. What is the correct fix?",
    "o": [
      "Move the shared instructions into the project-level CLAUDE.md and commit it.",
      "Run /memory on the teammate's machine and accept the defaults.",
      "Add the instructions to a personal skill in ~/.claude/skills/.",
      "Ask the teammate to copy your home-directory file into their own ~/.claude/CLAUDE.md."
    ],
    "a": [
      0
    ],
    "e": "User-level memory applies only to that user and is not shared through version control. Project-level CLAUDE.md is versioned with the repository and loads for everyone. Manual copying is fragile, personal skills are not shared, and /memory diagnoses loaded files rather than distributing them."
  },
  {
    "id": "s1q29",
    "d": "D3",
    "t": "3.1",
    "type": "single",
    "q": "A root CLAUDE.md has grown to 900 lines covering testing, API conventions, deployment and frontend rules. Developers say it is hard to maintain and often irrelevant. What organization is most appropriate?",
    "o": [
      "Split topics into .claude/rules/ files and use @import to pull only the relevant standards into each package.",
      "Convert the file into a custom slash command that developers invoke manually.",
      "Move everything into the user-level CLAUDE.md so it loads faster.",
      "Keep one file but add a table of contents at the top."
    ],
    "a": [
      0
    ],
    "e": "Modular rules keep each topic focused and import only what a package needs. A table of contents does not reduce context; user-level memory removes team sharing; a manually invoked command is not always-loaded project context."
  },
  {
    "id": "s1q30",
    "d": "D3",
    "t": "3.2",
    "type": "single",
    "q": "You want a /review slash command that runs the team's standard review checklist and is available to every developer after cloning the repo. Where should it live?",
    "o": [
      "In .claude/settings.json under a commands array.",
      "In ~/.claude/commands/ on each developer's machine.",
      "Inside the root CLAUDE.md as a bullet list.",
      "In .claude/commands/ inside the project repository."
    ],
    "a": [
      3
    ],
    "e": "Project-scoped custom commands in .claude/commands/ are version-controlled and shared automatically. The home-directory location is personal; CLAUDE.md holds context, not command definitions; there is no commands array in settings.json for this purpose."
  },
  {
    "id": "s1q31",
    "d": "D3",
    "t": "3.2",
    "type": "single",
    "q": "A codebase-analysis skill produces pages of exploration output that pollute the main conversation and crowd out later work. Which skill frontmatter option directly addresses this?",
    "o": [
      "argument-hint",
      "description with trigger keywords",
      "allowed-tools: Read",
      "context: fork"
    ],
    "a": [
      3
    ],
    "e": "context: fork runs the skill in an isolated sub-agent context so its verbose output does not accumulate in the main session. argument-hint prompts for arguments, allowed-tools restricts tools, and descriptions help invocation but do not isolate output."
  },
  {
    "id": "s1q32",
    "d": "D3",
    "t": "3.2",
    "type": "single",
    "q": "A release-notes skill must edit files but must never run shell commands. Which configuration best enforces that boundary?",
    "o": [
      "Set allowed-tools in SKILL.md frontmatter to the file-editing tools only.",
      "Add “do not use Bash” to the skill body.",
      "Use argument-hint to tell the developer which files to pass.",
      "Set context: fork and hope the isolated agent avoids Bash."
    ],
    "a": [
      0
    ],
    "e": "allowed-tools in skill frontmatter restricts the tools available during execution, which is a configuration boundary rather than a suggestion. Prose instructions are probabilistic; forking isolates context but does not limit tools; argument-hint only documents parameters."
  },
  {
    "id": "s1q33",
    "d": "D3",
    "t": "3.3",
    "type": "single",
    "q": "Test files are spread throughout the repository next to the code they test. All of them should receive the same testing conventions, regardless of directory. What is the most maintainable configuration?",
    "o": [
      "A separate CLAUDE.md in every directory that might contain a test.",
      "A testing skill that developers invoke manually before editing each test.",
      "A root CLAUDE.md section titled “Testing” that the model must infer applies.",
      "A .claude/rules/ file with paths: [\"**/*.test.tsx\"] and the testing conventions."
    ],
    "a": [
      3
    ],
    "e": "Path-scoped rules load automatically when matching files are edited and can target file types across directories. Directory CLAUDE.md files cannot cover spread-out tests cleanly; inference is unreliable; manual invocation is not automatic."
  },
  {
    "id": "s1q34",
    "d": "D3",
    "t": "3.3",
    "type": "single",
    "q": "You want Terraform conventions to load only when Claude is working with files under terraform/. What frontmatter should the rule file contain?",
    "o": [
      "alwaysApply: true",
      "description: Terraform conventions",
      "paths: [\"terraform/**/*\"]",
      "globs: terraform"
    ],
    "a": [
      2
    ],
    "e": "Path-specific rules use YAML frontmatter with a paths list of glob patterns. alwaysApply would load them everywhere; a bare directory name is not the documented glob form; a description alone does not scope activation."
  },
  {
    "id": "s1q35",
    "d": "D3",
    "t": "3.4",
    "type": "single",
    "q": "A team must migrate a shared library used by 45 files. There are two viable migration approaches with different infrastructure implications. Which working mode should Claude Code start in?",
    "o": [
      "Direct execution, changing files incrementally to discover the natural approach.",
      "Direct execution with a longer prompt that specifies every file edit upfront.",
      "A single Bash command that rewrites all imports at once.",
      "Plan mode, to explore dependencies and design the approach before committing changes."
    ],
    "a": [
      3
    ],
    "e": "Plan mode is for large-scale, multi-file work with architectural choices and costly rework risk. It supports exploration and design before edits. Incremental direct execution risks discovering dependencies too late; an upfront prompt assumes knowledge; a bulk rewrite is not a migration plan."
  },
  {
    "id": "s1q36",
    "d": "D3",
    "t": "3.4",
    "type": "single",
    "q": "A stack trace points to one function in one file, and the fix is a missing null check. Which execution approach is appropriate?",
    "o": [
      "Plan mode, because every code change should be planned.",
      "Fork the session and compare three fix strategies before editing.",
      "Direct execution of the well-scoped change.",
      "A research subagent followed by a full architecture review."
    ],
    "a": [
      2
    ],
    "e": "Direct execution fits simple, well-understood changes with a clear scope. Plan mode adds overhead when the location and fix are already known; architecture review and multi-branch exploration are disproportionate to a one-line bug fix."
  },
  {
    "id": "s1q37",
    "d": "D3",
    "t": "3.5",
    "type": "single",
    "q": "A data transformation prompt produces inconsistent results: the prose says “normalize phone numbers”, but the model keeps inventing different formats. What is the most effective way to clarify the requirement?",
    "o": [
      "Ask the model to explain its interpretation before every run.",
      "Provide two or three concrete input/output examples that demonstrate the exact transformation.",
      "Repeat the instruction in uppercase and add “this is very important”.",
      "Raise the temperature so the model explores more formatting options."
    ],
    "a": [
      1
    ],
    "e": "Concrete examples communicate transformations more reliably than prose because they resolve ambiguity about edge cases and output shape. Emphasis does not add information; higher temperature increases variance; explanations add cost without pinning the expected output."
  },
  {
    "id": "s1q38",
    "d": "D3",
    "t": "3.5",
    "type": "single",
    "q": "A legacy migration script handles nulls incorrectly in several edge cases. You want progressive, verifiable improvement rather than repeated guessing. Which approach fits best?",
    "o": [
      "Lower the temperature and rerun the same prompt until the output looks better.",
      "List every edge case in one prompt and request a single final version.",
      "Ask for a complete rewrite with no tests, then inspect the diff manually.",
      "Write a test suite covering expected behavior and edge cases, then iterate by sharing specific test failures."
    ],
    "a": [
      3
    ],
    "e": "Tests make the desired behavior executable and give the model precise failure feedback for each iteration. A rewrite without tests provides no signal; a one-shot prompt hides unresolved cases; rerunning with lower temperature does not supply missing requirements."
  },
  {
    "id": "s1q39",
    "d": "D3",
    "t": "3.6",
    "type": "single",
    "q": "A CI job runs `claude \"Analyze this pull request for security issues\"` and hangs indefinitely waiting for input. What is the correct fix?",
    "o": [
      "Set CLAUDE_HEADLESS=true before invoking the command.",
      "Add a --batch flag to put Claude Code into pipeline mode.",
      "Use the -p (or --print) flag to run Claude Code non-interactively.",
      "Redirect stdin from /dev/null and keep the same command."
    ],
    "a": [
      2
    ],
    "e": "The -p/--print flag is the documented non-interactive mode: it processes the prompt, writes the result, and exits without waiting for user input. The environment variable and --batch flag are not the documented mechanism; redirecting stdin is a workaround, not proper CLI usage."
  },
  {
    "id": "s1q40",
    "d": "D4",
    "t": "4.1",
    "type": "single",
    "q": "An automated reviewer flags many minor style preferences and comments on unchanged lines. Developers are starting to ignore all of its findings, including real bugs. What change best restores precision?",
    "o": [
      "Define explicit categorical criteria for what to report and what to skip, with concrete severity examples.",
      "Reduce the number of files reviewed per pull request.",
      "Add “be conservative and only report high-confidence findings” to the prompt.",
      "Lower the model temperature to make the review more deterministic."
    ],
    "a": [
      0
    ],
    "e": "Precision improves when the prompt defines categories to report and skip, rather than relying on vague confidence language. Reviewing fewer files may hide bugs; “be conservative” is explicitly noted as ineffective; determinism does not improve relevance."
  },
  {
    "id": "s1q41",
    "d": "D4",
    "t": "4.1",
    "type": "multi",
    "n": 2,
    "q": "One review category produces many false positives and is damaging trust in the reviewer's accurate categories. Which two actions are most appropriate? (Select two.)",
    "o": [
      "Define concrete, categorical criteria and examples for what should and should not be reported.",
      "Add “only report high-confidence findings” to every prompt.",
      "Temporarily disable that high-false-positive category while its prompt is improved.",
      "Ask developers to mentally discount findings from that category."
    ],
    "a": [
      0,
      2
    ],
    "e": "Removing a noisy category protects trust while targeted criteria and examples address its precision. Expecting developers to discount findings does not fix the system; confidence-based filtering is explicitly weaker than categorical criteria."
  },
  {
    "id": "s1q42",
    "d": "D4",
    "t": "4.2",
    "type": "single",
    "q": "Reviewers classify similar defects as “minor” in one file and “critical” in another. Detailed instructions have not produced consistency. What is the most effective next step?",
    "o": [
      "Provide two to four few-shot examples for each severity level, including the reasoning for the classification.",
      "Increase the size of the review prompt with more adjectives about importance.",
      "Remove severity labels and let developers decide.",
      "Ask the model to sort findings alphabetically before assigning severity."
    ],
    "a": [
      0
    ],
    "e": "Few-shot examples anchor judgment and demonstrate how to generalize ambiguous cases to new code. Alphabetical ordering and stronger adjectives add no decision rule; removing severity shifts the problem to developers."
  },
  {
    "id": "s1q43",
    "d": "D4",
    "t": "4.2",
    "type": "single",
    "q": "An invoice extractor works on standard invoices but returns empty values for documents with inline citations, tables or informal measurements. What intervention is most likely to improve consistency?",
    "o": [
      "Add few-shot examples showing correct extraction from each of the varied document layouts, including null handling.",
      "Make every schema field required so the model must return something.",
      "Switch to a model with a larger context window.",
      "Retry the same extraction until the fields are populated."
    ],
    "a": [
      0
    ],
    "e": "Few-shot examples demonstrate how to handle structural variety and reduce hallucination or empty extraction. Requiring fields encourages fabrication; blind retries cannot create information the model does not know how to locate; a larger window does not teach layout handling."
  },
  {
    "id": "s1q44",
    "d": "D4",
    "t": "4.3",
    "type": "single",
    "q": "A downstream service requires syntactically valid JSON that matches an exact schema. Which approach most reliably guarantees compliance?",
    "o": [
      "Instruct the model to “respond only with JSON” and validate afterward.",
      "Use a low temperature and a detailed prose description of the schema.",
      "Define an extraction tool whose input schema is the JSON schema, then read the structured tool_use input.",
      "Ask for JSON inside a Markdown code fence and strip the fence."
    ],
    "a": [
      2
    ],
    "e": "Tool use with a JSON schema constrains output structure at generation time and eliminates JSON syntax errors. Prompt-only JSON, fenced blocks and low temperature remain probabilistic and still require parsing and repair; they do not guarantee the schema."
  },
  {
    "id": "s1q45",
    "d": "D4",
    "t": "4.3",
    "type": "single",
    "q": "A pipeline receives several document types and has one extraction schema per type, but the type is unknown until the document is read. You need guaranteed structured output without knowing which schema applies. Which tool_choice setting fits?",
    "o": [
      "No tool_choice, because schemas are only advisory.",
      "\"auto\" so the model can answer in prose when it is unsure.",
      "A forced selection of the most common extraction tool.",
      "\"any\" so the model must call one of the extraction tools but may choose which."
    ],
    "a": [
      3
    ],
    "e": "tool_choice “any” requires a tool call while letting the model select the appropriate schema after reading the document. “auto” permits a text response and breaks the guarantee; forcing the most common tool misclassifies rare types; omitting tool_choice provides no enforcement."
  },
  {
    "id": "s1q46",
    "d": "D4",
    "t": "4.4",
    "type": "single",
    "q": "A structured extraction passes schema validation but fails business validation because line items do not sum to the stated total. What retry design is most likely to correct this?",
    "o": [
      "Resend the document with no explanation and ask for a better extraction.",
      "Send the original document, the failed extraction, and the specific validation error so the model can self-correct.",
      "Increase the retry count until the totals happen to match.",
      "Drop the validation rule and accept the output as-is."
    ],
    "a": [
      1
    ],
    "e": "Retry-with-error-feedback gives the model the evidence and the precise discrepancy to correct. A blind retry lacks signal, repeated guessing is wasteful, and ignoring the rule pushes bad data downstream."
  },
  {
    "id": "s1q47",
    "d": "D4",
    "t": "4.4",
    "type": "single",
    "q": "An extractor keeps retrying a required field that is genuinely absent because the value exists only in a separate appendix that was never provided. What is the correct interpretation?",
    "o": [
      "Retries cannot recover information that is absent from the source; provide the appendix or mark the field unavailable.",
      "The retry limit should be increased because persistence usually works.",
      "The schema should make the field required so the model tries harder.",
      "A higher temperature will help the model infer the missing value."
    ],
    "a": [
      0
    ],
    "e": "Retries fix format and structural errors, not missing evidence. The system should supply the external document or return an explicit unavailable value. Requiring the field encourages fabrication; temperature and more retries cannot create source data."
  },
  {
    "id": "s1q48",
    "d": "D4",
    "t": "4.5",
    "type": "single",
    "q": "A team wants to cut API cost by moving two workflows to the Message Batches API: a blocking pre-merge security check and an overnight technical-debt report. How should they proceed?",
    "o": [
      "Keep both synchronous because batch results cannot be correlated to requests.",
      "Use batch processing for the overnight report only; keep synchronous calls for the pre-merge check.",
      "Move both to batch processing and rely on batches usually finishing quickly.",
      "Move both to batch processing with a real-time fallback after five minutes."
    ],
    "a": [
      1
    ],
    "e": "Batches offer 50% savings but can take up to 24 hours with no latency SLA, so they fit latency-tolerant overnight work, not blocking checks. custom_id correlates batch requests. A fallback adds complexity when the correct fix is matching each workflow to its latency requirement."
  },
  {
    "id": "s1q49",
    "d": "D4",
    "t": "4.5",
    "type": "single",
    "q": "A nightly batch of 5,000 documents completes with 120 failures, mostly oversized files and a few malformed requests. What is the most efficient recovery?",
    "o": [
      "Resubmit the entire 5,000-document batch unchanged.",
      "Use custom_id to identify the failed requests, chunk oversized documents, and resubmit only the failures.",
      "Ignore the failures because 97.6% of the batch succeeded.",
      "Abandon the batch and process all 5,000 documents synchronously."
    ],
    "a": [
      1
    ],
    "e": "custom_id maps responses back to inputs, enabling targeted recovery. Only failures need modification and resubmission, which minimizes cost and time. Resubmitting everything repeats successful work; switching all to synchronous calls is expensive; ignoring failures leaves gaps."
  },
  {
    "id": "s1q50",
    "d": "D4",
    "t": "4.6",
    "type": "single",
    "q": "A model generates a patch and then reviews it in the same session. It consistently misses a subtle authorization bug in its own change. What is the most effective review change?",
    "o": [
      "Ask the same session to review the patch three times with extended thinking.",
      "Send the patch to an independent Claude instance that did not produce the code or its reasoning context.",
      "Increase the model's temperature during self-review to encourage skepticism.",
      "Instruct the generator to review more carefully and double-check its reasoning."
    ],
    "a": [
      1
    ],
    "e": "Self-review retains the generator's reasoning and commitments, making it less likely to question its own decisions. An independent instance sees only the artifact and can catch issues the generator rationalized away. Stronger instructions, repeated self-review or higher temperature do not remove that anchor."
  },
  {
    "id": "s1q51",
    "d": "D4",
    "t": "4.6",
    "type": "single",
    "q": "A high-stakes review produces findings but limited reviewer capacity. You want to route only uncertain findings to humans. Which architecture is most appropriate?",
    "o": [
      "Run the same review three times and send only unanimous findings to humans.",
      "Ask developers to review every finding because model confidence is never useful.",
      "Have the generating model label each finding as certain or uncertain.",
      "Run a separate verification pass that reports per-finding confidence and evidence, then route low-confidence findings to humans."
    ],
    "a": [
      3
    ],
    "e": "A verification pass that reports calibrated confidence alongside evidence supports targeted routing. The generator's own certainty is poorly calibrated; consensus among repeated runs does not measure correctness; reviewing everything ignores the capacity constraint."
  },
  {
    "id": "s1q52",
    "d": "D5",
    "t": "5.1",
    "type": "single",
    "q": "A long support conversation is repeatedly summarized. The agent eventually forgets the refund amount, order number and the customer's stated deadline, even though the prose summary sounds coherent. What is the best mitigation?",
    "o": [
      "Delete older turns so the model focuses on the latest message.",
      "Maintain a persistent case-facts block with amounts, dates, order IDs and statuses outside the summarized history.",
      "Increase the model temperature so it reconstructs missing facts.",
      "Rely on progressive summarization but ask it to preserve “important details”."
    ],
    "a": [
      1
    ],
    "e": "Summaries tend to blur exact values and expectations. A structured facts block preserves transactional details across turns and can be injected into every prompt. Vaguer summarization instructions are unreliable; temperature cannot recover facts; deleting history loses context."
  },
  {
    "id": "s1q53",
    "d": "D5",
    "t": "5.1",
    "type": "single",
    "q": "An order-lookup tool returns 40 fields, but the returns workflow only needs five. Across a long session these results consume most of the context window. What should you do?",
    "o": [
      "Stop appending tool results and let the model remember the previous response.",
      "Switch to a model with a larger context window and keep every field.",
      "Trim each tool result to the relevant fields before appending it to conversation context.",
      "Ask the model to summarize each result after it has already been appended."
    ],
    "a": [
      2
    ],
    "e": "Tool output should be reduced at the boundary where relevance is known. Trimming before accumulation prevents waste. Summarizing after appending still pays the token cost; omitting results breaks reasoning; a bigger window postpones rather than fixes context bloat."
  },
  {
    "id": "s1q54",
    "d": "D5",
    "t": "5.2",
    "type": "multi",
    "n": 2,
    "q": "Which two situations are appropriate triggers to escalate a customer-support case? (Select two.)",
    "o": [
      "The customer explicitly asks to speak with a human.",
      "The request requires a policy exception, or the policy is silent on the request.",
      "The agent's self-reported confidence score is below 6 out of 10.",
      "The customer's message contains strongly negative sentiment."
    ],
    "a": [
      0,
      1
    ],
    "e": "Explicit requests and genuine policy gaps or ambiguity are sound escalation triggers. Sentiment does not correlate with case complexity, and self-reported confidence is poorly calibrated; both are explicitly unreliable proxies."
  },
  {
    "id": "s1q55",
    "d": "D5",
    "t": "5.2",
    "type": "single",
    "q": "get_customer returns three plausible matches for a common name. The agent is about to choose the most recently active account and process a refund. What should it do instead?",
    "o": [
      "Merge the three accounts so the refund reaches the right one.",
      "Ask the customer for an additional identifier and resolve the ambiguity before proceeding.",
      "Select the account with the highest lifetime value because that is usually the right customer.",
      "Use the customer's geolocation to eliminate two of the matches."
    ],
    "a": [
      1
    ],
    "e": "Multiple matches require clarification, not a heuristic guess. Recency, value, geolocation and account merging all risk acting on the wrong person or corrupting records. The agent should pause the financial action until identity is unambiguous."
  },
  {
    "id": "s1q56",
    "d": "D5",
    "t": "5.3",
    "type": "single",
    "q": "A subagent times out and returns only “search unavailable” to the coordinator. The coordinator cannot decide whether to retry, switch sources or proceed with partial data. What is the root cause?",
    "o": [
      "The workflow needs a larger context window to hold the failed request.",
      "The coordinator does not have enough tools to perform the search itself.",
      "The error lacks structured context such as failure type, attempted query, partial results and alternatives.",
      "The subagent should have suppressed the error and returned an empty list."
    ],
    "a": [
      2
    ],
    "e": "Recovery decisions require actionable error context. A generic status hides what happened and prevents informed retry or fallback. More coordinator tools, suppressed errors or a larger window do not supply the missing diagnostic information."
  },
  {
    "id": "s1q57",
    "d": "D5",
    "t": "5.3",
    "type": "single",
    "q": "One source in a multi-source research run is unavailable, but the other sources support a useful report. How should the final synthesis represent this?",
    "o": [
      "Omit any mention of the unavailable source so the report appears complete.",
      "Fill the gap with the model's general knowledge and label it as analysis.",
      "Terminate the workflow because a complete report is impossible.",
      "Include coverage annotations identifying which findings are well-supported and which topic areas have gaps."
    ],
    "a": [
      3
    ],
    "e": "Coverage annotations preserve transparency and let readers judge confidence. Hiding the gap misrepresents completeness; substituting unsourced general knowledge undermines provenance; terminating discards valid partial results."
  },
  {
    "id": "s1q58",
    "d": "D5",
    "t": "5.4",
    "type": "single",
    "q": "After a long codebase exploration, the agent starts saying “this follows the typical pattern” instead of naming the classes it discovered earlier. Which intervention best counters this degradation?",
    "o": [
      "Have the agent maintain a scratchpad of key findings and consult it for later questions.",
      "Start a new session with no summary and re-read every file.",
      "Raise the temperature so the agent generates more specific language.",
      "Ask the agent to keep the entire repository in its context window."
    ],
    "a": [
      0
    ],
    "e": "A scratchpad externalizes verified findings across context boundaries and gives later turns a source of specific facts. Restarting without memory loses work; temperature does not restore recall; keeping everything in context is exactly what is degrading."
  },
  {
    "id": "s1q59",
    "d": "D5",
    "t": "5.5",
    "type": "single",
    "q": "An extraction pipeline reports 97% aggregate accuracy. The team wants to reduce human review from 20% to 5%. What should they do first?",
    "o": [
      "Remove review entirely for the most common document type.",
      "Trust the aggregate metric and reduce review immediately.",
      "Measure accuracy by document type and field, and run stratified sampling on high-confidence extractions before changing the threshold.",
      "Review only documents the model marks as low confidence."
    ],
    "a": [
      2
    ],
    "e": "Aggregate accuracy can hide weak segments. Segment-level accuracy and stratified sampling of supposedly high-confidence output reveal novel error patterns before review capacity is reduced. Low-confidence routing alone can miss confident errors; removing review by type ignores segment risk."
  },
  {
    "id": "s1q60",
    "d": "D5",
    "t": "5.6",
    "type": "single",
    "q": "Two credible sources report different market-growth figures for the same year. The synthesis agent must combine them into one report. What is the correct handling?",
    "o": [
      "Select the newer-looking figure and omit the other to keep the report consistent.",
      "Average the two figures and present the result as a single fact.",
      "Exclude both findings because conflicting sources are unusable.",
      "Preserve both values with source attribution and annotate the conflict, distinguishing well-established findings from contested ones."
    ],
    "a": [
      3
    ],
    "e": "Synthesis must preserve claim-source mappings and surface conflicts rather than silently choosing or averaging. Attribution lets the coordinator or reader reconcile the difference. Omitting or excluding data loses information; averaging invents a statistic."
  }
];
