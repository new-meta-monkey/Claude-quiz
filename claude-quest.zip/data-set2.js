window.SET2_QUESTIONS = [
  {
    "id": "s2q01",
    "d": "D1",
    "t": "1.1",
    "type": "single",
    "q": "An agent loop executes a tool but appends the result as ordinary assistant text. On the next iteration the model calls the same tool again with identical arguments. What is the correct fix?",
    "o": [
      "Convert the tool into an MCP server so its results are cached.",
      "Raise the iteration cap so the agent has more chances to finish.",
      "Append the tool output as a tool_result block tied to the tool_use ID, then continue the loop.",
      "Add a system-prompt instruction telling the model not to repeat tool calls."
    ],
    "a": [
      2
    ],
    "e": "The model needs a properly linked tool_result containing the tool_use ID to incorporate the result. Text that merely mentions the output does not close the tool-use turn, so the model repeats its request. Prompting, iteration caps and MCP caching do not repair the message structure."
  },
  {
    "id": "s2q02",
    "d": "D1",
    "t": "1.1",
    "type": "single",
    "q": "A complex invoice workflow sometimes stops after 12 tool calls because the loop breaks on a hard-coded iteration cap. Most runs finish in 5–7 calls. What is the best control-flow change?",
    "o": [
      "Increase the cap to 30 and keep it as the primary termination mechanism.",
      "Remove the cap entirely and rely on the model to stop eventually.",
      "Check whether the assistant's last message contains “done” and break when it does.",
      "Terminate based on stop_reason, using a generous safety cap only as a last-resort guard against runaway loops."
    ],
    "a": [
      3
    ],
    "e": "The semantic stop signal is stop_reason (“end_turn”), not an arbitrary count. A high safety cap can exist as a guard, but it must not be the primary stopping rule. Removing all bounds risks runaway loops, and keyword checks are explicitly fragile anti-patterns."
  },
  {
    "id": "s2q03",
    "d": "D1",
    "t": "1.2",
    "type": "single",
    "q": "A coordinator sends a short instruction to the synthesis subagent: “Use the research from the other agents.” The synthesis output is generic and omits most findings. Why?",
    "o": [
      "The synthesis model is too small to understand the instruction.",
      "The synthesis agent needs access to all search tools to reconstruct the findings.",
      "Subagents have isolated context and do not inherit the coordinator's conversation or other agents' outputs automatically.",
      "The coordinator should have used an MCP resource instead of a subagent."
    ],
    "a": [
      2
    ],
    "e": "Subagents start with isolated context; the coordinator must explicitly include the complete findings and metadata in the synthesis prompt. Model size is not the stated issue, MCP resources are a different mechanism, and re-searching is wasteful when findings already exist."
  },
  {
    "id": "s2q04",
    "d": "D1",
    "t": "1.2",
    "type": "single",
    "q": "The coordinator evaluates a synthesis report and finds that two important subtopics are thinly supported. What should the coordinator do next?",
    "o": [
      "Accept the report because all subagents completed successfully.",
      "Ask the synthesis agent to “try harder” with the same findings.",
      "Restart the entire pipeline from the original broad query.",
      "Re-delegate targeted queries to the search and analysis agents, then re-invoke synthesis with the new evidence."
    ],
    "a": [
      3
    ],
    "e": "The coordinator owns iterative refinement: evaluate coverage, identify gaps, re-delegate targeted work, and re-synthesize. Accepting the report leaves gaps; repeating synthesis without new evidence cannot improve coverage; a full restart wastes valid work."
  },
  {
    "id": "s2q05",
    "d": "D1",
    "t": "1.3",
    "type": "single",
    "q": "A coordinator is configured with tools for search, analysis and reporting, but every attempt to spawn a subagent fails. The coordinator's allowedTools list does not include “Task”. What is the fix?",
    "o": [
      "Give the coordinator the subagents' system prompts directly.",
      "Add “Task” to the coordinator's allowedTools so it can spawn subagents.",
      "Enable shared memory between the coordinator and subagents.",
      "Convert each subagent into a built-in Bash command."
    ],
    "a": [
      1
    ],
    "e": "The Task tool is the mechanism for spawning subagents, and it must be allowed for the coordinator. System prompts alone do not create invocations; shell commands and shared memory are unrelated to the missing capability."
  },
  {
    "id": "s2q06",
    "d": "D1",
    "t": "1.3",
    "type": "multi",
    "n": 2,
    "q": "A search subagent begins editing repository files even though its role is only to find sources. The coordinator passes one general system prompt to every subagent. Which two changes in the subagent's AgentDefinition best enforce its role? (Select two.)",
    "o": [
      "A restricted tool set that excludes file-editing tools.",
      "A role-specific system prompt that states the search-only responsibility.",
      "A larger context window so the agent understands its role.",
      "A shared conversation history inherited from the coordinator."
    ],
    "a": [
      0,
      1
    ],
    "e": "AgentDefinition carries a description, system prompt and tool restrictions. A role prompt plus restricted tools enforces behavior rather than relying on a global instruction. Shared history is not automatic, and a larger window does not restrict what the agent can do."
  },
  {
    "id": "s2q07",
    "d": "D1",
    "t": "1.3",
    "type": "single",
    "q": "A coordinator passes only the latest search result to the synthesis agent. Sources found by earlier subagent runs disappear from the final citations. What should the coordinator pass?",
    "o": [
      "A link to the coordinator's conversation history so synthesis can look up earlier turns.",
      "A request for synthesis to search the web again for any missing citations.",
      "Only the final answer from each subagent, with URLs removed to reduce tokens.",
      "The complete structured findings from all prior agents, including content and source metadata."
    ],
    "a": [
      3
    ],
    "e": "Synthesis needs all relevant findings, not just the latest, and attribution metadata must travel with them. Subagents cannot inspect the coordinator's history; re-searching duplicates work; stripping URLs destroys provenance."
  },
  {
    "id": "s2q08",
    "d": "D1",
    "t": "1.4",
    "type": "single",
    "q": "A lending workflow must run a sanctions screening before an application can be approved. The agent occasionally approves first and screens afterward. The business requires guaranteed ordering. What should be implemented?",
    "o": [
      "A programmatic prerequisite that blocks the approval tool until a successful screening record exists.",
      "A system prompt that lists the required steps in capital letters.",
      "A dashboard that alerts managers when the order is wrong.",
      "A few-shot example showing the correct order in three applications."
    ],
    "a": [
      0
    ],
    "e": "Guaranteed ordering for a regulated step requires deterministic enforcement. A gate tied to a screening record prevents approval regardless of model behavior. Prompting and examples are probabilistic; after-the-fact alerts do not prevent the violation."
  },
  {
    "id": "s2q09",
    "d": "D1",
    "t": "1.4",
    "type": "single",
    "q": "A customer changes their delivery address while a replacement is already in progress. The agent restarts the entire case, re-verifies identity and re-opens the replacement, creating a duplicate shipment. What handoff/workflow design would prevent this?",
    "o": [
      "Increase the model's context window so it remembers the first request.",
      "Escalate every address change to a human because workflow state is too complex.",
      "Ask the customer to close the first case and open a new one.",
      "Carry forward completed steps and pass a structured case state with what is done, what is pending and the relevant IDs."
    ],
    "a": [
      3
    ],
    "e": "Multi-step workflows need explicit state so completed steps are not repeated. A structured case state preserves progress and pending actions across the change. Escalating everything is disproportionate; forcing a new case loses continuity; a bigger window does not guarantee state tracking."
  },
  {
    "id": "s2q10",
    "d": "D1",
    "t": "1.5",
    "type": "single",
    "q": "Tool results sometimes contain full customer email addresses and card fragments. Policy requires that the model never see the raw values. Where should redaction occur?",
    "o": [
      "In a downstream report filter after the model has produced an answer.",
      "In a PostToolUse hook that redacts the fields before the result enters model context.",
      "In the system prompt, instructing the model to ignore sensitive fields.",
      "In the user-facing UI, replacing sensitive strings before display."
    ],
    "a": [
      1
    ],
    "e": "A PostToolUse hook can transform tool output before the model processes it, which is the deterministic control point for preventing exposure. Prompt instructions do not guarantee redaction; downstream filters act too late; UI masking does not stop the model from seeing the data."
  },
  {
    "id": "s2q11",
    "d": "D1",
    "t": "1.5",
    "type": "single",
    "q": "A browsing tool must never fetch domains outside an approved allowlist. The agent has occasionally ignored prompt instructions and fetched unapproved URLs. What control is appropriate?",
    "o": [
      "A monitoring alert that notifies security after an unapproved fetch.",
      "A tool-call interception hook that rejects any URL not on the allowlist before execution.",
      "A prompt that says “only use approved domains” and lists examples.",
      "A post-processing step that removes unapproved URLs from the final answer."
    ],
    "a": [
      1
    ],
    "e": "Blocking at the tool boundary prevents the unsafe action itself. Prompt guidance is probabilistic; removing URLs after the fetch still exposes the system; alerting detects but does not enforce the policy."
  },
  {
    "id": "s2q12",
    "d": "D1",
    "t": "1.6",
    "type": "single",
    "q": "A test-generation workflow always follows the same stages: inventory modules, generate unit tests per module, then generate integration tests. The stages and their order are predictable. Which decomposition pattern fits?",
    "o": [
      "Fully dynamic decomposition where each run discovers a new stage order.",
      "A coordinator that randomly selects one specialist per run.",
      "A single prompt asking for every test at once with no staging.",
      "Prompt chaining with fixed sequential stages, passing each stage's output forward."
    ],
    "a": [
      3
    ],
    "e": "Predictable multi-stage work benefits from prompt chaining: each stage has a clear input and output and feeds the next. Dynamic decomposition is for open-ended discovery; one giant prompt dilutes attention; random specialist selection abandons the known process."
  },
  {
    "id": "s2q13",
    "d": "D1",
    "t": "1.6",
    "type": "single",
    "q": "You must diagnose a production incident in an unfamiliar service. The next investigation step depends on what the logs and dependency graph reveal. Which approach is most appropriate?",
    "o": [
      "Ask the model to produce the final root cause from the incident title alone.",
      "Read every source file in the repository before forming any hypothesis.",
      "An adaptive investigation plan that generates subtasks based on each intermediate finding.",
      "A fixed five-step checklist chosen before looking at any evidence."
    ],
    "a": [
      2
    ],
    "e": "Open-ended investigation benefits from adaptive decomposition: evidence determines the next question. A pre-set checklist may miss the actual failure path; reading everything is wasteful; answering from the title is not investigation."
  },
  {
    "id": "s2q14",
    "d": "D1",
    "t": "1.6",
    "type": "single",
    "q": "A security audit covers 60 microservices. Reviewers need both service-local issues and vulnerabilities that cross trust boundaries. How should the work be split?",
    "o": [
      "A per-service local analysis pass, followed by a separate cross-service integration pass focused on trust boundaries and data flow.",
      "Randomly assign each service to one of three reviewers and merge the prose.",
      "Only per-service passes, because cross-service analysis is impossible.",
      "One pass over all services so the model sees the whole system at once."
    ],
    "a": [
      0
    ],
    "e": "Local and cross-cutting concerns need different scopes. Per-service passes preserve depth; a dedicated integration pass examines flows that no single service review can see. One giant pass dilutes attention, per-service only misses integration risks, and random prose merging is not analysis."
  },
  {
    "id": "s2q15",
    "d": "D1",
    "t": "1.7",
    "type": "single",
    "q": "You want to continue a named investigation tomorrow without losing its prior conclusions. Which command behavior fits?",
    "o": [
      "Use --resume with the named session to continue that specific prior conversation.",
      "Use fork_session and discard the original branch immediately.",
      "Start an unrelated session and paste the old final answer only.",
      "Create a new subagent and assume it inherits the old session's memory."
    ],
    "a": [
      0
    ],
    "e": "Named session resumption continues the intended conversation with its context intact. Pasting only the final answer loses evidence and reasoning; forking is for divergent branches; subagents do not automatically inherit parent or prior session context."
  },
  {
    "id": "s2q16",
    "d": "D1",
    "t": "1.7",
    "type": "single",
    "q": "After a shared analysis baseline, you want to explore two competing database migration plans independently, then compare them. Which approach preserves the baseline while preventing cross-contamination?",
    "o": [
      "Start two new sessions with no baseline and ask each to rediscover the schema.",
      "Run both plans in the same context and ask the model to keep them separate.",
      "Run plan A to completion, then ask the same session to undo it and run plan B.",
      "Use fork_session twice from the baseline so each branch explores one plan independently."
    ],
    "a": [
      3
    ],
    "e": "Forking creates independent branches from a common baseline, which is ideal for comparing alternatives. Sequential undo contaminates the context and may leave artifacts; rediscovery loses the baseline; asking one context to segregate two plans invites confusion."
  },
  {
    "id": "s2q17",
    "d": "D2",
    "t": "2.1",
    "type": "single",
    "q": "The system prompt contains “Always analyze content before responding.” The agent now calls analyze_content even for order-status questions that need lookup_order. Both tools have clear descriptions. What is the best diagnosis and fix?",
    "o": [
      "A keyword-sensitive system-prompt instruction is overriding the tool descriptions; remove or rewrite the instruction.",
      "Merge both tools into analyze_content so the instruction is always correct.",
      "The lookup_order description is still too short; expand it further.",
      "The model needs a higher temperature to explore other tools."
    ],
    "a": [
      0
    ],
    "e": "System-prompt wording can create unintended tool associations that overpower otherwise good descriptions. The instruction is the root cause, so it should be removed or scoped. Expanding an already-clear description, changing temperature, or merging tools does not address the override."
  },
  {
    "id": "s2q18",
    "d": "D2",
    "t": "2.1",
    "type": "single",
    "q": "An extract_metadata tool description says only “Extracts metadata.” The agent often omits the `currency` and `effective_date` outputs, then downstream code fails. What description change is most useful?",
    "o": [
      "Add a second tool with the same description and let the model choose.",
      "Rename the tool to extract_all_metadata.",
      "List the exact output fields, their formats, example inputs and boundary cases where fields may be absent.",
      "Add the phrase “be thorough” to the end of the description."
    ],
    "a": [
      2
    ],
    "e": "The description is the model's contract for when and how to use a tool. Documenting outputs, formats, examples and absent-field behavior makes the contract usable. “Be thorough” adds no information; renaming does not define outputs; a duplicate tool worsens ambiguity."
  },
  {
    "id": "s2q19",
    "d": "D2",
    "t": "2.2",
    "type": "multi",
    "n": 2,
    "q": "A refund tool rejects a request because the order is outside the 30-day policy. The agent retries four times, then invents an exception. Which two response elements best guide the agent? (Select two.)",
    "o": [
      "A raw stack trace with no policy context.",
      "A transient error flag so the agent retries with the same input.",
      "A customer-friendly policy explanation that the agent can relay.",
      "errorCategory set to a business error and isRetryable set to false."
    ],
    "a": [
      2,
      3
    ],
    "e": "A policy rejection is a non-retryable business error, and a plain-language explanation lets the agent communicate the outcome. Retrying cannot change policy, and a stack trace does not tell the agent what to say or do next."
  },
  {
    "id": "s2q20",
    "d": "D2",
    "t": "2.2",
    "type": "single",
    "q": "An MCP tool returns a permission error because the service account lacks access to a billing table. Which metadata best guides the agent?",
    "o": [
      "errorCategory: transient, isRetryable: true, with a request to retry immediately.",
      "A generic error string with no category so the agent stays flexible.",
      "errorCategory: permission, isRetryable: false, with the missing scope and an escalation path.",
      "An empty successful result with a note to try a different question."
    ],
    "a": [
      2
    ],
    "e": "A permission error needs a non-retryable classification plus the missing access and an escalation route. Retrying without new credentials cannot succeed; generic errors hide the cause; empty success misrepresents an access failure as a valid no-match."
  },
  {
    "id": "s2q21",
    "d": "D2",
    "t": "2.3",
    "type": "single",
    "q": "An extraction pipeline must always capture document metadata before any enrichment tool runs, but the model sometimes begins with enrichment. How can the first step be guaranteed?",
    "o": [
      "Set tool_choice to a forced selection of extract_metadata on the first turn, then continue processing in follow-up turns.",
      "Give the enrichment tool a longer description that mentions metadata.",
      "Set tool_choice to “auto” and mention metadata first in the prompt.",
      "Put all tools behind one generic tool with an internal ordering rule."
    ],
    "a": [
      0
    ],
    "e": "A forced tool selection guarantees the specific first call. Follow-up turns can then use the extracted metadata for enrichment. “auto” permits the model to skip the required first tool; description changes and a generic wrapper do not enforce ordering."
  },
  {
    "id": "s2q22",
    "d": "D2",
    "t": "2.3",
    "type": "single",
    "q": "A document workflow expects the model to call one of several extraction tools, but on some inputs it answers in prose instead. You do not know the document type in advance. Which tool_choice setting guarantees a tool call?",
    "o": [
      "\"auto\"",
      "\"none\"",
      "A forced selection of the first extraction tool",
      "\"any\""
    ],
    "a": [
      3
    ],
    "e": "“any” requires the model to call a tool while letting it choose the appropriate one. “auto” permits text, “none” forbids tools, and forcing the first tool misclassifies other document types."
  },
  {
    "id": "s2q23",
    "d": "D2",
    "t": "2.3",
    "type": "single",
    "q": "A general fetch_url tool lets the agent retrieve any URL, including non-document pages that derail analysis. Most use cases only need to load approved documents. What change best constrains behavior?",
    "o": [
      "Keep fetch_url but add a warning label to its description.",
      "Replace fetch_url with a load_document tool that accepts and validates document URLs.",
      "Add “only fetch documents” to the system prompt.",
      "Remove all URL-related tools and rely on the model's prior knowledge."
    ],
    "a": [
      1
    ],
    "e": "Replacing a generic tool with a constrained alternative makes the valid input space explicit and rejects invalid URLs by construction. Prompt guidance and warning labels remain advisory; removing retrieval entirely loses needed capability."
  },
  {
    "id": "s2q24",
    "d": "D2",
    "t": "2.4",
    "type": "single",
    "q": "A developer wants a personal experimental MCP server available in every Claude Code project on their machine, without sharing it with teammates. Where should it be configured?",
    "o": [
      "In .claude/settings.json under a globalServers key.",
      "In ~/.claude.json for user-scoped access across projects.",
      "In each project's .mcp.json so it travels with the repository.",
      "In the root CLAUDE.md as a documented setup step."
    ],
    "a": [
      1
    ],
    "e": "User-scoped configuration in ~/.claude.json is for personal or experimental servers available across projects. Project .mcp.json is shared team tooling; CLAUDE.md is instructions; there is no globalServers key for this purpose."
  },
  {
    "id": "s2q25",
    "d": "D2",
    "t": "2.4",
    "type": "single",
    "q": "An agent repeatedly calls exploratory MCP tools to discover what tables and columns a data warehouse contains. This consumes many turns. What design would reduce that exploration?",
    "o": [
      "Give the agent a tool that returns every row from every table.",
      "Add more exploratory tools with overlapping descriptions.",
      "Expose the database schema as an MCP resource that the agent can read as a content catalog.",
      "Disable the exploratory tools so the agent must guess the schema."
    ],
    "a": [
      2
    ],
    "e": "MCP resources expose catalogs such as schemas, issue summaries or documentation hierarchies without requiring a sequence of exploratory calls. Dumping rows is excessive and unsafe; guessing is unreliable; more overlapping tools worsen selection."
  },
  {
    "id": "s2q26",
    "d": "D2",
    "t": "2.5",
    "type": "single",
    "q": "You need every TypeScript test file in a monorepo, regardless of package location. Which built-in tool and pattern should you use?",
    "o": [
      "Read the root package.json and infer the test paths.",
      "Bash with ls on each package directory.",
      "Grep for the text “test” in all files.",
      "Glob with **/*.test.tsx."
    ],
    "a": [
      3
    ],
    "e": "Glob matches file paths by name and extension pattern, exactly what is needed for **/*.test.tsx. Grep searches contents and would include non-test files; package metadata may not enumerate files; directory listings miss nested paths."
  },
  {
    "id": "s2q27",
    "d": "D2",
    "t": "2.5",
    "type": "single",
    "q": "In an unfamiliar 400-file codebase, you must trace how a refund flows from an HTTP route to the database. What is the most effective built-in-tool strategy?",
    "o": [
      "Use Bash to print every file containing the word “refund” in full.",
      "Start with Grep to find route and refund entry points, then Read the files along the imports and call chain.",
      "Glob for every file, then read only the largest ones.",
      "Read all 400 files upfront so nothing is missed."
    ],
    "a": [
      1
    ],
    "e": "Incremental understanding starts from entry points and follows references, keeping context focused. Reading everything or dumping every match overwhelms the window; file size is unrelated to relevance."
  },
  {
    "id": "s2q28",
    "d": "D3",
    "t": "3.1",
    "type": "single",
    "q": "A monorepo has separate packages with different standards: the API package follows REST conventions, while the worker package follows queue conventions. You want each package's CLAUDE.md to include only relevant standards. What is the best mechanism?",
    "o": [
      "Create one user-level CLAUDE.md with all package rules.",
      "Copy the entire standards library into every package's CLAUDE.md.",
      "Put every standard in the root CLAUDE.md and ask the model to infer which applies.",
      "Use @import in each package's CLAUDE.md to reference only that package's standards file."
    ],
    "a": [
      3
    ],
    "e": "@import keeps shared standards modular and lets each package include only what applies. A monolithic root file invites inference and irrelevant context; duplicating everything is a maintenance burden; user-level configuration is not shared with the team."
  },
  {
    "id": "s2q29",
    "d": "D3",
    "t": "3.1",
    "type": "single",
    "q": "Two developers on the same project get different behavior from Claude Code, and you suspect different memory files are loading. Which command helps diagnose which memory files are active?",
    "o": [
      "/memory",
      "/compact",
      "/init",
      "/review"
    ],
    "a": [
      0
    ],
    "e": "/memory shows which memory files are loaded and is the diagnostic tool for inconsistent CLAUDE.md behavior. /compact reduces context, /review is a workflow command, and /init initializes project memory rather than inspecting the active hierarchy."
  },
  {
    "id": "s2q30",
    "d": "D3",
    "t": "3.2",
    "type": "single",
    "q": "A developer wants a personal variant of the team's /review command with an extra checklist, without changing what teammates get. What is the correct approach?",
    "o": [
      "Put the extra checklist in the project CLAUDE.md.",
      "Edit the project's .claude/commands/review.md directly.",
      "Create a differently named personal command in ~/.claude/commands/.",
      "Delete the team command and recreate it under the same name in the home directory."
    ],
    "a": [
      2
    ],
    "e": "User-scoped commands live in ~/.claude/commands/ and stay personal. A different name avoids confusion with the shared command. Editing the project file changes teammates' behavior; CLAUDE.md is not a command definition; deleting the team command breaks shared workflow."
  },
  {
    "id": "s2q31",
    "d": "D3",
    "t": "3.2",
    "type": "single",
    "q": "A skill requires a ticket ID, but developers often invoke it without arguments and it fails. Which SKILL.md frontmatter option prompts them for the required parameter?",
    "o": [
      "description",
      "argument-hint",
      "allowed-tools",
      "context: fork"
    ],
    "a": [
      1
    ],
    "e": "argument-hint displays the expected parameters when the skill is invoked without them. allowed-tools restricts tools, context: fork isolates execution, and description helps discovery but does not collect missing input."
  },
  {
    "id": "s2q32",
    "d": "D3",
    "t": "3.3",
    "type": "single",
    "q": "SQL migration files live under db/migrations, services/billing/migrations and services/auth/migrations. All should follow the same migration conventions. What rule configuration is most maintainable?",
    "o": [
      "A skill invoked manually before editing each migration.",
      "A separate CLAUDE.md in each migrations directory.",
      "A .claude/rules/ file with paths: [\"**/migrations/**/*.sql\"]",
      "A root CLAUDE.md section that says “migration files” and relies on inference."
    ],
    "a": [
      2
    ],
    "e": "A glob spanning directories applies the convention wherever matching SQL migrations appear. Directory-bound CLAUDE.md files require duplication; inference is unreliable; manual skill invocation is not automatic."
  },
  {
    "id": "s2q33",
    "d": "D3",
    "t": "3.3",
    "type": "single",
    "q": "A convention applies to every file of a given type, no matter which directory it sits in. Why are path-specific rules preferable to subdirectory CLAUDE.md files?",
    "o": [
      "Subdirectory CLAUDE.md files always override project instructions.",
      "Subdirectory CLAUDE.md files cannot contain code conventions.",
      "Path rules load only for matching files, so they can target file types across directories without duplicate files.",
      "Path rules are the only way to use YAML in Claude Code."
    ],
    "a": [
      2
    ],
    "e": "Glob-based path rules provide conditional loading by file pattern and are not tied to one directory. Directory CLAUDE.md files can hold conventions but are bound to their directory, which forces duplication when the same convention spans the codebase."
  },
  {
    "id": "s2q34",
    "d": "D3",
    "t": "3.4",
    "type": "single",
    "q": "During a multi-phase task, a verbose discovery step is filling the main conversation with file listings and search output. You need the findings but not the noise. What is the best approach?",
    "o": [
      "Use the Explore subagent for discovery so verbose output stays isolated and only a summary returns.",
      "Run discovery in the main session and delete messages manually afterward.",
      "Increase the context window and keep every discovery message.",
      "Avoid discovery and implement based on assumptions."
    ],
    "a": [
      0
    ],
    "e": "The Explore subagent isolates verbose discovery and returns a summary, preserving the main conversation's context for coordination and implementation. Manual deletion is error-prone; skipping discovery risks wrong assumptions; a larger window postpones exhaustion."
  },
  {
    "id": "s2q35",
    "d": "D3",
    "t": "3.4",
    "type": "single",
    "q": "A migration needs investigation of several integration approaches followed by implementation of the chosen one. How should plan mode and direct execution be combined?",
    "o": [
      "Use direct execution for both investigation and implementation to save time.",
      "Use plan mode to investigate and choose an approach, then switch to direct execution for the chosen implementation.",
      "Fork a session for each approach and never converge on one.",
      "Stay in plan mode through implementation so no code is written until the end."
    ],
    "a": [
      1
    ],
    "e": "Plan mode is valuable for exploration and architectural choice; direct execution is efficient once the approach is known. Remaining in plan mode blocks implementation; direct investigation risks costly rework; forking without convergence does not deliver the change."
  },
  {
    "id": "s2q36",
    "d": "D3",
    "t": "3.5",
    "type": "single",
    "q": "You must add caching to a system whose invalidation rules you do not fully understand. Before implementing, you want to surface design considerations you may have missed. Which technique fits best?",
    "o": [
      "Skip design and let the test suite reveal the invalidation strategy.",
      "Provide a complete implementation and ask Claude to approve it.",
      "Raise the temperature and accept the first design that appears.",
      "Use the interview pattern and have Claude ask you questions about invalidation, failure modes and constraints."
    ],
    "a": [
      3
    ],
    "e": "The interview pattern surfaces unanticipated considerations before code is written, which is valuable in unfamiliar domains. Self-approval lacks independent scrutiny; random design is not analysis; tests verify behavior but do not choose a coherent strategy."
  },
  {
    "id": "s2q37",
    "d": "D3",
    "t": "3.5",
    "type": "single",
    "q": "A refactor has four issues, but fixing the null handling changes how the retry logic behaves, which in turn affects logging. How should the issues be presented?",
    "o": [
      "Ask for four independent patches and merge them without review.",
      "Fix only the first issue and wait for the tests to reveal the rest.",
      "Address all interacting issues in one detailed message that explains the dependencies.",
      "Fix them one at a time in separate messages and never mention the interactions."
    ],
    "a": [
      2
    ],
    "e": "When fixes interact, separate iterations can produce conflicting local solutions. A single detailed message lets the model reason about the dependencies together. Sequential blind fixes may thrash; withholding known issues wastes cycles; merging independent patches ignores interactions."
  },
  {
    "id": "s2q38",
    "d": "D3",
    "t": "3.6",
    "type": "single",
    "q": "A CI job must post each review finding as an inline pull-request comment. The pipeline needs machine-parseable output with a fixed finding schema. Which invocation is appropriate?",
    "o": [
      "claude --output-format json --json-schema findings.schema.json -p \"Review this PR\"",
      "claude -p \"Review this PR\" with a request to “please return JSON”.",
      "claude --interactive --format markdown \"Review this PR\"",
      "claude -p \"Review this PR\" with prose output parsed by a regex."
    ],
    "a": [
      0
    ],
    "e": "--output-format json plus --json-schema gives a structured, schema-constrained payload for automated posting. Prose plus regex is brittle; an interactive flag defeats CI; a prompt-only JSON request is not enforced."
  },
  {
    "id": "s2q39",
    "d": "D3",
    "t": "3.6",
    "type": "single",
    "q": "A pull request is re-reviewed after new commits, but the bot reposts comments that were already addressed. What change fixes the duplicate feedback?",
    "o": [
      "Disable review on updates and run it only when the PR is opened.",
      "Run the review on only the newest commit and ignore the rest of the PR.",
      "Include the prior review findings in context and instruct the reviewer to report only new or still-unaddressed issues.",
      "Increase the review model's temperature so it produces different comments."
    ],
    "a": [
      2
    ],
    "e": "Prior findings let the reviewer distinguish resolved issues from new ones and avoid duplicates. Reviewing only the newest commit may miss unresolved issues elsewhere; disabling updates removes useful feedback; randomness is not deduplication."
  },
  {
    "id": "s2q40",
    "d": "D4",
    "t": "4.1",
    "type": "single",
    "q": "A code-comment reviewer is told to “check that comments are accurate”. It flags harmless wording differences and misses comments that contradict actual behavior. What instruction change most improves precision?",
    "o": [
      "Add more examples of comments it should not flag, without changing the criteria.",
      "Ask it to be more conservative and only report high-confidence findings.",
      "Tell it to review comments only in changed files.",
      "Specify that it should flag a comment only when the claimed behavior contradicts the code, and skip wording or style differences."
    ],
    "a": [
      3
    ],
    "e": "A categorical criterion defines the exact condition to report and excludes style noise. “Be conservative” is vague; limiting files reduces coverage; negative examples without a clear rule leave the decision boundary fuzzy."
  },
  {
    "id": "s2q41",
    "d": "D4",
    "t": "4.1",
    "type": "single",
    "q": "A security reviewer flags many theoretical issues that cannot be exploited in this architecture, while missing real vulnerabilities. Developers no longer trust it. What is the best prompt change?",
    "o": [
      "Lower the temperature and repeat the same instruction.",
      "Define explicit criteria for exploitable vulnerabilities versus theoretical concerns, with concrete examples of each.",
      "Reduce the review to the five largest files.",
      "Add “only report high-confidence findings” to the system prompt."
    ],
    "a": [
      1
    ],
    "e": "Precision requires a decision rule tied to the architecture and exploitability, not a confidence slogan. Concrete categories and examples calibrate judgment. File-count limits reduce coverage; lower temperature does not change relevance."
  },
  {
    "id": "s2q42",
    "d": "D4",
    "t": "4.2",
    "type": "single",
    "q": "A support agent must choose between a knowledge-base search and an order-database lookup for ambiguous requests. Instructions alone produce inconsistent choices. What few-shot design is most useful?",
    "o": [
      "Two to four examples of ambiguous requests that show the chosen tool and the reasoning for rejecting the plausible alternative.",
      "Twenty examples that list only the final tool name with no explanation.",
      "One example for every possible customer phrase.",
      "Examples of successful answers but not of tool selection."
    ],
    "a": [
      0
    ],
    "e": "Targeted examples that expose the decision rationale teach the model how to generalize to new ambiguous cases. Tool names alone do not explain boundaries; enumerating phrases is brittle; answer examples do not demonstrate routing."
  },
  {
    "id": "s2q43",
    "d": "D4",
    "t": "4.2",
    "type": "single",
    "q": "A reviewer keeps flagging an accepted repository pattern as a bug. You want it to distinguish that pattern from genuine defects and still catch novel variants. What is the best approach?",
    "o": [
      "Provide few-shot examples that contrast acceptable uses of the pattern with genuine defects, explaining the distinction.",
      "Remove all such code from the training examples.",
      "Add a blanket rule that suppresses every finding containing that pattern name.",
      "Ask developers to close those findings manually each time."
    ],
    "a": [
      0
    ],
    "e": "Contrastive examples teach the boundary and support generalization to new variants. A blanket suppression rule creates false negatives; removing examples leaves the model without context; manual triage does not improve the reviewer."
  },
  {
    "id": "s2q44",
    "d": "D4",
    "t": "4.3",
    "type": "single",
    "q": "A document-classification schema must support a known set of categories plus emerging categories not yet enumerated, without losing the specific label. Which schema design fits?",
    "o": [
      "A free-text category field with no constraints.",
      "A numeric confidence field with no category field.",
      "A required enum containing only today's categories.",
      "An enum that includes “other” plus a companion detail string for the specific label."
    ],
    "a": [
      3
    ],
    "e": "An “other” enum member preserves schema validity while a detail string captures the unanticipated category. Free text loses enumeration; a closed enum rejects new categories; a confidence score does not classify the document."
  },
  {
    "id": "s2q45",
    "d": "D4",
    "t": "4.3",
    "type": "single",
    "q": "An extraction schema requires a `termination_reason` field, but some contracts are silent on termination and others use ambiguous language. What schema change best avoids fabricated values?",
    "o": [
      "Make the field required and instruct the model to infer the most likely reason.",
      "Allow nullable values and add an “unclear” enum member for ambiguous cases.",
      "Remove the field entirely from the schema.",
      "Add a default value of “breach” so every document has an answer."
    ],
    "a": [
      1
    ],
    "e": "Nullable fields and an explicit “unclear” option let the model represent absence or ambiguity honestly. Forcing inference or a default fabricates data; removing the field loses a legitimate output when the source does state a reason."
  },
  {
    "id": "s2q46",
    "d": "D4",
    "t": "4.4",
    "type": "single",
    "q": "Developers dismiss many review findings, but you cannot tell which code constructs cause the false positives. What schema addition best enables systematic analysis?",
    "o": [
      "A timestamp field showing when the finding was generated.",
      "A longer explanation field with more prose.",
      "A free-text “notes” field on every finding.",
      "A detected_pattern field identifying the construct that triggered each finding."
    ],
    "a": [
      3
    ],
    "e": "A structured detected_pattern field lets you aggregate dismissals by construct and improve the prompt or rules where false positives cluster. Free-text notes are hard to aggregate; timestamps and longer prose do not identify the cause."
  },
  {
    "id": "s2q47",
    "d": "D4",
    "t": "4.4",
    "type": "single",
    "q": "Invoice extraction sometimes returns a line-item total that disagrees with the stated total, yet the JSON is schema-valid. What design best detects this semantic error?",
    "o": [
      "Retry the extraction until the two values happen to match.",
      "Extract both calculated_total and stated_total, then flag any discrepancy for review.",
      "Make the schema stricter so JSON syntax errors cannot occur.",
      "Trust the model because schema validation already passed."
    ],
    "a": [
      1
    ],
    "e": "Tool use eliminates syntax errors but not semantic inconsistencies. Capturing both values makes the disagreement explicit and routable. Stricter syntax does not compare totals; retrying without feedback is guessing; schema validity says nothing about correctness."
  },
  {
    "id": "s2q48",
    "d": "D4",
    "t": "4.5",
    "type": "single",
    "q": "A workflow needs to call a tool, inspect its result, and then make another model call within the same logical job. A manager proposes the Message Batches API for its cost savings. What should you advise?",
    "o": [
      "Use the batch API with a larger model to avoid the need for tools.",
      "Use the synchronous API because batch requests do not support multi-turn tool calling within a single request.",
      "Use the batch API and poll every minute for the intermediate result.",
      "Use the batch API because custom_id can coordinate the intermediate tool calls."
    ],
    "a": [
      1
    ],
    "e": "The Message Batches API cannot execute tools mid-request and return results for another turn, so it does not fit this interactive tool loop. custom_id correlates requests but does not add tool execution; polling and model size do not change the batch contract."
  },
  {
    "id": "s2q49",
    "d": "D4",
    "t": "4.5",
    "type": "single",
    "q": "A report pipeline has a 30-hour delivery SLA. Batch processing can take up to 24 hours, and documents arrive continuously. How should submissions be scheduled to stay within the SLA?",
    "o": [
      "Submit in 4-hour windows so the oldest document waits at most 24 hours of processing plus 4 hours of queueing.",
      "Submit one batch every 24 hours.",
      "Submit only when 10,000 documents have accumulated.",
      "Submit one batch every 30 hours."
    ],
    "a": [
      0
    ],
    "e": "With up to 24 hours of batch processing, a 4-hour submission window keeps worst-case age within 28 hours, inside the 30-hour SLA. Daily or 30-hour cadence can exceed the SLA; volume-triggered submission ignores arrival time."
  },
  {
    "id": "s2q50",
    "d": "D4",
    "t": "4.6",
    "type": "multi",
    "n": 2,
    "q": "A 40-file pull request produces contradictory review comments and misses cross-file data-flow bugs. Which two review passes best address both problems? (Select two.)",
    "o": [
      "A separate cross-file integration pass for data-flow and trust boundaries.",
      "Three identical full-PR passes with majority voting.",
      "A larger context window with all 40 files in one pass.",
      "A per-file local analysis pass for issues within each file."
    ],
    "a": [
      0,
      3
    ],
    "e": "Per-file passes prevent attention dilution, while a separate integration pass finds issues that only appear across files. Majority voting can suppress real intermittent findings, and a larger context window does not guarantee consistent attention."
  },
  {
    "id": "s2q51",
    "d": "D4",
    "t": "4.6",
    "type": "single",
    "q": "A model generates a security-sensitive patch and then checks it in the same conversation. It approves a flaw it introduced. What is the most reliable review setup?",
    "o": [
      "Ask the same model to review again with a stronger instruction to be skeptical.",
      "Have an independent Claude instance review the patch without the generator's reasoning context.",
      "Ask the generator to explain why the patch is secure and accept if the explanation is coherent.",
      "Increase the generator's temperature during self-review."
    ],
    "a": [
      1
    ],
    "e": "Independent review removes the generator's anchoring reasoning and is better at questioning subtle decisions. Re-prompting the same context retains its commitments; temperature does not create independence; a coherent self-justification can rationalize the same flaw."
  },
  {
    "id": "s2q52",
    "d": "D5",
    "t": "5.1",
    "type": "single",
    "q": "A long aggregated input contains a key summary in the middle, followed by hundreds of pages of detail. The model repeatedly misses the summary's findings. What layout change best mitigates position effects?",
    "o": [
      "Move the key findings summary to the beginning and organize the details under explicit section headers.",
      "Interleave the summary randomly throughout the document.",
      "Put the summary at the very end and remove all headers.",
      "Compress the details into one unbroken paragraph."
    ],
    "a": [
      0
    ],
    "e": "Models reliably process the beginning and end of long inputs better than the middle. Leading with the summary and using explicit headers reduces the chance that key findings are lost. Random placement or a wall of text worsens retrieval."
  },
  {
    "id": "s2q53",
    "d": "D5",
    "t": "5.1",
    "type": "single",
    "q": "A multi-turn support application sends only the newest user message on each API request. The model keeps losing earlier commitments and order details. What is the underlying problem?",
    "o": [
      "The model's temperature is too low to remember previous turns.",
      "Tool results are always cached by the API and should not be resent.",
      "The API is stateless, so the application must pass the relevant conversation history on each request.",
      "The system prompt is too short to store the full transcript."
    ],
    "a": [
      2
    ],
    "e": "The Messages API does not maintain conversation state between calls; the application supplies history. Sending only the newest message discards the context the model needs. Temperature and system-prompt length do not replace history, and tool results are not automatically preserved."
  },
  {
    "id": "s2q54",
    "d": "D5",
    "t": "5.2",
    "type": "multi",
    "n": 2,
    "q": "A customer writes an angry message about a simple password reset and uses strong language. The agent escalates solely because of negative sentiment. Which two behaviors are more appropriate? (Select two.)",
    "o": [
      "Ask the customer to calm down before diagnosing the issue.",
      "Escalate if the customer explicitly reiterates a preference for a human.",
      "Acknowledge the frustration and offer to resolve the straightforward issue.",
      "Escalate every message that contains profanity."
    ],
    "a": [
      1,
      2
    ],
    "e": "Sentiment is not a reliable proxy for case complexity. Acknowledging frustration while using the agent's capability serves the customer, and an explicit preference for a human is a valid escalation trigger. Blanket profanity escalation and tone policing are poor service."
  },
  {
    "id": "s2q55",
    "d": "D5",
    "t": "5.3",
    "type": "single",
    "q": "A subagent wraps every tool call in a broad exception handler and returns an empty list on failure. The coordinator treats the result as “no matches found”. What is the design flaw?",
    "o": [
      "The empty list should be cached to reduce future errors.",
      "The subagent needs more tools so it can retry every failure.",
      "The subagent is suppressing access failures and misrepresenting them as valid empty results.",
      "The coordinator should have used a larger context window."
    ],
    "a": [
      2
    ],
    "e": "Access failures and valid empty results are semantically different. Suppressing exceptions prevents the coordinator from deciding whether to retry, switch sources or annotate a gap. Context size, tool count and caching do not fix mislabeled outcomes."
  },
  {
    "id": "s2q56",
    "d": "D5",
    "t": "5.4",
    "type": "single",
    "q": "A long-running multi-agent codebase analysis crashes overnight. On restart, the coordinator cannot tell which modules were already analyzed or which findings are trustworthy. What design would enable recovery?",
    "o": [
      "Rely on the model's memory of the previous run.",
      "Have each agent export structured state and findings to a known location, and have the coordinator load a manifest on resume.",
      "Keep the whole repository in one agent's context to avoid handoffs.",
      "Restart the entire analysis from scratch every time."
    ],
    "a": [
      1
    ],
    "e": "Structured state exports and a manifest give the coordinator durable knowledge of completed work and validated findings. Model memory does not survive a crash; full restarts waste work; a single giant context is fragile and does not provide recovery metadata."
  },
  {
    "id": "s2q57",
    "d": "D5",
    "t": "5.4",
    "type": "single",
    "q": "During an extended exploration session, the context window fills with verbose discovery output, leaving little room for reasoning. Which action is specifically intended to reduce context usage in this situation?",
    "o": [
      "Use /review to start a code review.",
      "Use /memory to load more instructions.",
      "Use /compact to condense the conversation while preserving essential context.",
      "Use /init to reinitialize the project."
    ],
    "a": [
      2
    ],
    "e": "/compact reduces context usage by summarizing the session while retaining important context, which fits extended exploration. /init, /memory and /review serve different purposes and do not compact the current context."
  },
  {
    "id": "s2q58",
    "d": "D5",
    "t": "5.5",
    "type": "single",
    "q": "An extraction system is highly accurate overall, and the team wants ongoing evidence that confident extractions remain correct. Which monitoring approach best detects novel error patterns?",
    "o": [
      "Stratified random sampling of high-confidence extractions, reviewed against ground truth.",
      "Increase the confidence threshold until errors disappear from the dashboard.",
      "Review only documents the model marks as low confidence.",
      "Track only the aggregate accuracy metric once per month."
    ],
    "a": [
      0
    ],
    "e": "Stratified sampling of high-confidence output provides ongoing error-rate estimates and can surface new patterns that aggregate metrics hide. Aggregate-only tracking misses segment drift; low-confidence-only review ignores confident errors; raising thresholds hides rather than fixes them."
  },
  {
    "id": "s2q59",
    "d": "D5",
    "t": "5.5",
    "type": "single",
    "q": "You have field-level confidence scores from an extractor but no principled way to set the human-review threshold. What should you use?",
    "o": [
      "The model's overall confidence for the whole document.",
      "A fixed threshold of 0.9 for every field and document type.",
      "The threshold from a different vendor's extraction system.",
      "A labeled validation set to calibrate field-level thresholds against observed accuracy."
    ],
    "a": [
      3
    ],
    "e": "Confidence scores must be calibrated against labeled outcomes to choose thresholds that reflect real accuracy. A universal 0.9 ignores field and document differences; document-level confidence hides field variation; another system's calibration does not transfer."
  },
  {
    "id": "s2q60",
    "d": "D5",
    "t": "5.6",
    "type": "single",
    "q": "Two sources disagree on a market statistic. One was published in 2023 and the other in 2026, and the difference may reflect timing rather than a real conflict. What should the structured findings include?",
    "o": [
      "Publication or data-collection dates alongside each value and claim.",
      "Only the most recent value, with the older source omitted.",
      "A single averaged value without dates.",
      "A note that all statistics are inherently unreliable."
    ],
    "a": [
      0
    ],
    "e": "Temporal metadata lets synthesis distinguish a genuine conflict from a change over time. Dropping the older value hides evidence; averaging invents a number; a blanket disclaimer is not provenance."
  }
];
